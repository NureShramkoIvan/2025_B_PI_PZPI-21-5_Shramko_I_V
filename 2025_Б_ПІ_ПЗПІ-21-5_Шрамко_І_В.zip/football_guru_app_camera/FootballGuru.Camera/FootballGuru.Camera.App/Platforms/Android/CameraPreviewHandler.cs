﻿using Android.Content;
using Android.Graphics;
using Android.Hardware.Camera2;
using Android.Media;
using Android.Views;
using AndroidUtil = Android.Util;
using Java.Lang;
using Java.Nio;
using Microsoft.Maui.Handlers;
using Microsoft.Maui.Platform;
using System.Diagnostics;
using FootballGuru.Camera.App.Controls;
using Microsoft.Maui;
using System;
using Android.Hardware.Camera2.Params;
using AndroidMedia = Android.Media;


namespace FootballGuru.Camera.App.Platforms.Android
{
    public partial class CameraPreviewHandler : ViewHandler<CameraPreview, TextureView>
    {
        CameraDevice cameraDevice;
        CameraCaptureSession captureSession;
        CaptureRequest.Builder previewRequestBuilder;
        TextureView textureView;
        string cameraId;
        AndroidUtil.Size previewSize;

        ImageReader imageReader; // We'll capture YUV frames here

        // Mappers required by MAUI's handler architecture:
        public static IPropertyMapper<CameraPreview, CameraPreviewHandler> CameraPreviewMapper
            = new PropertyMapper<CameraPreview, CameraPreviewHandler>(ViewHandler.ViewMapper);

        public static CommandMapper<CameraPreview, CameraPreviewHandler> CameraPreviewCommandMapper
            = new(ViewHandler.ViewCommandMapper);

        public CameraPreviewHandler()
            : base(CameraPreviewMapper, CameraPreviewCommandMapper)
        {
        }

        protected override TextureView CreatePlatformView()
        {
            textureView = new TextureView(Context);
            textureView.SurfaceTextureListener = new MyTextureListener(this);
            return textureView;
        }

        protected override void ConnectHandler(TextureView nativeView)
        {
            base.ConnectHandler(nativeView);
            // We'll open the camera in OnSurfaceTextureAvailable
        }

        protected override void DisconnectHandler(TextureView nativeView)
        {
            CloseCamera();
            base.DisconnectHandler(nativeView);
        }

        #region Camera Setup

        void OpenCamera()
        {
            if (Context == null) return;

            var cameraManager = (CameraManager)Context.GetSystemService(Context.CameraService);
            try
            {
                // 1) Pick a back-facing camera ID
                string[] cameraIds = cameraManager.GetCameraIdList();
                foreach (var id in cameraIds)
                {
                    var characteristics = cameraManager.GetCameraCharacteristics(id);
                    var facing = (Integer)characteristics.Get(CameraCharacteristics.LensFacing);
                    if (facing != null && facing.IntValue() == (int)LensFacing.Back)
                    {
                        cameraId = id;
                        break;
                    }
                }
                if (cameraId == null && cameraIds.Length > 0)
                {
                    // fallback if we didn't find a back camera
                    cameraId = cameraIds[0];
                }

                // 2) Attempt to force 1920x1080 for preview
                var map = (StreamConfigurationMap)cameraManager
                    .GetCameraCharacteristics(cameraId)
                    .Get(CameraCharacteristics.ScalerStreamConfigurationMap);

                if (map != null)
                {
                    var allSizes = map.GetOutputSizes(Class.FromType(typeof(SurfaceTexture)));

                    // Let's see if 1920 x 1080 is supported
                    var desiredWidth = 1920;
                    var desiredHeight = 1080;
                    AndroidUtil.Size selectedSize = null;

                    foreach (var s in allSizes)
                    {
                        Debug.WriteLine($"Supported preview size: {s.Width} x {s.Height}");
                        if (s.Width == desiredWidth && s.Height == desiredHeight)
                        {
                            selectedSize = s;
                            break;
                        }
                    }

                    if (selectedSize == null)
                    {
                        // Fallback to the first if 1920x1080 not found
                        selectedSize = allSizes[0];
                    }

                    previewSize = selectedSize;
                    Debug.WriteLine($"[CameraPreviewHandler] Selected preview size: {previewSize.Width} x {previewSize.Height}");
                }

                cameraManager.OpenCamera(cameraId, new MyStateCallback(this), null);
            }
            catch (CameraAccessException ex)
            {
                Debug.WriteLine($"OpenCamera error: {ex}");
            }
            catch (System.Exception e)
            {
                Debug.WriteLine($"OpenCamera unexpected error: {e}");
            }
        }

        void CloseCamera()
        {
            captureSession?.Close();
            captureSession = null;

            cameraDevice?.Close();
            cameraDevice = null;

            imageReader?.Close();
            imageReader = null;
        }

        #endregion

        internal void OnSurfaceTextureAvailable(SurfaceTexture surface, int width, int height)
        {
            // Once the TextureView is ready, we open the camera
            OpenCamera();
        }

        internal void OnCameraOpened(CameraDevice camera)
        {
            cameraDevice = camera;
            try
            {
                // The TextureView's Surface
                var surfaceTexture = textureView!.SurfaceTexture;
                surfaceTexture.SetDefaultBufferSize(previewSize.Width, previewSize.Height);
                var previewSurface = new Surface(surfaceTexture);

                // 1) Build the preview request
                previewRequestBuilder = cameraDevice.CreateCaptureRequest(CameraTemplate.Preview);
                previewRequestBuilder.AddTarget(previewSurface);

                // 2) Create an ImageReader for YUV frames at the same resolution
                imageReader = ImageReader.NewInstance(
                    previewSize.Width,
                    previewSize.Height,
                    ImageFormatType.Yuv420888,
                    /*maxImages*/2
                );
                imageReader.SetOnImageAvailableListener(new YuvImageAvailableListener(this), null);

                previewRequestBuilder.AddTarget(imageReader.Surface);

                // 3) Create a capture session with both the preview surface and the imageReader
                cameraDevice.CreateCaptureSession(
                    new[] { previewSurface, imageReader.Surface },
                    new MySessionCallback(this),
                    null
                );
            }
            catch (CameraAccessException ex)
            {
                Debug.WriteLine($"OnCameraOpened error: {ex}");
            }
        }

        internal void OnSessionConfigured(CameraCaptureSession session)
        {
            captureSession = session;
            if (cameraDevice == null) return;

            try
            {
                previewRequestBuilder!.Set(CaptureRequest.ControlMode, (int)ControlMode.Auto);

                var previewRequest = previewRequestBuilder.Build();
                captureSession.SetRepeatingRequest(previewRequest, null, null);
            }
            catch (CameraAccessException ex)
            {
                Debug.WriteLine($"OnSessionConfigured error: {ex}");
            }
        }

        #region Nested Classes

        class MyTextureListener : Java.Lang.Object, TextureView.ISurfaceTextureListener
        {
            readonly CameraPreviewHandler handler;
            public MyTextureListener(CameraPreviewHandler cameraPreviewHandler)
            {
                handler = cameraPreviewHandler;
            }

            public void OnSurfaceTextureAvailable(SurfaceTexture surface, int width, int height)
            {
                handler.OnSurfaceTextureAvailable(surface, width, height);
            }

            public bool OnSurfaceTextureDestroyed(SurfaceTexture surface) => true;
            public void OnSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) { }
            public void OnSurfaceTextureUpdated(SurfaceTexture surface)
            {
                // Called whenever a new frame is drawn onto the TextureView
                //Debug.WriteLine("Camera frame updated (Android Handler).");

                // Bubble up to the shared control's event
                handler.VirtualView?.RaiseFrameUpdated();
            }
        }

        class MyStateCallback : CameraDevice.StateCallback
        {
            readonly CameraPreviewHandler handler;
            public MyStateCallback(CameraPreviewHandler cameraPreviewHandler)
            {
                handler = cameraPreviewHandler;
            }

            public override void OnOpened(CameraDevice camera)
            {
                handler.OnCameraOpened(camera);
            }
            public override void OnDisconnected(CameraDevice camera)
            {
                camera.Close();
                handler.cameraDevice = null;
            }
            public override void OnError(CameraDevice camera, CameraError error)
            {
                camera.Close();
                handler.cameraDevice = null;
            }
        }

        class MySessionCallback : CameraCaptureSession.StateCallback
        {
            readonly CameraPreviewHandler handler;
            public MySessionCallback(CameraPreviewHandler cameraPreviewHandler)
            {
                handler = cameraPreviewHandler;
            }

            public override void OnConfigured(CameraCaptureSession session)
            {
                handler.OnSessionConfigured(session);
            }

            public override void OnConfigureFailed(CameraCaptureSession session)
            {
                Debug.WriteLine("OnConfigureFailed: session configuration failed");
            }
        }

        #endregion
    }

    // This listener handles YUV frames from the ImageReader and does a naive YUV->BGR conversion
    class YuvImageAvailableListener : Java.Lang.Object, ImageReader.IOnImageAvailableListener
    {
        private readonly CameraPreviewHandler _handler;

        private int _frameCount = 0;
        private int _skipCount = 10;
        //private int _skipCount = 1;

        public YuvImageAvailableListener(CameraPreviewHandler handler)
        {
            _handler = handler;
        }

        public void OnImageAvailable(ImageReader reader)
        {
            using var image = reader.AcquireLatestImage();
            if (image == null) return;

            _frameCount++;

            if (_frameCount < _skipCount)
            {
                image.Close();
                return;
            }
            else
            {
                _frameCount = 0;
            }

            try
            {
                // 1) Save the dimensions
                int w = image.Width;
                int h = image.Height;

                // 2) Get references to the planes (assuming YUV_420_888)
                var planes = image.GetPlanes();

                // 3) Copy raw data from each plane
                //    This is very minimal copying—just read the ByteBuffers.
                var yPlaneBuffer = new byte[planes[0].Buffer.Remaining()];
                planes[0].Buffer.Get(yPlaneBuffer, 0, yPlaneBuffer.Length);

                var uPlaneBuffer = new byte[planes[1].Buffer.Remaining()];
                planes[1].Buffer.Get(uPlaneBuffer, 0, uPlaneBuffer.Length);

                var vPlaneBuffer = new byte[planes[2].Buffer.Remaining()];
                planes[2].Buffer.Get(vPlaneBuffer, 0, vPlaneBuffer.Length);

                // 4) Close image
                image.Close();

                // 5) Offload the rest to a Task
                Task.Run(() =>
                {
                    // e.g. Convert YUV -> BGR in background
                    // DO NOT reference 'planes[0].Buffer' again,
                    // because the image is closed. We only use yPlaneBuffer, etc.
                    var bgrBytes = ConvertYUV420ToBGR(yPlaneBuffer, uPlaneBuffer, vPlaneBuffer, w, h);

                    // Then do Emgu CV or additional logic
                    // ...

                    _handler.VirtualView.RaiseBgrFrame(w,h, bgrBytes);
                });
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine("OnImageAvailable error: " + ex);
            }
            finally
            {
                image.Close();
            }
        }

        // A simple (not stride-aware) YUV420 -> BGR function
        // For demonstration only! Real devices may require handling row/pixel strides carefully.
        private byte[] ConvertYUV420ToBGR(
                byte[] yBytes,
                byte[] uBytes,
                byte[] vBytes,
                int width,
                int height)
        {
            //var planes = image.GetPlanes();
            //if (planes.Length < 3)
            //    return Array.Empty<byte>();
            //
            //var yBuffer = planes[0].Buffer; // Y
            //var uBuffer = planes[1].Buffer; // U
            //var vBuffer = planes[2].Buffer; // V

            //int width = image.Width;
            //int height = image.Height;

            // For BGR, need 3 bytes per pixel
            byte[] bgrBytes = new byte[width * height * 3];

            // Extract Y, U, V planes (assuming they're nicely packed, which is device-dependent)
            //byte[] yBytes = new byte[yBuffer.Remaining()];
            //byte[] uBytes = new byte[uBuffer.Remaining()];
            //byte[] vBytes = new byte[vBuffer.Remaining()];

            //yBuffer.Get(yBytes, 0, yBytes.Length);
            //uBuffer.Get(uBytes, 0, uBytes.Length);
            //vBuffer.Get(vBytes, 0, vBytes.Length);

            // Basic iteration
            // Typically Y plane is full size, U/V are half width & half height
            int uvWidth = width / 2;
            int uvHeight = height / 2;

            for (int row = 0; row < height; row++)
            {
                for (int col = 0; col < width; col++)
                {
                    int yIndex = row * width + col;
                    int Y = (0xFF & yBytes[yIndex]);

                    int uvRow = row / 2;
                    int uvCol = col / 2;
                    int uvIndex = uvRow * uvWidth + uvCol;

                    // Assuming plane[1] = U, plane[2] = V
                    int U = (0xFF & uBytes[uvIndex]);
                    int V = (0xFF & vBytes[uvIndex]);

                    // Convert to RGB (or BGR):
                    // see standard formula
                    int C = Y - 16;
                    int D = U - 128;
                    int E = V - 128;

                    if (C < 0) C = 0;

                    int r = (298 * C + 409 * E + 128) >> 8;
                    int g = (298 * C - 100 * D - 208 * E + 128) >> 8;
                    int b = (298 * C + 516 * D + 128) >> 8;

                    // clamp
                    r = System.Math.Min(System.Math.Max(r, 0), 255);
                    g = System.Math.Min(System.Math.Max(g, 0), 255);
                    b = System.Math.Min(System.Math.Max(b, 0), 255);

                    // BGR index
                    int pixelIndex = (row * width + col) * 3;
                    bgrBytes[pixelIndex + 0] = (byte)b;
                    bgrBytes[pixelIndex + 1] = (byte)g;
                    bgrBytes[pixelIndex + 2] = (byte)r;
                }
            }

            return bgrBytes;
        }
    }
}
