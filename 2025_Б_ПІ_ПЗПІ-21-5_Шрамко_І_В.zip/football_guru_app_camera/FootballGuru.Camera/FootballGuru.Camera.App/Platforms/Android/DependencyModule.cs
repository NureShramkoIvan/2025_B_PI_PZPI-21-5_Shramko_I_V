﻿using FootballGuru.Camera.App.Infrastructure;
using FootballGuru.Camera.App.Platforms.Android;

namespace FootballGuru.Camera.App;

public static class DependencyModule
{
    public static IServiceCollection AddPlatformServices(this IServiceCollection services)
    {
        services.AddSingleton<IWifiDirect, WifiDirect>();
        return services;
    }
}
