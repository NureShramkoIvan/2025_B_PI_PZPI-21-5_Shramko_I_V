
namespace FootballGuru.Camera.App.States;

public class PlayerPositionsState
{
    public event EventHandler<int> PlayerPositionDataCollected;

    public Dictionary<int, List<PlayerPosition>> PlayerPositions { get; set; } = new Dictionary<int, List<PlayerPosition>>();

    public void UpdatePlayerPosition(int playerId, double left, double right)
    {
        PlayerPositions[playerId].Add(new PlayerPosition { PlayerId = playerId, Left = left, Right = right });
        PlayerPositionDataCollected?.Invoke(this, playerId);
    }
}

public class PlayerPosition
{
    public int PlayerId { get; set; }
    public double Left { get; set; }
    public double Right { get; set; }
}