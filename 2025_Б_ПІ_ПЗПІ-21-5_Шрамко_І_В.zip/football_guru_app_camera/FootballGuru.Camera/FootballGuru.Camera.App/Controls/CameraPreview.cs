﻿using Microsoft.Maui.Controls;

namespace FootballGuru.Camera.App.Controls;

/// <summary>
/// A simple cross-platform placeholder for a custom camera preview.
/// The actual native implementation is in our custom handler on Android.
/// </summary>
public class CameraPreview : View
{
    // Event that notifies when a new frame is drawn
    public event EventHandler FrameUpdated;

    // We'll expose a method so the native handler can raise this event
    public void RaiseFrameUpdated()
        => FrameUpdated?.Invoke(this, EventArgs.Empty);

    public event EventHandler<(int, int, byte[])> BgrFrameAvailable;

    internal void RaiseBgrFrame(int width, int height, byte[] data)
    {
        BgrFrameAvailable?.Invoke(this, (width, height, data));
    }
}