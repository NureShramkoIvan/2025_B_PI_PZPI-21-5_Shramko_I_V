﻿namespace FootballGuru.Camera.App;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute(nameof(Pages.CameraPage), typeof(Pages.CameraPage));
        Routing.RegisterRoute(nameof(Pages.ConfigureCameraPage), typeof(Pages.ConfigureCameraPage));
    }
}
