﻿using FootballGuru.Camera.App.Enums;
using System.Collections.Concurrent;

namespace FootballGuru.Camera.App.Processors;

public class InvalidPositionsBuffer
{
    public class BufferRecord
    {
        public int PlayerId { get; set; }
        public DateTime? TimeStamp { get; set; }
        public PositionRuleViolationDirection? ViolationDirection { get; set; }
        public bool IsWrong { get; set; }
    }

    private Dictionary<int, ConcurrentStack<BufferRecord>> _buffer = new();

    public void Add(int playerId, DateTime timestamp, PositionRuleViolationDirection? violationDirection, bool isWrong)
    {
        if (!_buffer.ContainsKey(playerId))
        {
            _buffer.Add(playerId, new ConcurrentStack<BufferRecord>());
        }

        _buffer[playerId].Push(new() { PlayerId = playerId, TimeStamp = timestamp, ViolationDirection = violationDirection, IsWrong = isWrong});
    }

    public bool IsEmpty() => _buffer.Count == 0;

    public Dictionary<int, ConcurrentStack<BufferRecord>> Get() => _buffer;
}