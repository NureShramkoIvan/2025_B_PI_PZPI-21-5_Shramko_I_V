using FootballGuru.Camera.App.Configuration;

namespace FootballGuru.Camera.App.Processors;

public class ContoursBufferItem
{
    public Point LeftMark { get; set; }
    public Point ColorMark { get; set; }
    public Point RightMark { get; set; }
    public string Color { get; set; }
}

public enum ContourPosition
{
    Left,
    Color,
    Right
}

public class ContoursBuffer(ContoursBufferConfiguration configuration)
{
    private readonly List<ContoursBufferItem> _buffer = new();

    public void Add(ContoursBufferItem item)
    {
        if (_buffer.Where(item => item.Color == item.Color).Count() >= configuration.BufferSize)
        {
            throw new InvalidOperationException("Buffer is full");
        }

        _buffer.Add(item);
    }

    public void Clear()
    {
        _buffer.Clear();
    }

    public bool IsLimitReached(string color)
    {
        return _buffer.Where(item => item.Color == color).Count() == configuration.BufferSize;
    }

    public double GetAverageXCoordinateValue(string color, ContourPosition position)
    {
        if (_buffer.Count < configuration.BufferSize)
        {
            throw new InvalidOperationException("Buffer is not full");
        }

        return position switch
        {
            ContourPosition.Left => _buffer.Where(item => item.Color == color).Average(item => item.LeftMark.X),
            ContourPosition.Color => _buffer.Where(item => item.Color == color).Average(item => item.ColorMark.X),
            ContourPosition.Right => _buffer.Where(item => item.Color == color).Average(item => item.RightMark.X),
            _ => throw new ArgumentException("Invalid contour position", nameof(position))
        };
    }
}
