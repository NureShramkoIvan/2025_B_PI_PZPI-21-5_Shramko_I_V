using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using FootballGuru.Camera.App.Configuration;
using FootballGuru.Camera.App.Queues;
using FootballGuru.Camera.App.Services;
using FootballGuru.Camera.App.States;
using System.Diagnostics;

namespace FootballGuru.Camera.App.Processors;

public class PlayerDetectionConfiguration
{
    public string Color { get; set; }
    public int PlayerId { get; set; }
    public double DistanceToValidateLeft { get; set; }
    public double DistanceToValidateRight { get; set; }
}

public class ImageProcessor(
    ColorService colorService,
    ContourService contourService,
    ContoursBuffer contoursBuffer,
    DistanceService distanceService,
    FieldSizeConfiguration fieldSizeConfiguration,
    TrainingState trainingState,
    PlayerPositionsQueue playerPositionsQueue)
{
    public void Process(byte[] imageBytes, int width, int height, string cameraPosition)
    {
        try
        {
            var playerConfigurations = GetPlayerConfigurations(cameraPosition);
            
            using var hsvObjectMat = CreateHSVObjectMat(imageBytes, width, height);

            using var blackMask = SetupBlackMask(hsvObjectMat);
            using var blackContours = new VectorOfVectorOfPoint();
            
            CvInvoke.FindContours(blackMask, blackContours, null, RetrType.External, ChainApproxMethod.ChainApproxSimple);
            
            var blackCenters = contourService.FindNlargestContourCenters(blackContours, 2);
            var (leftMark, rightMark) = DefineLeftAndRightMarks(blackCenters);
            
            foreach (var playerConfiguration in playerConfigurations)   
            {
                using var colorMask = SetupColorMask(hsvObjectMat, playerConfiguration.Color);
                using var colorContours = new VectorOfVectorOfPoint();

                CvInvoke.FindContours(colorMask, colorContours, null, RetrType.External, ChainApproxMethod.ChainApproxSimple);
                
                Point colorCenter = contourService.FindLargestContourCenter(colorContours);

                if (IsColorMarkValid(colorCenter))
                {
                    if (!contoursBuffer.IsLimitReached(playerConfiguration.Color))
                    {
                        contoursBuffer.Add(new ContoursBufferItem() { LeftMark = leftMark, ColorMark = colorCenter, RightMark = rightMark, Color = playerConfiguration.Color });
                    }
                    else
                    {
                        //TODO: add to state
                        var (distanceLeftMeters, distanceRightMeters) = CalculateDistance(playerConfiguration.Color);
                        Debug.WriteLine($"color: {playerConfiguration.Color} | l: {distanceLeftMeters} | r: {distanceRightMeters}");

                        playerPositionsQueue.Enqueue(new PlayerPositionsQueueItem() 
                        { 
                            PlayerId = playerConfiguration.PlayerId,
                            DistanceLeftActual = distanceLeftMeters * 100,
                            DistanceRightActual = distanceRightMeters * 100,
                            DistanceRightExpected = playerConfiguration.DistanceToValidateRight,
                            DistanceLeftExpected = playerConfiguration.DistanceToValidateLeft,
                            DimensionToTrack = cameraPosition == "X" ? Enums.DimensionToTrack.Width : Enums.DimensionToTrack.Height,
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(ex.Message);
        }
    }

    private (Point leftMark, Point rightMark) DefineLeftAndRightMarks(List<Point> blackCenters)
    {
        blackCenters = blackCenters.OrderBy(c => c.X).ToList();
        return (blackCenters[0], blackCenters[1]);
    }

    private Mat CreateHSVObjectMat(byte[] imageBytes, int width, int height)
    {
        using var objectMat = new Mat(height, width, Emgu.CV.CvEnum.DepthType.Cv8U, 3);
        objectMat.SetTo(imageBytes);

        var hsvObjectMat = new Mat();
        CvInvoke.CvtColor(objectMat, hsvObjectMat, ColorConversion.Bgr2Hsv);

        return hsvObjectMat;
    }

    private Mat SetupColorMask(Mat hsvMat, string colorToDetect)
    {
        var bgrColor = colorService.HexToBgr(colorToDetect);

        var hsvColor = colorService.ConvertBgrToHsv(bgrColor);

        var (upperHsv, lowerHsv) = colorService.GetColorThreshold(hsvColor);

        var colorMask = new Mat();
        CvInvoke.InRange(
            hsvMat,
            new ScalarArray(new MCvScalar(lowerHsv.H, lowerHsv.S, lowerHsv.V)),
            new ScalarArray(new MCvScalar(upperHsv.H, upperHsv.S, upperHsv.V)), colorMask);

        return colorMask;
    }

    private Mat SetupBlackMask(Mat hsvMat)
    {
        var lowerBlack = new MCvScalar(0, 0, 0);
        var upperBlack = new MCvScalar(180, 255, 50);

        var blackMask = new Mat();
        CvInvoke.InRange(hsvMat, new ScalarArray(lowerBlack), new ScalarArray(upperBlack), blackMask);

        return blackMask;
    }

    private bool IsColorMarkValid(Point colorCenter)
    {
        return colorCenter.X != 0;
    }

    private (double distanceLeftMeters, double distanceRightMeters) CalculateDistance(string color)
    {
        var leftXAverage = contoursBuffer.GetAverageXCoordinateValue(color, ContourPosition.Left);
        var rightXAverage = contoursBuffer.GetAverageXCoordinateValue(color, ContourPosition.Right);
        var objectXAverage = contoursBuffer.GetAverageXCoordinateValue(color, ContourPosition.Color);

        var dx1 = Math.Abs(objectXAverage - leftXAverage);
        var dx2 = Math.Abs(rightXAverage - objectXAverage);

        contoursBuffer.Clear();

        return distanceService.CalculateDistance(dx1, dx2, fieldSizeConfiguration.WidthMeters);
    }

    private List<PlayerDetectionConfiguration> GetPlayerConfigurations(string cameraPosition)
    {
        return Enumerable.Concat(trainingState.TrainingDetails.TeamA.Players, trainingState.TrainingDetails.TeamB.Players)
            .Select(p => new PlayerDetectionConfiguration()
            {
                PlayerId = p.PlayerId,
                Color = p.ColorHex,
                DistanceToValidateLeft = cameraPosition == "X" ? p.Zone.LeftDistanceCm : p.Zone.BottomDistanceCm,
                DistanceToValidateRight = cameraPosition == "X" ? p.Zone.RightDistanceCm : p.Zone.TopDistanceCm
            }).ToList();
    }
}
