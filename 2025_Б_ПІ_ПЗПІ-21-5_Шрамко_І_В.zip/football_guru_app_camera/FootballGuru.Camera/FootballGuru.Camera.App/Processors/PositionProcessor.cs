﻿using FootballGuru.Camera.App.Enums;

namespace FootballGuru.Camera.App.Processors;

public class PositionProcessor(InvalidPositionsBuffer invalidPositionsBuffer)
{
    public void Process(
        int playerId, 
        double distanceLeftExpected, 
        double distanceRightExpected, 
        double distanceLeftActual, 
        double distanceRightActual,
        DimensionToTrack dimensionToTrack)
    {
        if (distanceLeftActual < distanceLeftExpected)
        {
            invalidPositionsBuffer.Add(playerId, DateTime.UtcNow, dimensionToTrack == DimensionToTrack.Width
                ? PositionRuleViolationDirection.Left
                : PositionRuleViolationDirection.Bottom, true);

            return;
        }
        else if (distanceRightActual < distanceRightExpected)
        {
            invalidPositionsBuffer.Add(playerId, DateTime.UtcNow, dimensionToTrack == DimensionToTrack.Width
                ? PositionRuleViolationDirection.Right
                : PositionRuleViolationDirection.Top, true);

            return;
        }
        else 
        {
            invalidPositionsBuffer.Add(playerId, DateTime.UtcNow, null, false);
        }
    }
}
