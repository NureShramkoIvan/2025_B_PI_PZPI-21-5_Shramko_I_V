using FootballGuru.Camera.App.Infrastructure;
using FootballGuru.Camera.App.States;

namespace FootballGuru.Camera.App.Pages;

public partial class StartPage : ContentPage
{
    private readonly IWifiDirect _wifi;
    private readonly TrainingState _trainingState;
    private readonly MessagingService _messagingService;

    public StartPage(IWifiDirect wifi, TrainingState trainingState, MessagingService messagingService)
    {
        InitializeComponent();
        _wifi = wifi;
        _trainingState = trainingState;
        _messagingService = messagingService;
        //CameraPositionPicker.SelectedIndex = 0; // Set default selection to X
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _wifi.StartAsync();           // only sets up broadcast receiver
    }

    private async void OnStartButtonClicked(object sender, EventArgs e)
    {
//        if (CameraPositionPicker.SelectedItem == null)
//        {
//            await DisplayAlert("Error", "Please select a camera position", "OK");
//            return;
//        }

//        var cameraPosition = CameraPositionPicker.SelectedItem.ToString();
//        var navigationParameters = new Dictionary<string, object>
//        {
//            { "CameraPosition", cameraPosition }
//        };
//
        //if (!IsTrainingConfigSet)
        //{


            //mock
            //await Shell.Current.GoToAsync(nameof(CameraPage), navigationParameters);

            //actual code
            var cam = await Permissions.CheckStatusAsync<Permissions.Camera>();
            if (cam != PermissionStatus.Granted)
                cam = await Permissions.RequestAsync<Permissions.Camera>();
            
            // **location is mandatory for WifiP2p discovery**
            var loc = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (loc != PermissionStatus.Granted)
                loc = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            
            var status = await Permissions.CheckStatusAsync<Permissions.NearbyWifiDevices>();
            if (status != PermissionStatus.Granted)
                status = await Permissions.RequestAsync<Permissions.NearbyWifiDevices>();
            
            if (cam != PermissionStatus.Granted || loc != PermissionStatus.Granted || status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permissions required",
                    "Camera + location permissions are required for P2P discovery.",
                    "OK");
                return;
            }
            
            // 1) discover + connect to GO the trainer just created
            var serverEp = await _wifi.ConnectAsync();      // returns when info is available
            
            if (serverEp == null)
            {
                await DisplayAlert("Error", "WI-FI direct hub not found", "OK");
                return;
            }

            await _messagingService.ConnectAsync(serverEp);

            var ackMessage = new Message<string>()
            {
                Type = MessageTypes.ACK,
                Data = AllowedPeers.CAMERA
            };

            await _messagingService.SendMessage(ackMessage);

        await DisplayAlert("Info", "Sent ack", "OK");

        //}
        //else
        //{
        //    await DisplayAlert("Camera", $"Config received – ready to capture!\nTraining ID: {_trainingState.TrainingDetails.Id}", "OK");
        //    await Shell.Current.GoToAsync(nameof(CameraPage), navigationParameters);
        //}

        //// 2) pull the JSON training package
        //var bytes = await _wifi.ReceiveAsync(expectedBytes: 0); // block until trainer sends
        //var json = Encoding.UTF8.GetString(bytes);
        //
        //// 3) store the config in our state
        //_trainingState.UpdateFromJson(json);
        //
    }

    protected override void OnDisappearing()
    {
        _wifi.Stop();
        base.OnDisappearing();
    }
} 