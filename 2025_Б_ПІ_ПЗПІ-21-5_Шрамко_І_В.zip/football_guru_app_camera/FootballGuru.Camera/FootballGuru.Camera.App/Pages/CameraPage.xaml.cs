using FootballGuru.Camera.App.Queues;
using FootballGuru.Camera.App.Services;

namespace FootballGuru.Camera.App.Pages;

[QueryProperty(nameof(CameraPosition), "CameraPosition")]
public partial class CameraPage : ContentPage
{
    private readonly BgrBytesQueue _bgrBytesQueue;
    private string _cameraPosition;

    public CameraPage(BgrBytesQueue bgrBytesQueue)
    {
        InitializeComponent();
        cameraPreview.BgrFrameAvailable += OnBgrFrameAvailable;
        _bgrBytesQueue = bgrBytesQueue;
    }

    public string CameraPosition { get => _cameraPosition; set { _cameraPosition = value; } }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // Get the camera position from navigation parameters
//        if (Shell.Current.CurrentState.Location.OriginalString.Contains("CameraPage"))
//        {
//            var parameters = Shell.Current.CurrentState.Location.OriginalString
//                .Split('?')[1]
//                .Split('&')
//                .Select(p => p.Split('='))
//                .ToDictionary(p => p[0], p => p[1]);
//
//            if (parameters.TryGetValue("CameraPosition", out var position))
//            {
//                _cameraPosition = position;
//                Title = $"Camera ({_cameraPosition})";
//            }
//        }

        // Check camera permissions, etc.
        await CheckPermissionsAsync();
    }

    private async Task CheckPermissionsAsync()
    {
        var status = await Permissions.CheckStatusAsync<Permissions.Camera>();
        if (status != PermissionStatus.Granted)
        {
            status = await Permissions.RequestAsync<Permissions.Camera>();
            if (status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission required", "Camera permission is required.", "OK");
                return;
            }
        }
        // Microphone permission if you plan to do audio or video recording
    }

    private void OnFrameUpdated(object sender, EventArgs e)
    {
        // This is just a quick debug signal to prove frames are coming in
        // For instance, we can log a message or update the UI
        //System.Diagnostics.Debug.WriteLine("FrameUpdated event: camera feed is alive!");
    }

    private void OnBgrFrameAvailable(object sender, (int width, int height, byte[] bgrBytes) data)
    {
        _bgrBytesQueue.Enqueue(new BgrBytesQueueItem() {Width = data.width, Height = data.height, BgrBytes = data.bgrBytes, CameraPosition = _cameraPosition});
    }
}