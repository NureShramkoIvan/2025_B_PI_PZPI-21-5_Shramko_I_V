using FootballGuru.Camera.App.States;

namespace FootballGuru.Camera.App.Pages;

public partial class ConfigureCameraPage : ContentPage
{
    private readonly TrainingState _trainingState;

    public ConfigureCameraPage(TrainingState trainingState)
    {
		InitializeComponent();
        _trainingState = trainingState;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        //DisplayAlert("Camera", $"Config received � ready to capture!\nTraining ID: {_trainingState.TrainingDetails.Id}", "OK");
    }

    private async void OnStartButtonClicked(object sender, EventArgs e)
	{
        if (CameraPositionPicker.SelectedItem == null)
        {
            await DisplayAlert("Error", "Please select a camera position", "OK");
            return;
        }

        var cameraPosition = CameraPositionPicker.SelectedItem.ToString();
        var navigationParameters = new Dictionary<string, object>
        {
            { "CameraPosition", cameraPosition }
        };

        await Shell.Current.GoToAsync(nameof(CameraPage), navigationParameters);
    }
}