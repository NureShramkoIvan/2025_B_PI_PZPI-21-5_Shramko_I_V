using Emgu.CV;
using Emgu.CV.CvEnum;
using FootballGuru.Camera.App.Configuration;

namespace FootballGuru.Camera.App.Services;

public class BGRColor
{
    public byte B { get; set; }
    public byte G { get; set; }
    public byte R { get; set; }
}

public class HSVColor
{
    public byte H { get; set; }
    public byte S { get; set; }
    public byte V { get; set; }
}

public class ColorService(ColorThresholdConfiguration colorThresholdConfiguration)
{
    public BGRColor HexToBgr(string hex)
    {
        // Example: #FDEE00 (a bright yellow-like color)
        // Strip '#' if present
        hex = hex.Replace("#", "");

        // Convert to int
        int rgb = int.Parse(hex, System.Globalization.NumberStyles.HexNumber);

        // Extract R, G, B from integer
        byte r = (byte)((rgb >> 16) & 0xFF);
        byte g = (byte)((rgb >> 8) & 0xFF);
        byte b = (byte)((rgb) & 0xFF);

        // Now you have R, G, B channels
        //System.Diagnostics.Debug.WriteLine($"Parsed color: R={r}, G={g}, B={b}");

        return new() { B = b, G = g, R = r };
    }

    public HSVColor ConvertBgrToHsv(BGRColor bgrColor)
    {
        // Create a 1x1 Mat with our BGR color
        Mat bgrMat = new(1, 1, DepthType.Cv8U, 3);
        bgrMat.SetTo([bgrColor.B, bgrColor.G, bgrColor.R]);

        // Convert that single pixel to HSV
        Mat hsvMat = new();
        CvInvoke.CvtColor(bgrMat, hsvMat, ColorConversion.Bgr2Hsv);

        // Extract the HSV values
        // .GetData() will return a byte[] with the HSV channels
        var data = hsvMat.GetData();

        //var l = data.Length;

        byte[,,] hsvData = (byte[,,])data;
        //data.CopyTo(hsvData, 0);

        byte H = hsvData[0,0,0];
        byte S = hsvData[0,0,1];
        byte V = hsvData[0,0,2];

        //System.Diagnostics.Debug.WriteLine($"Parsed color: H={H}, S={S}, V={V}");

        return new() { H = H, S = S, V = V };
    }

    public (HSVColor upperHsv, HSVColor lowerHsv) GetColorThreshold(HSVColor hsvColor)
    {
        double baseH = hsvColor.H;
        double baseS = hsvColor.S;
        double baseV = hsvColor.V;

        // You might give some tolerance:
        double hTolerance = colorThresholdConfiguration.HueThreshold;
        double sTolerance = colorThresholdConfiguration.SaturationThreshold;
        double vTolerance = colorThresholdConfiguration.ValueThreshold;

        var lowerHsv = new HSVColor 
        { 
            H = (byte)Math.Max(baseH - hTolerance, 0),
            S = (byte)Math.Max(baseS - sTolerance, 0),
            V = (byte)Math.Max(baseV - vTolerance, 0)
        };

        var upperHsv = new HSVColor 
        { 
            H = (byte)Math.Min(baseH + hTolerance, 179),
            S = (byte)Math.Min(baseS + sTolerance, 255),
            V = (byte)Math.Min(baseV + vTolerance, 255)
        };

        return (upperHsv, lowerHsv);
    }
}

