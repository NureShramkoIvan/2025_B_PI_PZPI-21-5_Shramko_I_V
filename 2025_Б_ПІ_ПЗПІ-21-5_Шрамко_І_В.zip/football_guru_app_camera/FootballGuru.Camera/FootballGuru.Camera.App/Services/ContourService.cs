using Emgu.CV;
using Emgu.CV.Util;

namespace FootballGuru.Camera.App.Services;

public class ContourService
{
    public Point FindLargestContourCenter(VectorOfVectorOfPoint contours)
    {
        double largestArea = 0.0;
        Point bestCenter = new Point(0, 0);

        for (int i = 0; i < contours.Size; i++)
        {
            double area = CvInvoke.ContourArea(contours[i]);
            if (area > largestArea)
            {
                largestArea = area;

                // Compute bounding rect or moments
                var M = CvInvoke.Moments(contours[i]);
                int cx = (int)(M.M10 / (M.M00 + 1e-5));
                int cy = (int)(M.M01 / (M.M00 + 1e-5));

                bestCenter = new Point(cx, cy);
            }
        }

        return bestCenter;
    }

    public List<Point> FindNlargestContourCenters(VectorOfVectorOfPoint contours, int n)
    {
        // 1) Build a list of (area, index)
        var areas = new List<(double area, int idx)>();
        for (int i = 0; i < contours.Size; i++)
        {
            double area = CvInvoke.ContourArea(contours[i]);
            areas.Add((area, i));
        }

        // 2) Sort descending by area
        areas.Sort((a, b) => b.area.CompareTo(a.area));

        // 3) Now pick up to n largest
        var centers = new List<Point>();
        for (int i = 0; i < Math.Min(n, areas.Count); i++)
        {
            int contourIndex = areas[i].idx;
            var M = CvInvoke.Moments(contours[contourIndex]);
            int cx = (int)(M.M10 / (M.M00 + 1e-5));
            int cy = (int)(M.M01 / (M.M00 + 1e-5));

            centers.Add(new Point(cx, cy));
        }

        return centers;
    }
}
