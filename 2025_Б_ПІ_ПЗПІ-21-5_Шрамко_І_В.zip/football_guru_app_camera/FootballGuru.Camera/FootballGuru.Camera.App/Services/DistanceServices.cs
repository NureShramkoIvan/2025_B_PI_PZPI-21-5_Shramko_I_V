using FootballGuru.Camera.App.Configuration;

namespace FootballGuru.Camera.App.Services;

public class DistanceService
{
    public (double distanceLeftMe, double right) CalculateDistance(double dx1, double dx2, double c)
    {
        var distanceLeft = Math.Sqrt(dx1 * dx1);
        var distanceRight = Math.Sqrt(dx2 * dx2);

        System.Diagnostics.Debug.WriteLine($"Distance left pixels: {distanceLeft}");
        System.Diagnostics.Debug.WriteLine($"Distance right pixels: {distanceRight}");

        var distanceLeftMeters = PixelToMeters(distanceLeft, distanceLeft + distanceRight, c);
        var distanceRightMeters = PixelToMeters(distanceRight, distanceLeft + distanceRight, c);

        distanceLeftMeters = Math.Round(distanceLeftMeters, 2, MidpointRounding.AwayFromZero);
        distanceRightMeters = Math.Round(distanceRightMeters, 2, MidpointRounding.AwayFromZero);

        System.Diagnostics.Debug.WriteLine($"Distance left meters: {distanceLeftMeters}");
        System.Diagnostics.Debug.WriteLine($"Distance right meters: {distanceRightMeters}");

        return (distanceLeftMeters, distanceRightMeters);
    }

    private double PixelToMeters(double d, double dSum, double c)
    {
        return d / dSum * c;
    }

}
