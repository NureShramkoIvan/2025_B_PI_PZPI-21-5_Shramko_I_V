﻿using System.Diagnostics;
using System.Text.Json;

namespace FootballGuru.Camera.App.Infrastructure;

public class MessagesHandler(IServiceProvider serviceProvider)
{
    private StreamReader _streamReader;
    private List<(string MessageType, Type HandlerType)> _handlers = [];

    public void Start(StreamReader streamReader)
    {
        _streamReader = streamReader;
        Task.Run(Handle);
    }

    public void RegisterHandler(string messageType, Type handlerType)
    {
        _handlers.Add((messageType, handlerType));
    }

    public async Task Handle()
    {
        while (true)
        {
            var messageJson = _streamReader.ReadLineAsync().Result;

            if (messageJson is null)
            {
                //Debug.WriteLine($"Message is empty");
                continue;
            }

            try
            {
                var messageBase = JsonSerializer.Deserialize<MessageBase>(messageJson);

                var handlerType = _handlers.FirstOrDefault(h => h.MessageType == messageBase.Type).HandlerType;

                if (handlerType is null)
                {
                    Debug.WriteLine($"No handler for message | {messageBase.Type}");
                    continue;
                }

                IMessageHandler handler = (IMessageHandler)serviceProvider.GetRequiredService(handlerType);

                await handler.Handle(messageJson).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to parse message | {ex}");
            }
        }
    }
}
