﻿namespace FootballGuru.Camera.App.Infrastructure;

public static class MessageTypes
{
    public const string ACK = "ACK";
    public const string TRAINING_CONFIG = "TRAINING_CONFIG";
    public const string POSITION_VIOLATION = "POSITION_VIOLATION";
}
