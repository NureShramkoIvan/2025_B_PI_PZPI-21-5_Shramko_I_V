﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Camera.App.Infrastructure.Messages;

public class PositionViolationMessage
{
    public int PlayerId { get; set; }
    public int Direction { get; set; }
}
