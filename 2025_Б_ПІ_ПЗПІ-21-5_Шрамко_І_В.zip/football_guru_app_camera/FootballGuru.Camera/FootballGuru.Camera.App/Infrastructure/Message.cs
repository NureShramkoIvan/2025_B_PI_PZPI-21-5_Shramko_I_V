﻿namespace FootballGuru.Camera.App.Infrastructure;

public class Message<TData> : MessageBase
{
    public TData Data { get; set; }
}

public class MessageBase
{
    public string Type { get; set; }
}
