﻿using CommunityToolkit.Maui.Core.Primitives;
using FootballGuru.Camera.App.Models;
using FootballGuru.Camera.App.Pages;
using FootballGuru.Camera.App.States;
using System.Text.Json;

namespace FootballGuru.Camera.App.Infrastructure.Handlers;

internal class TrainingConfigurationMessageHandler(TrainingState trainingState) : IMessageHandler
{
    public async Task Handle(string messageJson)
    {
        var message = JsonSerializer.Deserialize<Message<TrainingDetailsModel>>(messageJson);

        trainingState.Set(message.Data);

        //var navigationParameters = new Dictionary<string, object>
        //{
        //    { "IsTrainingConfigSet", true }
        //};

        //await Shell.Current.GoToAsync(nameof(StartPage), navigationParameters);
        await MainThread.InvokeOnMainThreadAsync(() =>
            Shell.Current.GoToAsync(nameof(ConfigureCameraPage))
        ).ConfigureAwait(false);
    }
}
