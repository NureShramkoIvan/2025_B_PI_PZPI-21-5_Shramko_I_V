﻿using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace FootballGuru.Camera.App.Infrastructure;

public class MessagingService(MessagesHandler messagesHandler)
{
    private readonly TcpClient _tcpClient = new();
    private NetworkStream _stream;
    private StreamWriter _writer;
    private bool _isConnected = false;

    public async Task ConnectAsync(IPEndPoint endPoint)
    {
        await _tcpClient.ConnectAsync(endPoint.Address, endPoint.Port);
        _stream = _tcpClient.GetStream();
        var reader = new StreamReader(_stream, Encoding.UTF8, false, leaveOpen: true);
        _writer = new StreamWriter(_stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };

        if (_stream is not null)
        {
            messagesHandler.Start(reader);
            Debug.WriteLine("Started handlers");
        }
        else
        {
            Debug.WriteLine("Failed to get stream");
        }

        _isConnected = true;
    }

    public async Task SendMessage<TMessageData>(Message<TMessageData> message)
    {
        var messageJson = JsonSerializer.Serialize(message);

        await _writer.WriteLineAsync(messageJson);
    }

    public bool IsConnected() => _isConnected;
}
