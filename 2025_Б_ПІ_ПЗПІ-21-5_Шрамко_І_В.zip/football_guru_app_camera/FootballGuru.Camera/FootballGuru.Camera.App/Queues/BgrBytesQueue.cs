
using System.Collections.Concurrent;

namespace FootballGuru.Camera.App.Queues;

public class BgrBytesQueue
{
    private readonly object _lock = new();
    private readonly Queue<BgrBytesQueueItem> _queue = new();

    public void Enqueue(BgrBytesQueueItem item)
    {
        lock (_lock)
        {
            _queue.Enqueue(item);
        }
        System.Diagnostics.Debug.WriteLine($"BgrBytesQueue: {_queue.Count}");
    }

    public BgrBytesQueueItem Dequeue()
    {
        lock (_lock)
        {
            var isSuccess = _queue.TryDequeue(out var item);
            return isSuccess ? item : null;
        }
    }
}

public class BgrBytesQueueItem
{
    public byte[] BgrBytes { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public string CameraPosition { get; set; }
}
