
using FootballGuru.Camera.App.Processors;

namespace FootballGuru.Camera.App.Queues;

public class BgrBytesQueueConsumer(BgrBytesQueue bgrBytesQueue, ImageProcessor imageProcessor)
{
    public void Start() => Task.Run(Consume);

    private void Consume()
    {
        while (true)
        {
            var item = bgrBytesQueue.Dequeue();
            if (item == null) continue;

            imageProcessor.Process(item.BgrBytes, item.Width, item.Height, item.CameraPosition);
        }
    }
}
