﻿using FootballGuru.Camera.App.Processors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Camera.App.Queues;

public class PlayerPositionsQueueConsumer(PlayerPositionsQueue positionsQueue, PositionProcessor positionProcessor)
{
    public void Start() => Task.Run(Consume);

    private void Consume()
    {
        while (true)
        {
            var item = positionsQueue.Dequeue();
            if (item == null) continue;

            positionProcessor.Process(
                item.PlayerId,
                item.DistanceLeftExpected,
                item.DistanceRightExpected,
                item.DistanceLeftActual,
                item.DistanceRightActual,
                item.DimensionToTrack);
        }
    }

}
