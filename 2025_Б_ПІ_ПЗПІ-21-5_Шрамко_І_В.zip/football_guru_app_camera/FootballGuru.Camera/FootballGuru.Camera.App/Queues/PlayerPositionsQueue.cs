﻿using FootballGuru.Camera.App.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Camera.App.Queues;

public class PlayerPositionsQueue
{
    private readonly object _lock = new();
    private readonly Queue<PlayerPositionsQueueItem> _queue = new();

    public void Enqueue(PlayerPositionsQueueItem item)
    {
        lock (_lock)
        {
            _queue.Enqueue(item);
        }
        System.Diagnostics.Debug.WriteLine($"BgrBytesQueue: {_queue.Count}");
    }

    public PlayerPositionsQueueItem Dequeue()
    {
        lock (_lock)
        {
            var isSuccess = _queue.TryDequeue(out var item);
            return isSuccess ? item : null;
        }
    }
}

public class PlayerPositionsQueueItem
{
    public int PlayerId { get; set; }
    public double DistanceLeftExpected { get; set; }
    public double DistanceRightExpected { get; set; }
    public double DistanceLeftActual { get; set; }
    public double DistanceRightActual { get; set; }
    public DimensionToTrack DimensionToTrack{ get; set; }
}
