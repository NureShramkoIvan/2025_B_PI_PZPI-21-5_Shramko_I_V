namespace FootballGuru.Camera.App.Configuration;

public class ColorThresholdConfiguration
{
    public byte HueThreshold { get; set; } = 10;
    public byte SaturationThreshold { get; set; } = 50;
    public byte ValueThreshold { get; set; } = 50;
}
