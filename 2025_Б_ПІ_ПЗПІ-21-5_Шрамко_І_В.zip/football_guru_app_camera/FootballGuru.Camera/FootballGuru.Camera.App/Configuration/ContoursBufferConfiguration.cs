namespace FootballGuru.Camera.App.Configuration;

public class ContoursBufferConfiguration
{
    public int BufferSize { get; set; } = 10;
}
