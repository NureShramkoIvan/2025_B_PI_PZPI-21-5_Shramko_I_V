namespace FootballGuru.Camera.App.Configuration;

public class FieldSizeConfiguration
{
    public double WidthMeters { get; set; } = 1;
    public double HeightMeters { get; set; } = 22;
}
