﻿using FootballGuru.Camera.App.Infrastructure;
using FootballGuru.Camera.App.Infrastructure.Messages;
using FootballGuru.Camera.App.Processors;
using System.Diagnostics;

namespace FootballGuru.Camera.App.Workers;

public class InvalidPositionNotificationsWorker(
    InvalidPositionsBuffer invalidPositionsBuffer,
    MessagingService messagingService)
{
    public void Start() => Task.Run(DoWork);

    private void DoWork()
    {
        while (true)
        {
            //TEST
            //Thread.Sleep(15_000);
            //
            //if (messagingService.IsConnected())
            //{
            //    Debug.WriteLine("Sending message");
            //    
            //    var message = new Message<PositionViolationMessage>()
            //    {
            //        Type = MessageTypes.POSITION_VIOLATION,
            //        Data = new() { Direction = new Random().Next(1,4), PlayerId = 7 }
            //    };
            //
            //    messagingService.SendMessage(message);
            //}
            //else
            //{
            //    Debug.WriteLine("not connected");
            //}

            var positionViolations = invalidPositionsBuffer.Get();
            
            foreach (var violation in positionViolations)
            {
                var records = violation.Value.ToList();
            
                //if (records.Count < 10) continue;
            
                var okCount = records.Where(x => !x.IsWrong).Count();
            
                var withMaxCount = records
                    .Where(x => x.IsWrong)
                    .GroupBy(r => r.ViolationDirection)
                    .Select(gr => 
                    (
                        Direction: gr.Key,
                        LastTimestamp: gr.MaxBy(x => x.TimeStamp).TimeStamp,
                        Count: gr.Count()
                    ))
                    .MaxBy(x => x.Count);
            
                if ((double)((double)withMaxCount.Count / okCount) * 100 > 80)
                {
                    Debug.WriteLine($"Player {violation.Key} violated position | dir: {withMaxCount.Direction}");

                    if (messagingService.IsConnected())
                    {
                        var message = new Message<PositionViolationMessage>()
                        {
                            Type = MessageTypes.POSITION_VIOLATION,
                            Data = new() { Direction = (int)withMaxCount.Direction, PlayerId = violation.Key }
                        };

                        messagingService.SendMessage(message);
                    }   
                }
                else
                {
                    Debug.WriteLine($"Player {violation.Key} position OK | ratio: {withMaxCount.Count} / {okCount}");
                }
            
                violation.Value.Clear();
            }

            Thread.Sleep(45_000);
        }
    }
}
