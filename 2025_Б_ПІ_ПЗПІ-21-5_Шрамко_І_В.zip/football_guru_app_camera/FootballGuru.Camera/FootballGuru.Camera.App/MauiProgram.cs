﻿using FootballGuru.Camera.App.Configuration;
using FootballGuru.Camera.App.Controls;
using FootballGuru.Camera.App.Infrastructure;
using FootballGuru.Camera.App.Infrastructure.Handlers;
using FootballGuru.Camera.App.Pages;
using FootballGuru.Camera.App.Processors;
using FootballGuru.Camera.App.Queues;
using FootballGuru.Camera.App.Services;
using FootballGuru.Camera.App.States;
using FootballGuru.Camera.App.Workers;
#if ANDROID
using FootballGuru.Camera.App.Platforms.Android;
#endif
using Microsoft.Extensions.Logging;

namespace FootballGuru.Camera.App;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            //.UseMauiCommunityToolkitCamera()
            .ConfigureMauiHandlers(handlers =>
            {
#if ANDROID
                handlers.AddHandler(typeof(CameraPreview), typeof(CameraPreviewHandler));
#endif
            })
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

#if DEBUG
		builder.Logging.AddDebug();
#endif

        builder.Services.AddQueues();
        builder.Services.AddServices();

        builder.Services.AddPages();
        builder.Services.AddConfiguration();
        builder.Services.AddServices();
        builder.Services.AddProcessors();

        builder.Services.AddSingleton<MessagingService>();
        builder.Services.AddSingleton<TrainingConfigurationMessageHandler>();
        builder.Services.AddSingleton<MessagesHandler>((sp) => 
        {
            var messagesHandler = new MessagesHandler(sp);
            messagesHandler.RegisterHandler(MessageTypes.TRAINING_CONFIG, typeof(TrainingConfigurationMessageHandler));

            return messagesHandler;
        });

        var app = builder.Build();

        var bgrBytesQueueConsumer = app.Services.GetRequiredService<BgrBytesQueueConsumer>();
        bgrBytesQueueConsumer.Start();

        var playerPositionsQueueConsumer = app.Services.GetRequiredService<PlayerPositionsQueueConsumer>();
        playerPositionsQueueConsumer.Start();

        var invalidPositionNotificationsWorker = app.Services.GetRequiredService<InvalidPositionNotificationsWorker>();
        invalidPositionNotificationsWorker.Start();

        return app;
    }

}

public static class MauiAppBuilderExtensions
{
    public static void AddPages(this IServiceCollection services)
    {
        services.AddSingleton<CameraPage>();
        services.AddSingleton<StartPage>();
        services.AddSingleton<ConfigureCameraPage>();
    }

    public static void AddProcessors(this IServiceCollection services)
    {
        services.AddSingleton<ImageProcessor>();
        services.AddSingleton<ContoursBuffer>();
        services.AddSingleton<PositionProcessor>();
        services.AddSingleton<InvalidPositionsBuffer>();
    }

    public static void AddConfiguration(this IServiceCollection services)
    {
        services.AddSingleton<ColorThresholdConfiguration>();
        services.AddSingleton<ContoursBufferConfiguration>();
        services.AddSingleton<FieldSizeConfiguration>();
    }

    public static void AddServices(this IServiceCollection services)
    {
        services.AddSingleton<ColorService>();
        services.AddSingleton<DistanceService>();
        services.AddSingleton<ContourService>();

        services.AddSingleton<InvalidPositionNotificationsWorker>();

#if ANDROID
        services.AddPlatformServices();
#endif

        services.AddSingleton<TrainingState>();
    }

    public static void AddQueues(this IServiceCollection services)
    {
        services.AddSingleton<BgrBytesQueue>();
        services.AddSingleton<BgrBytesQueueConsumer>();
        services.AddSingleton<PlayerPositionsQueue>();
        services.AddSingleton<PlayerPositionsQueueConsumer>();
    }
}