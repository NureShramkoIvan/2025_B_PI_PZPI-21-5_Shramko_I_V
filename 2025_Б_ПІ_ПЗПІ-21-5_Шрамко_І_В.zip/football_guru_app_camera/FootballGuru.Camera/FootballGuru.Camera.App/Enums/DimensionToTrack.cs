namespace FootballGuru.Camera.App.Enums;

public enum DimensionToTrack
{
    Width = 1,
    Height = 2
}