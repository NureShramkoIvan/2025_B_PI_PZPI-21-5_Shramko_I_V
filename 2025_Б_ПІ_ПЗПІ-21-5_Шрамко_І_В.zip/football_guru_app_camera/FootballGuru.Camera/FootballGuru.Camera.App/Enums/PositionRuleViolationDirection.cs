﻿namespace FootballGuru.Camera.App.Enums;

public enum PositionRuleViolationDirection
{
    Top = 1,
    Bottom = 2,
    Left = 3,
    Right = 4,
}
