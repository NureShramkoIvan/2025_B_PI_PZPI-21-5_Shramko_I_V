using FootballGuru.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Route("formations")]
[Authorize]
public class FormationController(IFormationFacade formationFacade) : ApiController
{
    [HttpGet]
    public async Task<IActionResult> GetManyFormationsAsync(CancellationToken cancellationToken)
    {
        var getManyFormationsResult = await formationFacade.GetManyFormationsAsync(cancellationToken);
        return ToActionResult(getManyFormationsResult);
    }
} 