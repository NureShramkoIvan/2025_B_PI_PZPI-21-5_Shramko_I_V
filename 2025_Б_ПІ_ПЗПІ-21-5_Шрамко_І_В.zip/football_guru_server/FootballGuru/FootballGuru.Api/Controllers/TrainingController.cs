using AutoMapper;
using FootballGuru.Api.Requests.Trainings;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Trainings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Route("trainings")]
[Authorize]
public class TrainingController(
    ITrainingFacade trainingFacade,
    IMapper mapper) : ApiController
{
    [HttpPost]
    public async Task<IActionResult> CreateTrainingAsync(
        [FromBody] CreateTrainingRequest request, 
        CancellationToken cancellationToken)
    {
        var createTrainingDTO = mapper.Map<CreateTrainingDTO>(request);
        createTrainingDTO.TrainerId = UserId;

        var createTrainingResult = await trainingFacade.CreateTrainingAsync(
            createTrainingDTO, 
            cancellationToken);

        return ToActionResult(createTrainingResult);
    }

    [HttpGet]
    public async Task<IActionResult> GetManyTrainingsAsync(
        [FromQuery] GetManyTrainingsRequest request,
        CancellationToken cancellationToken)
    {
        var getManyTrainingsDTO = new GetManyTrainingsDTO
        {
            Skip = request.Skip,
            Limit = request.Limit,
            TrainerId = UserId
        };

        var getManyTrainingsResult = await trainingFacade.GetManyTrainingsAsync(
            getManyTrainingsDTO,
            cancellationToken);

        return ToActionResult(getManyTrainingsResult);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetTrainingByIdAsync(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        var getTrainingResult = await trainingFacade.GetTrainingByIdAsync(
            id,
            UserId,
            cancellationToken);

        return ToActionResult(getTrainingResult);
    }
} 