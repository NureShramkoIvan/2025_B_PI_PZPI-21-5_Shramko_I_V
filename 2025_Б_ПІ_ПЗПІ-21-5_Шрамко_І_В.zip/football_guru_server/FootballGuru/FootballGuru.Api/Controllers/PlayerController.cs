﻿using AutoMapper;
using FootballGuru.Api.Requests.Players;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Players;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Route("players")]
[Authorize]
public class PlayerController(
    IPlayerFacade playerFacade,
    IMapper mapper) : ApiController
{
    [HttpPost]
    public async Task<IActionResult> CreatePlayerAsync([FromBody] CreatePlayerRequest request, CancellationToken cancellationToken)
    {
        var createPlayerDTO = mapper.Map<CreatePlayerDTO>(request);

        createPlayerDTO.TrainerId = UserId;

        var createPlayerResult = await playerFacade.CreatePlayerAsync(createPlayerDTO, cancellationToken);
        return ToActionResult(createPlayerResult);
    }

    [HttpGet]
    public async Task<IActionResult> GetManyPlayersAsync([FromQuery] GetManyPlayersRequest request, CancellationToken cancellationToken)
    {
        Console.WriteLine(UserId);
        var getManyPlayersResult = await playerFacade.GetManyPlayers(new() 
        { 
            Skip = request.Skip,
            Limit = request.Limit,
            TrainerId = UserId
        }, cancellationToken);

        return ToActionResult(getManyPlayersResult);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetPlayerByIdAsync([FromRoute] int id, CancellationToken cancellationToken)
    {

        Console.WriteLine(UserId);
        var getPlayerResult = await playerFacade.GetOnePlayerAsync(new GetOnePlayerDTO 
        { 
            PlayerId = id,
            TrainerId = UserId
        }, cancellationToken);


        return ToActionResult(getPlayerResult);
    }
}
