﻿using System.Security.Claims;
using FootballGuru.Application.Common;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Controller]
public class ApiController : ControllerBase
{
    public int UserId => int.Parse(((ClaimsIdentity)User.Identity).Claims.Single(c => c.Type == "user_id").Value);


    protected IActionResult ToActionResult(ServiceResponse serviceResponse)
    {
        return new ObjectResult(serviceResponse) { StatusCode = (int)serviceResponse.Status };
    }

    protected IActionResult ToActionResult<T>(ServiceResponse<T> serviceResponse)
    {
        return new ObjectResult(serviceResponse)
        { 
            StatusCode = (int)serviceResponse.Status,
            Value = serviceResponse 
        };
    }
}
