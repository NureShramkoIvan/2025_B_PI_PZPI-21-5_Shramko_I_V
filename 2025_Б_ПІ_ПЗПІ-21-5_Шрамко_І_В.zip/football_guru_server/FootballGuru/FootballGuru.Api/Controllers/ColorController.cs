using AutoMapper;
using FootballGuru.Api.Requests.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Route("colors")]
[Authorize]
public class ColorController(
    IColorFacade colorFacade,
    IMapper mapper) : ApiController
{
    [HttpGet]
    public async Task<IActionResult> GetManyColors([FromQuery] PageRequest request, CancellationToken cancellationToken)
    {
        var response = await colorFacade.GetManyAsync(
            new() { Skip = request.Skip, Limit = request.Limit }, 
            cancellationToken);
            
        return ToActionResult(response);
    }
} 