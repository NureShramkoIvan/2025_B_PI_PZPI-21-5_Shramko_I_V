using AutoMapper;
using FootballGuru.Api.Requests.Roles;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Roles;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Route("roles")]
public class RoleController(
    IRoleFacade roleFacade,
    IMapper mapper) : ApiController
{
    [HttpPost]
    public async Task<IActionResult> CreateRole([FromBody] CreateRoleRequest request, CancellationToken cancellationToken)
    {
        var response = await roleFacade.CreateAsync(mapper.Map<CreateRoleDTO>(request), cancellationToken);
        return ToActionResult(response);
    }

    [HttpGet]
    public async Task<IActionResult> GetManyRoles([FromQuery] GetManyRolesRequest request, CancellationToken cancellationToken)
    {
        var response = await roleFacade.GetManyAsync(mapper.Map<GetManyRolesDTO>(request), cancellationToken);
        return ToActionResult(response);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetOneRole([FromRoute] int id, CancellationToken cancellationToken)
    {
        var response = await roleFacade.GetOneAsync(new GetOneRoleDTO { RoleId = id }, cancellationToken);
        return ToActionResult(response);
    }

    [HttpPost("{roleId:int}/actions")]
    public async Task<IActionResult> CreateRoleAction([FromRoute] int roleId, [FromBody] CreateRoleActionRequest request, CancellationToken cancellationToken)
    {
        var response = await roleFacade.CreateRoleActionAsync(new CreateRoleActionDTO 
        { 
            RoleId = roleId,
            Action = request.Action
        }, cancellationToken);
        
        return ToActionResult(response);
    }

    [HttpDelete("{roleId:int}/actions/{actionId:int}")]
    public async Task<IActionResult> DeleteRoleAction([FromRoute] int roleId, [FromRoute] int actionId, CancellationToken cancellationToken)

    {
        var response = await roleFacade.DeleteRoleActionAsync(new DeleteRoleActionDTO 
        { 
            RoleId = roleId,
            ActionId = actionId
        }, cancellationToken);
        
        return ToActionResult(response);
    }
} 