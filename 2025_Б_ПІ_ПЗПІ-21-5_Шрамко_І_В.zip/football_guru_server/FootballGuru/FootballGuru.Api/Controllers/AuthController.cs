﻿using AutoMapper;
using FootballGuru.Api.Requests.Identity;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FootballGuru.Api.Controllers;

[Route("auth")]
public class AuthController(IAuthFacade authFacade, IMapper mapper) : ApiController
{
    [HttpPost("register")]
    public async Task<IActionResult> CreateUser([FromBody] CreateUserRequest request)
    {
        var serviceResponse = await authFacade.CreateUser(mapper.Map<CreateUserDTO>(request));

        return ToActionResult(serviceResponse);
    }

    [HttpPost("token")]
    public async Task<IActionResult> GetAccessToken([FromBody] GetAccessTokenRequest request)
    {
        var serviceResponse = await authFacade.GetAccessToken(mapper.Map<GetAccessTokenDTO>(request));
        return ToActionResult(serviceResponse);
    }
}
