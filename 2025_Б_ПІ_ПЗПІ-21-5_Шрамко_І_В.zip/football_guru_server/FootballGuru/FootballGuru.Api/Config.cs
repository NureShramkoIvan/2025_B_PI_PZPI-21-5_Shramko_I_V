﻿namespace FootballGuru.Api;

public static class Config
{
    public static string SqlServerConnection = "FootballGuruDb";
    public static string MongoDbConnection = "MongoDb";
    public static string Identity = "Identity";
}
