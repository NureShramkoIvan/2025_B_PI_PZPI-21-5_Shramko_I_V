﻿using FootballGuru.Application;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace FootballGuru.Api;

public static class DependencyModule
{
    public static IServiceCollection AddServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddApplication(
            configuration.GetSection(Config.SqlServerConnection).Value,
            configuration.GetSection(Config.MongoDbConnection).Value,
            configuration.GetSection(Config.Identity));
        services.AddAutoMapper(c => c.AddProfile(new ApiLayerMapperProfile()));

        services.ConfigureJwtAuth(configuration.GetSection(Config.Identity));
        services.AddDocumentation();

        return services;
    }

    private static IServiceCollection ConfigureJwtAuth(this IServiceCollection services, IConfigurationSection jwtSettings)
    {
        var issuer = jwtSettings["Issuer"];
        var secretKey = jwtSettings["SecretKey"];

        var tokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidateAudience = false,
            ValidIssuer = issuer,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey)),
            LifetimeValidator = (before, expires, _, _) => expires.Value > DateTime.UtcNow
        };

        services
            .AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = tokenValidationParameters;
                options.RequireHttpsMetadata = true;
            });

        return services;
    }
}
