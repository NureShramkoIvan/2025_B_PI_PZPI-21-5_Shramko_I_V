namespace FootballGuru.Api.Requests.Trainings;

public class GetManyTrainingsRequest
{
    public int? Skip { get; set; }
    public int? Limit { get; set; }
} 