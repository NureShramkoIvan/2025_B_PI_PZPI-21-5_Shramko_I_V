namespace FootballGuru.Api.Requests.Trainings;

public class CreateTrainingRequest
{
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public TeamConfigurationRequest TeamA { get; set; }
    public TeamConfigurationRequest TeamB { get; set; }
    
    public class TeamConfigurationRequest
    {
        public int FormationId { get; set; }
        public List<PlayerConfigurationRequest> Players { get; set; }
    }

    public class PlayerConfigurationRequest
    {
        public int PlayerId { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> CustomActions { get; set; }
        public ZoneConfigurationRequest Zone { get; set; }
        public int ColorId { get; set; }
    }

    public class ZoneConfigurationRequest
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    } 
}