﻿namespace FootballGuru.Api.Requests.Identity;

public class GetAccessTokenRequest
{
    public string UserName { get; set; }
    public string Password { get; set; }
}
