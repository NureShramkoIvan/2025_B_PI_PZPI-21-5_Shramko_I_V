﻿using FootballGuru.Api.Requests.Common;

namespace FootballGuru.Api.Requests.Players;

public class GetManyPlayersRequest : PageRequest
{
}
