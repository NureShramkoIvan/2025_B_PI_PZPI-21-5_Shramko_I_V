﻿namespace FootballGuru.Api.Requests.Common;

public class PageRequest
{
    public int? Skip { get; set; }
    public int? Limit { get; set; }
}
