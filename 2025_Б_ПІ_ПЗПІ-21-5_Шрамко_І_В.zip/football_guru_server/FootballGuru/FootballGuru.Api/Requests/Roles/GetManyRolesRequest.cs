using FootballGuru.Api.Requests.Common;

namespace FootballGuru.Api.Requests.Roles;

public class GetManyRolesRequest : PageRequest
{
}