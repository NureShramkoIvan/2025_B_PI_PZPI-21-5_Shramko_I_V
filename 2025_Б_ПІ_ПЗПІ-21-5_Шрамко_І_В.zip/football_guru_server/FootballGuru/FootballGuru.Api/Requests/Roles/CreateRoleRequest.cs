namespace FootballGuru.Api.Requests.Roles;

public class CreateRoleRequest
{
    public string Name { get; set; }
} 