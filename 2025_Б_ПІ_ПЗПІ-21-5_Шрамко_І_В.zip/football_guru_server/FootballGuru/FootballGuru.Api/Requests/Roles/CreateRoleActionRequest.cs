
namespace FootballGuru.Api.Requests.Roles;

public class CreateRoleActionRequest
{
    public string Action { get; set; }
}