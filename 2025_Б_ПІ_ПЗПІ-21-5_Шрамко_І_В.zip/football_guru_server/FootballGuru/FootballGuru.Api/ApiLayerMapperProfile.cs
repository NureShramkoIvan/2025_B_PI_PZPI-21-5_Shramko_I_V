﻿using AutoMapper;
using FootballGuru.Api.Requests.Identity;
using FootballGuru.Api.Requests.Players;
using FootballGuru.Api.Requests.Roles;
using FootballGuru.Api.Requests.Trainings;
using FootballGuru.Transport.DTOs.Identity;
using FootballGuru.Transport.DTOs.Players;
using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.DTOs.Trainings;

namespace FootballGuru.Api;

public class ApiLayerMapperProfile : Profile
{
    public ApiLayerMapperProfile()
    {
        CreateMap<CreateUserRequest, CreateUserDTO>();
        CreateMap<GetAccessTokenRequest, GetAccessTokenDTO>();

        CreateMap<CreatePlayerRequest, CreatePlayerDTO>();
        CreateMap<GetManyPlayersRequest, GetManyPlayersDTO>();

        CreateMap<CreateRoleRequest, CreateRoleDTO>();
        CreateMap<GetManyRolesRequest, GetManyRolesDTO>();

        CreateMap<CreateTrainingRequest, CreateTrainingDTO>();
        CreateMap<CreateTrainingRequest.TeamConfigurationRequest, CreateTrainingDTO.TeamConfigurationDTO>();
        CreateMap<CreateTrainingRequest.PlayerConfigurationRequest, CreateTrainingDTO.PlayerConfigurationDTO>();
        CreateMap<CreateTrainingRequest.ZoneConfigurationRequest, CreateTrainingDTO.ZoneConfigurationDTO>();
    }
}
