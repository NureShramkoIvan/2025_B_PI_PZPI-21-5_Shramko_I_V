﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Data.SqlServer.SqlServer;

internal class CommandDbConnection(string connectionString)
{
    public SqlConnection Connection { get; } = new SqlConnection(connectionString);
}
