﻿using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Data.SqlServer.Repositories;
using FootballGuru.Data.SqlServer.SqlServer;
using FootballGuru.Data.SqlServer.Transactions;
using Microsoft.Extensions.DependencyInjection;

namespace FootballGuru.Data.SqlServer;

public static class DependencyModule
{
    public static IServiceCollection AddDataAccess(this IServiceCollection services, string dbConnectionString)
    {
        services.AddScoped<IDataLayerTransactionFactory, DataLayerTransactionFactory>();
        services.AddScoped(c => new CommandDbConnection(dbConnectionString));
        services.AddTransient(c => new QueryDbConnection(dbConnectionString));

        services.AddScoped<ITrainerRepository, TrainerRepository>();
        services.AddScoped<IPlayerRepository, PlayerRepository>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<IColorRepository, ColorRepository>();
        
        return services;
    }
}
