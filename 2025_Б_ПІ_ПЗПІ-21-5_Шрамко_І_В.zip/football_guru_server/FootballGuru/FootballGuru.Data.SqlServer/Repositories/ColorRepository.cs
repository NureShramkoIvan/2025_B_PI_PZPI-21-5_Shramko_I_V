using System.Data;
using Dapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Data.SqlServer.SqlServer;
using FootballGuru.Domain;

namespace FootballGuru.Data.SqlServer.Repositories;

internal class ColorRepository(QueryDbConnection queryDbConnection) : IColorRepository
{
    private readonly IDbConnection _queryDbConnection = queryDbConnection.Connection;

    public async Task<IEnumerable<Color>> GetManyAsync(int? skip, int? limit, CancellationToken cancellationToken = default)
    {
        var sql = "SELECT * FROM colors ORDER BY id OFFSET @Skip ROWS FETCH NEXT @Limit ROWS ONLY";

        var commandDefinition = new CommandDefinition(
            sql, 
            new { Skip = skip ?? 0, Limit = limit ?? 100 }, 
            cancellationToken: cancellationToken);

        return await _queryDbConnection.QueryAsync<Color>(commandDefinition);
    }
} 