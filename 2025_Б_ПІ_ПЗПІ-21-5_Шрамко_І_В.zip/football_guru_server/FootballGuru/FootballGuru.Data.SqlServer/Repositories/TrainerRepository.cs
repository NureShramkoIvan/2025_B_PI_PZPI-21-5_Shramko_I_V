﻿using Dapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Data.SqlServer.SqlServer;
using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Domain;
using System.Data.Common;

namespace FootballGuru.Data.SqlServer.Repositories;

internal class TrainerRepository(
    CommandDbConnection commandDbConnection,
    QueryDbConnection queryDbConnection) : ITrainerRepository
{
    private readonly DbConnection _commandDbConnection = commandDbConnection.Connection;
    private readonly DbConnection _queryDbConnection = queryDbConnection.Connection;

    record TrainerRecord(int Id, string FirstName, string LastName, string UserName, string PasswordHash);

    public async Task CreateAsync(Trainer trainer, DataLayerTransaction transaction, CancellationToken cancellationToken)
    {
        //await _dbConnection.OpenAsync();

        var sql = @"
        INSERT INTO trainers (first_name, last_name, user_name, password_hash)
        VALUES (@FirstName, @LastName, @UserName, @PasswordHash)
    ";

        var commandDefinition = new CommandDefinition(
            sql,
            new
            {
                FirstName = trainer.FirstName,
                LastName = trainer.LastName,
                UserName = trainer.User.UserName,
                PasswordHash = trainer.User.PasswordHash
            },
            transaction: transaction.DbTransaction
        );

        await _commandDbConnection.ExecuteAsync(commandDefinition);

        //await _dbConnection.CloseAsync();
    }

    public async Task<Trainer> GetOneByUserName(string userName, CancellationToken cancellationToken = default)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
        SELECT 
            t.id AS Id,
            t.first_name AS FirstName,
            t.last_name AS LastName,
            t.user_name AS UserName,
            t.password_hash AS PasswordHash
        FROM trainers t
        WHERE t.user_name = @UserName
    ";

        var trainerData = await _queryDbConnection.QuerySingleOrDefaultAsync<TrainerRecord>(
            new CommandDefinition(
                sql,
                new { UserName = userName },
                cancellationToken: cancellationToken
            )
        );

        await _queryDbConnection.CloseAsync();

        if (trainerData == null) return null;

        var trainer = new Trainer(
            new User(
                userName: trainerData.UserName,
                passwordHash: trainerData.PasswordHash
            ),
            firstName: trainerData.FirstName,
            lastName: trainerData.LastName
        );

        trainer.Id = trainerData.Id;

        return trainer;
    }


    public async Task<bool> UserNameExistsAsync(
        string userName,
        CancellationToken cancellationToken = default)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
            SELECT CASE 
                WHEN EXISTS (
                    SELECT 1
                    FROM trainers
                    WHERE user_name = @UserName
                )
                THEN CAST(1 AS BIT)
                ELSE CAST(0 AS BIT)
            END
        ";

        var result = await _queryDbConnection.ExecuteScalarAsync<bool>(
            new CommandDefinition(
                sql,
                new { UserName = userName },
                cancellationToken: cancellationToken
            )
        );

        await _queryDbConnection.CloseAsync();

        return result;
    }

    public async Task<bool> ExistsAsync(int trainerId, CancellationToken cancellationToken)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
            SELECT 
                CASE 
                    WHEN EXISTS (SELECT 1 FROM trainers t WHERE t.id = @Id)
                    THEN 1 
                    ELSE 0 
                END
        ";

        var exists = await _queryDbConnection.QueryFirstOrDefaultAsync<bool>(
            new CommandDefinition(
                sql,
                new { Id = trainerId },
                cancellationToken: cancellationToken
            )
        );

        await _queryDbConnection.CloseAsync();

        return exists;
    }
}
