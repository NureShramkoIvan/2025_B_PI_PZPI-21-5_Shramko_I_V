﻿using Dapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Data.SqlServer.SqlServer;
using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Domain;
using System.Data.Common;

namespace FootballGuru.Data.SqlServer.Repositories;

internal class PlayerRepository(
    CommandDbConnection commandDbConnection,
    QueryDbConnection queryDbConnection) : IPlayerRepository
{
    private readonly DbConnection _commandDbConnection = commandDbConnection.Connection;
    private readonly DbConnection _queryDbConnection = queryDbConnection.Connection;

    public async Task CreateAsync(
        Player player,
        DataLayerTransaction transaction,
        CancellationToken cancellationToken = default)
    {
        var sql = @"
        INSERT INTO players (first_name, last_name, date_of_birth, trainer_id, role_id)
        VALUES (@FirstName, @LastName, @DateOfBirth, @TrainerId, @RoleId)
    ";

        var commandDefinition = new CommandDefinition(
            sql,
            new
            {
                FirstName = player.FirstName,
                LastName = player.LastName,
                DateOfBirth = player.DateOfBirth,
                TrainerId = player.TrainerId,
                RoleId = player.RoleId
            },
            transaction: transaction.DbTransaction,
            cancellationToken: cancellationToken
        );

        await _commandDbConnection.ExecuteAsync(commandDefinition);
    }

    public async Task<IEnumerable<Player>> GetManyAsync(
        int skip,
        int limit,
        int trainerId,
        CancellationToken cancellationToken = default)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
        SELECT id, first_name AS FirstName, last_name AS LastName, date_of_birth AS DateOfBirth, role_id AS RoleId
        FROM players
        WHERE trainer_id = @TrainerId
        ORDER BY id desc
        OFFSET @Skip ROWS FETCH NEXT @Limit ROWS ONLY
    ";

        var parameters = new
        {
            Skip = skip,
            Limit = limit,
            TrainerId = trainerId
        };

        var result = await _queryDbConnection.QueryAsync<Player>(
            new CommandDefinition(
                sql,
                parameters,
                cancellationToken: cancellationToken)
        );

        await _queryDbConnection.CloseAsync();

        return result;
    }

    public async Task<Player> GetByIdAsync(int playerId, int trainerId, CancellationToken cancellationToken = default)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
        SELECT id, first_name AS FirstName, last_name AS LastName, date_of_birth AS DateOfBirth, role_id AS RoleId
        FROM players
        WHERE id = @PlayerId AND trainer_id = @TrainerId
    ";

        var parameters = new
        {
            PlayerId = playerId,
            TrainerId = trainerId
        };

        var result = await _queryDbConnection.QueryFirstOrDefaultAsync<Player>(
            new CommandDefinition(sql, parameters, cancellationToken: cancellationToken));  

        await _queryDbConnection.CloseAsync();

        return result;
    }

    public async Task<bool> ExistsManyAsync(
        IEnumerable<int> ids,
        int trainerId,
        CancellationToken cancellationToken = default)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
        SELECT COUNT(*)
        FROM players
        WHERE id IN @Ids AND trainer_id = @TrainerId
    ";

        var parameters = new
        {
            Ids = ids,
            TrainerId = trainerId
        };

        var result = await _queryDbConnection.QueryFirstOrDefaultAsync<int>(
            new CommandDefinition(sql, parameters, cancellationToken: cancellationToken)
        );

        await _queryDbConnection.CloseAsync();

        return result > 0;
    }

    public async Task<List<Player>> GetManyByIdsAsync(
        IEnumerable<int> ids,
        int trainerId,
        CancellationToken cancellationToken = default)
    {
        await _queryDbConnection.OpenAsync(cancellationToken);

        var sql = @"
            SELECT id, first_name AS FirstName, last_name AS LastName, date_of_birth AS DateOfBirth, role_id AS RoleId
            FROM players
            WHERE id IN @Ids AND trainer_id = @TrainerId";

        var parameters = new
        {
            Ids = ids.ToArray(),
            TrainerId = trainerId
        };

        var result = await _queryDbConnection.QueryAsync<Player>(
            new CommandDefinition(sql, parameters, cancellationToken: cancellationToken));

        await _queryDbConnection.CloseAsync();

        return result.ToList();
    }
}