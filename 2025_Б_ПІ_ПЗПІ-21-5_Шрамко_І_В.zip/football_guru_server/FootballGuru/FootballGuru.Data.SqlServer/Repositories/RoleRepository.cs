using System.Data;
using Dapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Data.SqlServer.SqlServer;
using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Domain;

namespace FootballGuru.Data.SqlServer.Repositories;

internal class RoleRepository(
    QueryDbConnection queryDbConnection,
    CommandDbConnection commandDbConnection) : IRoleRepository
{
    private readonly IDbConnection _queryDbConnection = queryDbConnection.Connection;
    private readonly IDbConnection _commandDbConnection = commandDbConnection.Connection;

    public Task CreateAsync(Role role, DataLayerTransaction transaction, CancellationToken cancellationToken = default)
    {
        var sql = "INSERT INTO roles (name) VALUES (@Name)";
        
        var commandDefinition = new CommandDefinition(
            sql, 
            new { Name = role.Name },
            cancellationToken: cancellationToken,
            transaction: transaction.DbTransaction);

        return _commandDbConnection.ExecuteAsync(commandDefinition);
    }

    public async Task<IEnumerable<Role>> GetManyAsync(int? skip, int? limit, CancellationToken cancellationToken = default)
    {
        var sql = "SELECT * FROM roles ORDER BY id desc OFFSET @Skip ROWS FETCH NEXT @Limit ROWS ONLY";

        var commandDefinition = new CommandDefinition(sql, new { Skip = skip ?? 0, Limit = limit ?? 100 }, cancellationToken: cancellationToken);

        return await _queryDbConnection.QueryAsync<Role>(commandDefinition);
    }

    private record RoleQueryResult(int Id, string Name, int? ActionId, string Action);
    
    public async Task<Role> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var sql = @"
            SELECT r.id as Id, r.name as Name, ra.id as ActionId, ra.action as Action
            FROM roles r
            LEFT JOIN role_actions ra ON r.id = ra.role_id 
            WHERE r.id = @Id";

        var commandDefinition = new CommandDefinition(sql, new { Id = id }, cancellationToken: cancellationToken);


        var results = await _queryDbConnection.QueryAsync<RoleQueryResult>(
            commandDefinition);

        if (!results.Any())
        {
            return null;
        }

        var grouped = results.GroupBy(r => new { r.Id, r.Name }).First();
        var role = new Role
        {
            Id = grouped.Key.Id,
            Name = grouped.Key.Name,
            Actions = grouped
                .Where(r => r.ActionId.HasValue)
                .Select(r => new RoleAction
                {
                    Id = r.ActionId.Value,
                    Action = r.Action,
                    RoleId = grouped.Key.Id
                })
                .ToList()
        };

        return role;
    }

    public async Task AddActionAsync(RoleAction roleAction, DataLayerTransaction transaction, CancellationToken cancellationToken = default)
    {
        var sql = "INSERT INTO role_actions (role_id, action) VALUES (@RoleId, @Action)";

        var commandDefinition = new CommandDefinition(sql, new { RoleId = roleAction.RoleId, Action = roleAction.Action }, cancellationToken: cancellationToken, transaction: transaction.DbTransaction);

        await _commandDbConnection.ExecuteAsync(commandDefinition);
    }

    public async Task<bool> ExistsAsync(int roleId, int actionId, CancellationToken cancellationToken = default)
    {
        _queryDbConnection.Open();
        var sql = @"
            SELECT COUNT(1)
            FROM role_actions
            WHERE role_id = @RoleId AND id = @ActionId";


        var exists = await _queryDbConnection.ExecuteScalarAsync<bool>(
            new CommandDefinition(
                sql,
                new { RoleId = roleId, ActionId = actionId },
                cancellationToken: cancellationToken));

        _queryDbConnection.Close();

        return exists;

    }

    public async Task DeleteActionAsync(int roleId, int actionId, DataLayerTransaction transaction, CancellationToken cancellationToken = default)
    {
        var sql = @"
            DELETE FROM role_actions 
            WHERE role_id = @RoleId AND id = @ActionId";

        await _commandDbConnection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new { RoleId = roleId, ActionId = actionId },
                cancellationToken: cancellationToken,
                transaction: transaction.DbTransaction));

    }

    public async Task<List<Role>> GetManyByIdsAsync(
        IEnumerable<int> ids,
        CancellationToken cancellationToken = default)
    {
        var sql = @"
            SELECT r.id as Id, r.name as Name, ra.id as ActionId, ra.action as Action
            FROM roles r
            LEFT JOIN role_actions ra ON r.id = ra.role_id 
            WHERE r.id IN @Ids";

        var commandDefinition = new CommandDefinition(
            sql, 
            new { Ids = ids.ToArray() }, 
            cancellationToken: cancellationToken);

        var results = await _queryDbConnection.QueryAsync<RoleQueryResult>(commandDefinition);

        return results
            .GroupBy(r => new { r.Id, r.Name })
            .Select(grouped => new Role
            {
                Id = grouped.Key.Id,
                Name = grouped.Key.Name,
                Actions = grouped
                    .Where(r => r.ActionId.HasValue)
                    .Select(r => new RoleAction
                    {
                        Id = r.ActionId.Value,
                        Action = r.Action,
                        RoleId = grouped.Key.Id
                    })
                    .ToList()
            })
            .ToList();
    }
}   