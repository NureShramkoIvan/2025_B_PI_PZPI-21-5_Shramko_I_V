﻿using System.Data;

namespace FootballGuru.Data.SqlServer.Transactions;

public class DataLayerTransaction(IDbTransaction dbTransaction)
{
    public IDbTransaction DbTransaction { get; } = dbTransaction;

    public void Commit()
    {
        DbTransaction.Commit();
    }
}
