﻿namespace FootballGuru.Data.SqlServer.Transactions;

public interface IDataLayerTransactionFactory
{
    DataLayerTransaction Create();
}
