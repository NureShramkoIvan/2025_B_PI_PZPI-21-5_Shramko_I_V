﻿using FootballGuru.Data.SqlServer.SqlServer;
using System.Data.Common;

namespace FootballGuru.Data.SqlServer.Transactions;

internal class DataLayerTransactionFactory(CommandDbConnection dbConnection) : IDataLayerTransactionFactory
{
    private readonly DbConnection _dbConnection = dbConnection.Connection;

    public DataLayerTransaction Create()
    {
        _dbConnection.Open();
        var transaction = _dbConnection.BeginTransaction();
        return new DataLayerTransaction(transaction);
    }
}
