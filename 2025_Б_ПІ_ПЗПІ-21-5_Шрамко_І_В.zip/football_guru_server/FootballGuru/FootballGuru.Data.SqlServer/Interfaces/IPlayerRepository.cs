﻿using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Domain;

namespace FootballGuru.Data.SqlServer.Interfaces;

public interface IPlayerRepository
{
    Task CreateAsync(Player trainer, DataLayerTransaction transaction, CancellationToken cancellationToken = default);
    Task<IEnumerable<Player>> GetManyAsync(
        int skip,
        int limit,
        int trainerId,
        CancellationToken cancellationToken = default);

    Task<Player> GetByIdAsync(int playerId, int trainerId, CancellationToken cancellationToken = default);

    Task<bool> ExistsManyAsync(
        IEnumerable<int> ids, 
        int trainerId,
        CancellationToken cancellationToken = default);

    Task<List<Player>> GetManyByIdsAsync(
        IEnumerable<int> ids,
        int trainerId,
        CancellationToken cancellationToken = default);
}
