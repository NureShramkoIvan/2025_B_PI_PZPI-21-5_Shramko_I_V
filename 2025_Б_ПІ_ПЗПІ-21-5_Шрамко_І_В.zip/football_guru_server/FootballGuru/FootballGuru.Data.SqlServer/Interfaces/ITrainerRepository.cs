﻿using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Domain;
using System.Data;

namespace FootballGuru.Data.SqlServer.Interfaces;

public interface ITrainerRepository
{
    Task CreateAsync(Trainer trainer, DataLayerTransaction transaction, CancellationToken cancellationToken = default);
    Task<bool> UserNameExistsAsync(
        string userName,
        CancellationToken cancellationToken = default);
    Task<Trainer> GetOneByUserName(string userName, CancellationToken cancellationToken = default);
    Task<bool> ExistsAsync(int trainerId, CancellationToken cancellationToken);
}
