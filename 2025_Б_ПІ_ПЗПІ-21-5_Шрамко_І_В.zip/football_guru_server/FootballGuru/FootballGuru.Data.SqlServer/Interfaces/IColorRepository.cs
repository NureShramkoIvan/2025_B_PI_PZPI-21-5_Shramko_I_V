using FootballGuru.Domain;

namespace FootballGuru.Data.SqlServer.Interfaces;

public interface IColorRepository
{
    Task<IEnumerable<Color>> GetManyAsync(int? skip, int? limit, CancellationToken cancellationToken = default);
} 