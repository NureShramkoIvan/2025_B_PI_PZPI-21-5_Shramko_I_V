using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Domain;

namespace FootballGuru.Data.SqlServer.Interfaces;

public interface IRoleRepository
{
    Task CreateAsync(Role role, DataLayerTransaction transaction, CancellationToken cancellationToken = default);
    Task<IEnumerable<Role>> GetManyAsync(int? skip, int? limit, CancellationToken cancellationToken = default);
    Task<Role> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task AddActionAsync(RoleAction roleAction, DataLayerTransaction transaction, CancellationToken cancellationToken = default);
    Task<bool> ExistsAsync(int roleId, int actionId, CancellationToken cancellationToken = default);
    Task DeleteActionAsync(int roleId, int actionId, DataLayerTransaction transaction, CancellationToken cancellationToken = default);
    Task<List<Role>> GetManyByIdsAsync(
        IEnumerable<int> ids,
        CancellationToken cancellationToken = default);
}