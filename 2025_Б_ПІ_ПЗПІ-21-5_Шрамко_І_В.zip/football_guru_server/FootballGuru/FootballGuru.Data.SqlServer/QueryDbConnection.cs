﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Data.SqlServer;
internal class QueryDbConnection(string connectionString)
{
    public SqlConnection Connection { get; } = new SqlConnection(connectionString);
}
