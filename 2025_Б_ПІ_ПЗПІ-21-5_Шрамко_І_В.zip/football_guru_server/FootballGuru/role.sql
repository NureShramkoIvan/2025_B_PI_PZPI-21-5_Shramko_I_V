create table roles
(
    id int primary key identity,
    name varchar(50) not null
)

drop table roles; 

create table role_actions
(
    id int primary key identity,
    role_id int not null,
    action varchar(50) not null,
    foreign key (role_id) references roles(id)
)


drop table role_actions; 