using AutoMapper;
using FootballGuru.Data.MongoDB.Entities;
using FootballGuru.Domain;

public class MapperProfile : Profile
{
    public MapperProfile()
    {
        CreateMap<TrainingEntity, Training>();
        CreateMap<TrainingEntity.PlayerConfigurationEntity, Training.PlayerConfiguration>();
        CreateMap<TrainingEntity.TeamConfigurationEntity, Training.TeamConfiguration>();
        CreateMap<TrainingEntity.ZoneConfigurationEntity, Training.ZoneConfiguration>();

        CreateMap<Training, TrainingEntity>();
        CreateMap<Training.TeamConfiguration, TrainingEntity.TeamConfigurationEntity>();
        CreateMap<Training.PlayerConfiguration, TrainingEntity.PlayerConfigurationEntity>();
        CreateMap<Training.ZoneConfiguration, TrainingEntity.ZoneConfigurationEntity>();
    }
}
