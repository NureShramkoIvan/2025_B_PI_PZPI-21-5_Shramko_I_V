using FootballGuru.Data.MongoDB.Repositories;
using FootballGuru.Data.MongoDB.Repositories.Abstract;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;

namespace FootballGuru.Data.MongoDB;

public static class DependencyModule
{
    public static IServiceCollection AddMongoDb(this IServiceCollection services, string dbConnectionString)
    {
        services.AddScoped(c => new MongoClient(dbConnectionString).GetDatabase("FootballGuru"));

        services.AddScoped<IFormationRepository, FormationRepository>();
        services.AddScoped<ITrainingRepository, TrainingRepository>();

        services.AddAutoMapper(c => c.AddProfile<MapperProfile>());
        
        return services;
    }
}