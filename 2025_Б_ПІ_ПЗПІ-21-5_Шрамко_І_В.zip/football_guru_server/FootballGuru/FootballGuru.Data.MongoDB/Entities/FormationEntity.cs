using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

public class FormationEntity
{
    [BsonId]
    public int Id { get; set; }
    public string Name { get; set; }
    public List<FormationLineEntity> Lines { get; set; }


    public class FormationLineEntity
    {
        public int Order { get; set; }
        public List<FormationPositionEntity> Positions { get; set; }
    }

    public class FormationPositionEntity
    {
        public int Order { get; set; }
    }
}
