using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FootballGuru.Data.MongoDB.Entities;

public class TrainingEntity
{
    [BsonId]
    [BsonRepresentation(BsonType.String)]
    public Guid Id { get; set; }
    public int TrainerId { get; set; }
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public TeamConfigurationEntity TeamA { get; set; }
    public TeamConfigurationEntity TeamB { get; set; }

    public class TeamConfigurationEntity
    {
        public int FormationId { get; set; }
        public List<PlayerConfigurationEntity> Players { get; set; }
    }

    public class PlayerConfigurationEntity
    {
        public int PlayerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> Actions { get; set; }
        public ZoneConfigurationEntity Zone { get; set; }
        public int ColorId { get; set; }
        public string ColorHex { get; set; }
    }

    public class ZoneConfigurationEntity
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    }
} 