using FootballGuru.Domain;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

public class FormationRepository(IMongoDatabase database) : IFormationRepository
{
    private readonly IMongoCollection<FormationEntity> _formations = database.GetCollection<FormationEntity>("formations");

    public async Task<IEnumerable<Formation>> GetManyAsync(CancellationToken cancellationToken = default)
    {
        var records = await _formations.Find(_ => true).ToListAsync(cancellationToken);
        
        return records.Select(r => new Formation
        {
            Id = r.Id,
            Name = r.Name,
            Lines = r.Lines.Select(l => new Formation.FormationLine
            {
                Order = l.Order,
                Positions = l.Positions.Select(p => new Formation.FormationPosition
                {
                    Order = p.Order
                }).OrderBy(p => p.Order).ToList()
            }).OrderBy(l => l.Order).ToList()
        }).ToList();
    }

}
