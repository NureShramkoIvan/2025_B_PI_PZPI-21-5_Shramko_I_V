using AutoMapper;
using FootballGuru.Data.MongoDB.Entities;
using FootballGuru.Data.MongoDB.Repositories.Abstract;
using FootballGuru.Domain;
using MongoDB.Driver;

namespace FootballGuru.Data.MongoDB.Repositories;

public class TrainingRepository(IMongoDatabase database, IMapper mapper) : ITrainingRepository
{
    private readonly IMongoCollection<TrainingEntity> _trainings = database.GetCollection<TrainingEntity>("trainings");

    public async Task CreateAsync(Training training, CancellationToken cancellationToken = default)
    {
        var entity = mapper.Map<TrainingEntity>(training);

        await _trainings.InsertOneAsync(entity, cancellationToken: cancellationToken);
    }

    public async Task<List<Training>> GetManyAsync(
        int? skip,
        int? limit,
        int trainerId,
        CancellationToken cancellationToken = default)
    {
        var filter = Builders<TrainingEntity>.Filter.Eq(t => t.TrainerId, trainerId);
        var options = new FindOptions<TrainingEntity>
        {
            Skip = skip,
            Limit = limit,
            Sort = Builders<TrainingEntity>.Sort.Descending(t => t.DateTime)
        };

        var trainings = await _trainings.FindAsync(filter, options, cancellationToken);
        var trainingList = await trainings.ToListAsync(cancellationToken);

        return mapper.Map<List<Training>>(trainingList);
    }

    public async Task<Training> GetByIdAsync(
        Guid id,
        int trainerId,
        CancellationToken cancellationToken = default)
    {
        var filter = Builders<TrainingEntity>.Filter.And(
            Builders<TrainingEntity>.Filter.Eq(t => t.Id, id),
            Builders<TrainingEntity>.Filter.Eq(t => t.TrainerId, trainerId));

        var trainingEntity = await _trainings.Find(filter)
            .FirstOrDefaultAsync(cancellationToken);

        return trainingEntity == null ? null : mapper.Map<Training>(trainingEntity);
    }
} 