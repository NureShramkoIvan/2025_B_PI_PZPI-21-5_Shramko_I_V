using FootballGuru.Domain;

public interface IFormationRepository
{
    Task<IEnumerable<Formation>> GetManyAsync(CancellationToken cancellationToken = default);
}