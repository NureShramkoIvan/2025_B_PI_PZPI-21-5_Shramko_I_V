using FootballGuru.Domain;

namespace FootballGuru.Data.MongoDB.Repositories.Abstract;

public interface ITrainingRepository
{
    Task CreateAsync(Training training, CancellationToken cancellationToken = default);
    Task<List<Training>> GetManyAsync(
        int? skip,
        int? limit,
        int trainerId,
        CancellationToken cancellationToken = default);
    Task<Training> GetByIdAsync(
        Guid id,
        int trainerId,
        CancellationToken cancellationToken = default);
} 