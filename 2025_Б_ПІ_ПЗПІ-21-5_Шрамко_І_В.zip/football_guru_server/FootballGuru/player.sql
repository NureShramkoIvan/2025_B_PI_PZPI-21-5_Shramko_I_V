create table players
(
	id int primary key identity,
	first_name varchar(50),
	last_name varchar(50),
	date_of_birth datetime,
	trainer_id int,
	role_id int null,
	foreign key (trainer_id) references trainers(id),
	foreign key (role_id) references roles(id)
)

drop table players;