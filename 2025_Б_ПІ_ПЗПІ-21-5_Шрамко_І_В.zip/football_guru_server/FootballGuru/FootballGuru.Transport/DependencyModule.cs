﻿using Microsoft.Extensions.DependencyInjection;

namespace FootballGuru.Transport;

public static class DependencyModule
{
    public static IServiceCollection AddTransport(this IServiceCollection services)
    {
        //TDOD: think about moving DTOs of of transport
        return services;
    }
}
