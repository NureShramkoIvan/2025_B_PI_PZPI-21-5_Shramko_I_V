using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;

namespace FootballGuru.Transport.Queries;

public class GetOneRoleQuery(int roleId) : IRequest<OneOf<RoleDetailsDTO, RoleNotFoundError>>
{
    public int RoleId { get; } = roleId;
} 