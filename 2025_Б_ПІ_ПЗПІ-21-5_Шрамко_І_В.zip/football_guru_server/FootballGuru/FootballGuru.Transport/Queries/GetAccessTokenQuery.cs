﻿using FootballGuru.Transport.DTOs.Identity;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;

namespace FootballGuru.Transport.Queries;

public class GetAccessTokenQuery : IRequest<OneOf<AccessTokenDTO, InvalidCredentialsError>>
{
    public string UserName { get; set; }
    public string Password { get; set; }
}
