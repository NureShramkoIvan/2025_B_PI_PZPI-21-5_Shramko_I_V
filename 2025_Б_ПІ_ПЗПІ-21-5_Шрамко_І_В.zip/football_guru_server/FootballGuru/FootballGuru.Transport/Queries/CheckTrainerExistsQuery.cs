using MediatR;

namespace FootballGuru.Transport.Queries
{
    public class CheckTrainerExistsQuery(int trainerId) : IRequest<bool>
    {
        public int TrainerId { get; } = trainerId;
    }
}
