using FootballGuru.Transport.DTOs.Players;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;

namespace FootballGuru.Transport.Queries;

public class GetOnePlayerQuery(int playerId, int trainerId) : IRequest<OneOf<PlayerDTO, PlayerNotFoundError>>
{
    public int PlayerId { get; } = playerId;
    public int TrainerId { get; } = trainerId;
} 