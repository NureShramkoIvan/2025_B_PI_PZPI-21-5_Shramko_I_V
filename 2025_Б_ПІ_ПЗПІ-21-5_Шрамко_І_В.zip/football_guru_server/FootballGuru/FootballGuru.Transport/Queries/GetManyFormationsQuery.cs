using FootballGuru.Transport.DTOs.Formations;
using MediatR;

namespace FootballGuru.Transport.Queries;

public record GetManyFormationsQuery() : IRequest<IEnumerable<FormationDTO>>; 