using FootballGuru.Transport.DTOs.Colors;
using FootballGuru.Transport.DTOs.Common;
using MediatR;

namespace FootballGuru.Transport.Queries;

public class GetManyColorsQuery(int? skip, int? limit) : IRequest<PageDTO<ColorDTO>>
{
    public int? Skip { get; } = skip;
    public int? Limit { get; } = limit;
} 