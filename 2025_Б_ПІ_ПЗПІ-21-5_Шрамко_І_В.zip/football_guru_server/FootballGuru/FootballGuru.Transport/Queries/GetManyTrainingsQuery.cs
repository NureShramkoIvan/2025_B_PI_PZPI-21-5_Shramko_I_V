using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Trainings;
using MediatR;

namespace FootballGuru.Transport.Queries;

public class GetManyTrainingsQuery(int? skip, int? limit, int trainerId) 
    : IRequest<PageDTO<TrainingDTO>>
{
    public int? Skip { get; } = skip;
    public int? Limit { get; } = limit;
    public int TrainerId { get; } = trainerId;
} 