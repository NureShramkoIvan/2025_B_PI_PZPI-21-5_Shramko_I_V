using FootballGuru.Transport.DTOs.Trainings;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Transport.Queries;

public class GetTrainingByIdQuery(Guid id, int trainerId) 
    : IRequest<OneOf<TrainingDetailsDTO, TrainingNotFoundError>>
{
    public Guid Id { get; } = id;
    public int TrainerId { get; } = trainerId;
} 