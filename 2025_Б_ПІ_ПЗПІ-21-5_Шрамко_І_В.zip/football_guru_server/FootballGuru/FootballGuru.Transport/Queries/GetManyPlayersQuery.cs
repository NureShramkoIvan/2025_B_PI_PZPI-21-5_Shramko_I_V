﻿using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Players;
using MediatR;

namespace FootballGuru.Transport.Queries;

public class GetManyPlayersQuery(int? skip, int? limit, int? trainerId) : IRequest<PageDTO<PlayerDTO>>
{
    public int? Skip { get; } = skip;
    public int? Limit { get; } = limit;
    public int? TrainerId { get; } = trainerId;
}
