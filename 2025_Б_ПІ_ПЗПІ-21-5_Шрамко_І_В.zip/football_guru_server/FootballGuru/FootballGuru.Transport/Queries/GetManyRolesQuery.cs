using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Roles;
using MediatR;

namespace FootballGuru.Transport.Queries;

public class GetManyRolesQuery(int? skip, int? limit) : IRequest<PageDTO<RoleDTO>>
{
    public int? Skip { get; } = skip;
    public int? Limit { get; } = limit;
}

