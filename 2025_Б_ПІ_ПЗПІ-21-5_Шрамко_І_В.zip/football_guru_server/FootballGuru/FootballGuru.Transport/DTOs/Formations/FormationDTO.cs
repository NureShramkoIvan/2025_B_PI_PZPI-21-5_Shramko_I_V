namespace FootballGuru.Transport.DTOs.Formations;

public class FormationDTO
{
    public int Id { get; set; }
    public string Name { get; set; }
    public List<FormationLineDTO> Lines { get; set; }

    public class FormationLineDTO
    {
        public int Order { get; set; }
        public List<FormationPositionDTO> Positions { get; set; }
    }

    public class FormationPositionDTO
    {
        public int Order { get; set; }
    }
} 