namespace FootballGuru.Transport.DTOs.Colors;

public class ColorDTO
{
    public int Id { get; set; }
    public string Hex { get; set; }
} 