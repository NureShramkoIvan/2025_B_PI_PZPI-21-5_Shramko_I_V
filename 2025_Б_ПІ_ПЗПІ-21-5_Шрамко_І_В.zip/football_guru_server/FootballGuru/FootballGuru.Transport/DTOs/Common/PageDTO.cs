﻿namespace FootballGuru.Transport.DTOs.Common;

public class PageDTO<T>
{
    public IEnumerable<T> Data { get; set; }
    public bool HasNext { get; set; }
}
