﻿namespace FootballGuru.Transport.DTOs.Common;

public class PageRequestDTO
{
    public int? Skip { get; set; }
    public int? Limit { get; set; }
}
