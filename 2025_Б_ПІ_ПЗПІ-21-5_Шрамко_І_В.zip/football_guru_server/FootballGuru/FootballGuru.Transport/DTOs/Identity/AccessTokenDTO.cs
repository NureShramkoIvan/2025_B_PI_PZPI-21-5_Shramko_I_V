﻿namespace FootballGuru.Transport.DTOs.Identity;

public class AccessTokenDTO
{
    public string AccessToken { get; set; }
    public DateTime ExpiresAt { get; set; }
}
