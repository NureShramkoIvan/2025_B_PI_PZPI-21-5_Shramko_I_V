﻿namespace FootballGuru.Transport.DTOs.Identity;

public class GetAccessTokenDTO
{
    public string Username { get; set; }
    public string Password { get; set; }
}
