﻿using FootballGuru.Transport.DTOs.Common;

namespace FootballGuru.Transport.DTOs.Players;

public class GetManyPlayersDTO : PageRequestDTO
{
    public int? TrainerId { get; set; }
}


