public class GetOnePlayerDTO
{
    public int TrainerId { get; set; }
    public int PlayerId { get; set; }
}
