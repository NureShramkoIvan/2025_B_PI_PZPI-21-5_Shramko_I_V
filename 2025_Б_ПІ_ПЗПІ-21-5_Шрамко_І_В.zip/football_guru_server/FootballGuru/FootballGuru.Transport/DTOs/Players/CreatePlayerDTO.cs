﻿namespace FootballGuru.Transport.DTOs.Players;

public class CreatePlayerDTO
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime DateOfBirth { get; set; }
    public int TrainerId { get; set; }
    public int? RoleId { get; set; }
}

