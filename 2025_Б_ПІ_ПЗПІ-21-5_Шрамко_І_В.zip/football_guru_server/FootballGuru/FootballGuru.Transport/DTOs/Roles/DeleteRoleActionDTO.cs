namespace FootballGuru.Transport.DTOs.Roles;

public class DeleteRoleActionDTO
{
    public int RoleId { get; set; }
    public int ActionId { get; set; }
} 