namespace FootballGuru.Transport.DTOs.Roles;

public class GetOneRoleDTO
{
    public int RoleId { get; set; }
} 