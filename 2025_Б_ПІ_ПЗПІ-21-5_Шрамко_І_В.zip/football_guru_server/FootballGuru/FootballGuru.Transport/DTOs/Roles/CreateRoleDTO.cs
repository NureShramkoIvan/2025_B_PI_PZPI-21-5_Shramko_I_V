namespace FootballGuru.Transport.DTOs.Roles;

public class CreateRoleDTO
{
    public string Name { get; set; }
} 