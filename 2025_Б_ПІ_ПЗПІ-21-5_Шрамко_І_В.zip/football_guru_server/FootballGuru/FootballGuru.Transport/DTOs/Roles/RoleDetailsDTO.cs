namespace FootballGuru.Transport.DTOs.Roles;

public class RoleDetailsDTO
{
    public int Id { get; set; }
    public string Name { get; set; }
    public List<RoleActionDTO> Actions { get; set; }
}

