namespace FootballGuru.Transport.DTOs.Roles;

public class CreateRoleActionDTO
{
    public int RoleId { get; set; }
    public string Action { get; set; }
}
