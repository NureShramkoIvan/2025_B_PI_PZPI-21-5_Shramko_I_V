namespace FootballGuru.Transport.DTOs.Roles;

public class RoleActionDTO
{
    public int Id { get; set; }
    public string Action { get; set; }
}