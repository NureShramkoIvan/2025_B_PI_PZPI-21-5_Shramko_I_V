using FootballGuru.Transport.DTOs.Common;

namespace FootballGuru.Transport.DTOs.Roles;

public class GetManyRolesDTO : PageRequestDTO
{
}