namespace FootballGuru.Transport.DTOs.Trainings;

public class GetManyTrainingsDTO
{
    public int? Skip { get; set; }
    public int? Limit { get; set; }
    public int TrainerId { get; set; }
} 