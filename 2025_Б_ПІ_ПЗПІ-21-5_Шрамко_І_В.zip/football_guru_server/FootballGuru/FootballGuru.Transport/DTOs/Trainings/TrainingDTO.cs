namespace FootballGuru.Transport.DTOs.Trainings;

public class TrainingDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
} 