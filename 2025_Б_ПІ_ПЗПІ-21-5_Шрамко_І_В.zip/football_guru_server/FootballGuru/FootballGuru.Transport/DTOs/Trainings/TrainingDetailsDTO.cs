namespace FootballGuru.Transport.DTOs.Trainings;

public class TrainingDetailsDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public TeamConfigurationDTO TeamA { get; set; }
    public TeamConfigurationDTO TeamB { get; set; }

    public class TeamConfigurationDTO
    {
        public int FormationId { get; set; }
        public List<PlayerConfigurationDTO> Players { get; set; }
    }

    public class PlayerConfigurationDTO
    {
        public int PlayerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> Actions { get; set; }
        public ZoneConfigurationDTO Zone { get; set; }
        public int ColorId { get; set; }
        public string ColorHex { get; set; }
    }

    public class ZoneConfigurationDTO
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    }
} 