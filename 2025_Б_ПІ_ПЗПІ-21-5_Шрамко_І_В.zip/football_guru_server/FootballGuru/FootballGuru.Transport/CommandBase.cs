﻿using FootballGuru.Data.SqlServer.Transactions;

namespace FootballGuru.Transport;

public class CommandBase
{
    public DataLayerTransaction Transaction { get; set; }
}
