namespace FootballGuru.Transport.Errors;

public struct RoleActionNotFoundError { } 