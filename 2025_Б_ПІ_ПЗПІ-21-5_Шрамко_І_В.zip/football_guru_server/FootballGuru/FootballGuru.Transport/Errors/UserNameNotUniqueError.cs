﻿namespace FootballGuru.Transport.Errors;

public struct UserNameNotUniqueError { }
