namespace FootballGuru.Transport.Errors;

public record FormationNotFoundError; 