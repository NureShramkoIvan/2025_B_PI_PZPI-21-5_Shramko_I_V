namespace FootballGuru.Transport.Errors;

public record PlayerNotFoundError; 