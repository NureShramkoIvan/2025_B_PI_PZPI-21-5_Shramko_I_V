﻿namespace FootballGuru.Transport.Errors;

public struct InvalidCredentialsError { }
