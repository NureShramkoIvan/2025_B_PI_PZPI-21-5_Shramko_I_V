using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Transport.Commands;

public class DeleteRoleActionCommand : CommandBase, IRequest<OneOf<None, RoleNotFoundError, RoleActionNotFoundError>>
{
    public int RoleId { get; set; }
    public int ActionId { get; set; }
} 