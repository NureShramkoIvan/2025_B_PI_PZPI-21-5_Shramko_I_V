using FootballGuru.Domain;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Transport.Commands;

public class CreateTrainingCommand : CommandBase, IRequest<OneOf<None, FormationNotFoundError, PlayerNotFoundError>>
{
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public int TrainerId { get; set; }
    public TeamConfiguration TeamA { get; set; }
    public TeamConfiguration TeamB { get; set; }

    public class TeamConfiguration
    {
        public int FormationId { get; set; }
        public List<PlayerConfiguration> Players { get; set; }
    }

    public class PlayerConfiguration
    {
        public int PlayerId { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> CustomActions { get; set; }
        public ZoneConfiguration Zone { get; set; }
        public int ColorId { get; set; }
    }

    public class ZoneConfiguration
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    }
} 