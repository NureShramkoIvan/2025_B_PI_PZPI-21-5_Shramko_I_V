﻿using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Transport.Commands;

public class CreatePlayerCommand : CommandBase, IRequest<OneOf<None, TrainerNotFoundError>>
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime DateOfBirth { get; set; }
    public int TrainerId { get; set; }
    public int? RoleId { get; set; }
}
