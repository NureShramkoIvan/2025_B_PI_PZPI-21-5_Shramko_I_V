using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;


namespace FootballGuru.Transport.Commands;

public class CreateRoleActionCommand : CommandBase, IRequest<OneOf<None, RoleNotFoundError>>
{
    public int RoleId { get; set; }
    public string Action { get; set; }
} 