﻿using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Transport.Commands;

public class CreateTrainerCommand : CommandBase, IRequest<OneOf<None, UserNameNotUniqueError>>
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
}
