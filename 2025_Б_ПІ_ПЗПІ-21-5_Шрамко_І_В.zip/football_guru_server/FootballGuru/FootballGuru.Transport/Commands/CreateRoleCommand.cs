using MediatR;

namespace FootballGuru.Transport.Commands;

public class CreateRoleCommand : CommandBase, IRequest
{
    public string Name { get; set; }
}

