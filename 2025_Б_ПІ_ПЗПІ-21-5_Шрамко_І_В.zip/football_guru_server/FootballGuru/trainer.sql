create table trainers
(
	id int primary key identity,
	first_name varchar(50),
	last_name varchar(50),
	user_name varchar(50),
	password_hash varchar(100)
)