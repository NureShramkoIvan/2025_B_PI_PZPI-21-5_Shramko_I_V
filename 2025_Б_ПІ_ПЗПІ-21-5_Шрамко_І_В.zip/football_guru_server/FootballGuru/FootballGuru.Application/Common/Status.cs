﻿namespace FootballGuru.Application.Common;

public enum Status
{
    Success = 200,
    NotFound = 404,
    ValidationFailure = 400,
}
