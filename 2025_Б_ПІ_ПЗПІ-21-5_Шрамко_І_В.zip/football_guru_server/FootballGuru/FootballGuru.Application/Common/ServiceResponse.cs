﻿using FluentValidation.Results;

namespace FootballGuru.Application.Common;

public class ServiceResponse
{
    public ValidationResult ValidationResult { get; set; }
    public Status Status { get; set; }
    public string Message { get; set; }
}

public class ServiceResponse<TData> : ServiceResponse
{
    public TData Data { get; set; }
}