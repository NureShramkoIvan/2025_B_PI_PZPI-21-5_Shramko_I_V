﻿using FluentValidation.Results;

namespace FootballGuru.Application.Common;

internal class LogicalLayerElement
{
    protected ServiceResponse ValidationFailure(ValidationResult validationResult)
        => new() { Status = Status.ValidationFailure, ValidationResult = validationResult };

    protected ServiceResponse<T> ValidationFailure<T>(ValidationResult validationResult)
        => new() { Status = Status.ValidationFailure, ValidationResult = validationResult };

    protected ServiceResponse ValidationFailure(string message)
        => new() { Status = Status.ValidationFailure, Message = message };
    protected ServiceResponse<T> ValidationFailure<T>(string message)
        => new() { Status = Status.ValidationFailure, Message = message };
    protected ServiceResponse NotFound(string message)
        => new() { Status = Status.NotFound, Message = message };
    protected ServiceResponse<T> NotFound<T>(string message)
        => new() { Status = Status.NotFound, Message = message };
    protected ServiceResponse Success() => new() { Status = Status.Success };
    protected ServiceResponse<T> Success<T>(T data) => new() { Status = Status.Success, Data = data };
}
