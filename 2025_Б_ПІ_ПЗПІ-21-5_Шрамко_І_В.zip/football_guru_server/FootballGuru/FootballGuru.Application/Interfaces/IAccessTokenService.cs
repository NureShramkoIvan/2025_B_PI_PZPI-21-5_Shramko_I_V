﻿using System.Security.Claims;

namespace FootballGuru.Application.Interfaces;

internal interface IAccessTokenService
{
    public (string token, DateTime expiresAt) GenerateJwtToken(IEnumerable<Claim> claims);
}
