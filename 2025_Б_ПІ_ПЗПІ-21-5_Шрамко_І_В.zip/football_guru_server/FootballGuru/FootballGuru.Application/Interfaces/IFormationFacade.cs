using FootballGuru.Application.Common;
using FootballGuru.Transport.DTOs.Formations;

namespace FootballGuru.Application.Interfaces;

public interface IFormationFacade
{
    Task<ServiceResponse<IEnumerable<FormationDTO>>> GetManyFormationsAsync(CancellationToken cancellationToken = default);
} 