﻿using FootballGuru.Application.Common;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Players;

namespace FootballGuru.Application.Interfaces;

public interface IPlayerFacade
{
    Task<ServiceResponse> CreatePlayerAsync(
        CreatePlayerDTO createPlayerDTO,
        CancellationToken cancellationToken = default);

    Task<ServiceResponse<PageDTO<PlayerDTO>>> GetManyPlayers(
        GetManyPlayersDTO getManyPlayersDTO,
        CancellationToken cancellationToken);

    Task<ServiceResponse<PlayerDTO>> GetOnePlayerAsync(
        GetOnePlayerDTO getOnePlayerDTO,
        CancellationToken cancellationToken = default);
}
