using FootballGuru.Application.Common;
using FootballGuru.Transport.DTOs.Colors;
using FootballGuru.Transport.DTOs.Common;

namespace FootballGuru.Application.Interfaces;

public interface IColorFacade
{
    Task<ServiceResponse<PageDTO<ColorDTO>>> GetManyAsync(
        PageRequestDTO request,
        CancellationToken cancellationToken = default);
} 