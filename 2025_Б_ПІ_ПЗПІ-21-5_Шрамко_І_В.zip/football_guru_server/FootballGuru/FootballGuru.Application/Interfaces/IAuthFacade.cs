﻿using FootballGuru.Application.Common;
using FootballGuru.Transport.DTOs.Identity;

namespace FootballGuru.Application.Interfaces;

public interface IAuthFacade
{
    Task<ServiceResponse> CreateUser(CreateUserDTO createUserDTO, CancellationToken cancellationToken = default);
    Task<ServiceResponse<AccessTokenDTO>> GetAccessToken(
        GetAccessTokenDTO getAccessTokenDTO,
        CancellationToken cancellationToken = default);
}
