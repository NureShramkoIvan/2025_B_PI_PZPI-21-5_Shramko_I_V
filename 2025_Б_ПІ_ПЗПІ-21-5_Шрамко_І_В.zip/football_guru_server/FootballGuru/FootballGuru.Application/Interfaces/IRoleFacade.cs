using FootballGuru.Application.Common;
using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.DTOs.Common;

namespace FootballGuru.Application.Interfaces;

public interface IRoleFacade
{
    Task<ServiceResponse> CreateAsync(
        CreateRoleDTO request,
        CancellationToken cancellationToken = default);
    Task<ServiceResponse<PageDTO<RoleDTO>>> GetManyAsync(
        GetManyRolesDTO request,
        CancellationToken cancellationToken = default);
    Task<ServiceResponse<RoleDetailsDTO>> GetOneAsync(
        GetOneRoleDTO request,
        CancellationToken cancellationToken = default);
    Task<ServiceResponse> CreateRoleActionAsync(
        CreateRoleActionDTO request,
        CancellationToken cancellationToken = default);
    Task<ServiceResponse> DeleteRoleActionAsync(
        DeleteRoleActionDTO request,
        CancellationToken cancellationToken = default);
} 