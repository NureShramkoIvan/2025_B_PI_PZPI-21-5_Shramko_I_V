using FootballGuru.Application.Common;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Trainings;

namespace FootballGuru.Application.Interfaces;

public interface ITrainingFacade
{
    Task<ServiceResponse> CreateTrainingAsync(
        CreateTrainingDTO createTrainingDTO,
        CancellationToken cancellationToken = default);

    Task<ServiceResponse<PageDTO<TrainingDTO>>> GetManyTrainingsAsync(
        GetManyTrainingsDTO getManyTrainingsDTO,
        CancellationToken cancellationToken = default);

    Task<ServiceResponse<TrainingDetailsDTO>> GetTrainingByIdAsync(
        Guid id,
        int trainerId,
        CancellationToken cancellationToken = default);
} 