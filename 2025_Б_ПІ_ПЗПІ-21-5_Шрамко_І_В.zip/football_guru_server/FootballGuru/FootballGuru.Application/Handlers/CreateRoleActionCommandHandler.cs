using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Domain;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Application.Handlers;

internal class CreateRoleActionCommandHandler(
    IRoleRepository roleRepository) : IRequestHandler<CreateRoleActionCommand, OneOf<None, RoleNotFoundError>>
{
    public async Task<OneOf<None, RoleNotFoundError>> Handle(
        CreateRoleActionCommand request,
        CancellationToken cancellationToken)
    {
        var role = await roleRepository.GetByIdAsync(request.RoleId, cancellationToken);
        
        if (role is null)
        {
            return new RoleNotFoundError();
        }

        await roleRepository.AddActionAsync(new RoleAction { Action = request.Action, RoleId = request.RoleId }, request.Transaction, cancellationToken);


        return new None();

    }
} 