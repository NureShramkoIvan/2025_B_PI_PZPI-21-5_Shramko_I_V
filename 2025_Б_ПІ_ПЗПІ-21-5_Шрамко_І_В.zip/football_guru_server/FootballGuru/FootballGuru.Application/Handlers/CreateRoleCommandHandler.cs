using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Domain;
using FootballGuru.Transport.Commands;
using MediatR;

namespace FootballGuru.Application.Handlers;

public class CreateRoleCommandHandler(IRoleRepository roleRepository) : IRequestHandler<CreateRoleCommand>
{
    public async Task Handle(CreateRoleCommand request, CancellationToken cancellationToken)
    {
        var role = new Role { Name = request.Name };
        await roleRepository.CreateAsync(role, request.Transaction, cancellationToken);
    }
}