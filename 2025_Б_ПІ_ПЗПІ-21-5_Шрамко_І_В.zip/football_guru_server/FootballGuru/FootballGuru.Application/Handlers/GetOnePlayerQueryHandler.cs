using AutoMapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.DTOs.Players;
using FootballGuru.Transport.Errors;
using FootballGuru.Transport.Queries;
using MediatR;
using OneOf;

namespace FootballGuru.Application.Handlers;

internal class GetOnePlayerQueryHandler(
    IPlayerRepository playerRepository,
    IMapper mapper) : IRequestHandler<GetOnePlayerQuery, OneOf<PlayerDTO, PlayerNotFoundError>>
{
    public async Task<OneOf<PlayerDTO, PlayerNotFoundError>> Handle(
        GetOnePlayerQuery request,

        CancellationToken cancellationToken)
    {

        var player = await playerRepository.GetByIdAsync(request.PlayerId, request.TrainerId, cancellationToken);
        
        if (player is null)
        {
            return new PlayerNotFoundError();
        }

        return mapper.Map<PlayerDTO>(player);
    }
} 