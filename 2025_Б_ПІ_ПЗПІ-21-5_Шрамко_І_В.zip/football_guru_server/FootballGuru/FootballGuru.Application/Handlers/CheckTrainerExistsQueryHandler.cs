using MediatR;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.Queries;

namespace FootballGuru.Application.Handlers
{
    internal class CheckTrainerExistsQueryHandler(ITrainerRepository trainerRepository) 
        : IRequestHandler<CheckTrainerExistsQuery, bool>
    {
        public async Task<bool> Handle(CheckTrainerExistsQuery request, CancellationToken cancellationToken)
        {
            var exists = await trainerRepository.ExistsAsync(request.TrainerId, cancellationToken);
            return exists;
        }
    }
}