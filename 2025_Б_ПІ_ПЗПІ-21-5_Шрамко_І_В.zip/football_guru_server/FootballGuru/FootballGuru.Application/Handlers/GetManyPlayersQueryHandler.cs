﻿using AutoMapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Players;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Handlers;

internal class GetManyPlayersQueryHandler(
    IPlayerRepository playerRepository,
    IMapper mapper) : IRequestHandler<GetManyPlayersQuery, PageDTO<PlayerDTO>>
{
    public async Task<PageDTO<PlayerDTO>> Handle(
        GetManyPlayersQuery request,
        CancellationToken cancellationToken)
    {
        var players = await playerRepository.GetManyAsync(
            request.Skip ?? 0,
            request.Limit.HasValue ? request.Limit.Value + 1 : 101,
            request.TrainerId.Value,
            cancellationToken);

        return new()
        { 
            Data = mapper.Map<IEnumerable<PlayerDTO>>(players),
            HasNext = request.Limit.HasValue ? players.Count() > request.Limit.Value : players.Count() > 100
        };
    }
}
