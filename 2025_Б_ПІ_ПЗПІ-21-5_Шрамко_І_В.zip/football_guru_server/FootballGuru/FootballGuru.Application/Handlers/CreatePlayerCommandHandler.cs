﻿using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Domain;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.Errors;
using FootballGuru.Transport.Queries;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Application.Handlers;

internal class CreatePlayerCommandHandler(
    IPlayerRepository playerRepository,
    IMediator mediator) : IRequestHandler<CreatePlayerCommand, OneOf<None, TrainerNotFoundError>>
{
    public async Task<OneOf<None, TrainerNotFoundError>> Handle(CreatePlayerCommand request, CancellationToken cancellationToken)
    {
        var trainerExistsResult = await mediator.Send(new CheckTrainerExistsQuery(request.TrainerId), cancellationToken);

        if (!trainerExistsResult) return new TrainerNotFoundError();

        var player = new Player()
        {
            DateOfBirth = request.DateOfBirth,
            FirstName = request.FirstName,
            LastName = request.LastName,
            TrainerId = request.TrainerId,
            RoleId = request.RoleId
        };

        await playerRepository.CreateAsync(player, request.Transaction, cancellationToken);
        return new None();
    }
}
