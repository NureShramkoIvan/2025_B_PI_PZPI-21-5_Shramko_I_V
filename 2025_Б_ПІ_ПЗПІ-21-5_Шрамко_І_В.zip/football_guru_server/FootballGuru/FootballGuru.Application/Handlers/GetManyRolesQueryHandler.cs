using AutoMapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Handlers;

public class GetManyRolesQueryHandler(IRoleRepository roleRepository, IMapper mapper) : IRequestHandler<GetManyRolesQuery, PageDTO<RoleDTO>>
{
    public async Task<PageDTO<RoleDTO>> Handle(GetManyRolesQuery request, CancellationToken cancellationToken)
    {
        var roles = await roleRepository.GetManyAsync(request.Skip, request.Limit, cancellationToken);

        return new PageDTO<RoleDTO>()   
        {
            Data = mapper.Map<IEnumerable<RoleDTO>>(roles),
            HasNext = request.Limit.HasValue ? roles.Count() > request.Limit.Value : roles.Count() > 100
        };
    }
}