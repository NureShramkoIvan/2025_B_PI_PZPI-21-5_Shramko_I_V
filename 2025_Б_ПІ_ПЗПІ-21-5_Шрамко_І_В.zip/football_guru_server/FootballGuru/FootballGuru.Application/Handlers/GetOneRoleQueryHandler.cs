using AutoMapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.Errors;
using FootballGuru.Transport.Queries;
using MediatR;
using OneOf;

namespace FootballGuru.Application.Handlers;

internal class GetOneRoleQueryHandler(
    IRoleRepository roleRepository,
    IMapper mapper) : IRequestHandler<GetOneRoleQuery, OneOf<RoleDetailsDTO, RoleNotFoundError>>
{
    public async Task<OneOf<RoleDetailsDTO, RoleNotFoundError>> Handle(
        GetOneRoleQuery request,
        CancellationToken cancellationToken)
    {
        var role = await roleRepository.GetByIdAsync(request.RoleId, cancellationToken);
        
        if (role is null)
        {
            return new RoleNotFoundError();
        }

        return mapper.Map<RoleDetailsDTO>(role);

    }
} 