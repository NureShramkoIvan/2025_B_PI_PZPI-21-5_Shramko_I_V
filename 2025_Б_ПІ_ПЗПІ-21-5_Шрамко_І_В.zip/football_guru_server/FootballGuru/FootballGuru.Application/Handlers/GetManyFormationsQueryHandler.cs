using AutoMapper;
using FootballGuru.Transport.DTOs.Formations;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Handlers;

public class GetManyFormationsQueryHandler(IFormationRepository formationRepository, IMapper mapper) 
    : IRequestHandler<GetManyFormationsQuery, IEnumerable<FormationDTO>>
{
    public async Task<IEnumerable<FormationDTO>> Handle(
        GetManyFormationsQuery request, 
        CancellationToken cancellationToken)
    {
        var formations = await formationRepository.GetManyAsync(cancellationToken);

        return mapper.Map<IEnumerable<FormationDTO>>(formations);
    }
} 