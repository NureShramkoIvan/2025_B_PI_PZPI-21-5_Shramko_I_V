﻿using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Domain;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.Errors;
using MediatR;
using Microsoft.AspNetCore.Identity;
using OneOf.Types;
using OneOf;

namespace FootballGuru.Application.Handlers;

internal class CreateTrainerCommandHandler(
    ITrainerRepository trainerRepository, 
    IPasswordHasher<User> passwordHasher) : IRequestHandler<CreateTrainerCommand, OneOf<None, UserNameNotUniqueError>>
{
    public async Task<OneOf<None, UserNameNotUniqueError>> Handle(CreateTrainerCommand request, CancellationToken cancellationToken)
    {
        var userNameExists = await trainerRepository.UserNameExistsAsync(request.Username, cancellationToken);

        if (userNameExists) return new UserNameNotUniqueError();

        var user = new User(request.Username, string.Empty);

        var passwordHash = passwordHasher.HashPassword(user, request.Password);

        user.PasswordHash = passwordHash;

        var trainer = new Trainer(user, request.FirstName, request.LastName);

        await trainerRepository.CreateAsync(trainer, request.Transaction, cancellationToken);

        return new None();
    }
}
