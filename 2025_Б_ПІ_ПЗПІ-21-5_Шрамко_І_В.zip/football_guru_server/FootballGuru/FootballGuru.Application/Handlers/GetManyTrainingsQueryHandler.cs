using AutoMapper;
using FootballGuru.Data.MongoDB.Repositories.Abstract;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Trainings;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Handlers;

internal class GetManyTrainingsQueryHandler(
    ITrainingRepository trainingRepository,
    IMapper mapper) : IRequestHandler<GetManyTrainingsQuery, PageDTO<TrainingDTO>>
{
    public async Task<PageDTO<TrainingDTO>> Handle(
        GetManyTrainingsQuery request,
        CancellationToken cancellationToken)
    {
        var trainings = await trainingRepository.GetManyAsync(
            request.Skip,
            request.Limit.HasValue ? request.Limit.Value + 1 : 101,
            request.TrainerId,
            cancellationToken);

        return new()
        {
            Data = mapper.Map<IEnumerable<TrainingDTO>>(trainings.Take(request.Limit ?? 100)),
            HasNext = request.Limit.HasValue ? trainings.Count > request.Limit.Value : trainings.Count > 100
        };
    }
} 