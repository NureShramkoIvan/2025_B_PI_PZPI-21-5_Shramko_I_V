using AutoMapper;
using FootballGuru.Data.MongoDB.Repositories.Abstract;
using FootballGuru.Transport.DTOs.Trainings;
using FootballGuru.Transport.Errors;
using FootballGuru.Transport.Queries;
using MediatR;
using OneOf;

namespace FootballGuru.Application.Handlers;

internal class GetTrainingByIdQueryHandler(
    ITrainingRepository trainingRepository,
    IMapper mapper) : IRequestHandler<GetTrainingByIdQuery, OneOf<TrainingDetailsDTO, TrainingNotFoundError>>
{
    public async Task<OneOf<TrainingDetailsDTO, TrainingNotFoundError>> Handle(
        GetTrainingByIdQuery request,
        CancellationToken cancellationToken)
    {
        var training = await trainingRepository.GetByIdAsync(
            request.Id,
            request.TrainerId,
            cancellationToken);

        if (training == null)
        {
            return new TrainingNotFoundError();
        }

        return mapper.Map<TrainingDetailsDTO>(training);
    }
} 