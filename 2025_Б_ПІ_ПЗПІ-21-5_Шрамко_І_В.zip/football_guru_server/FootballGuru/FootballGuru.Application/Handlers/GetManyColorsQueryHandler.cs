using AutoMapper;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.DTOs.Colors;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Handlers;

public class GetManyColorsQueryHandler(IColorRepository colorRepository, IMapper mapper) 
    : IRequestHandler<GetManyColorsQuery, PageDTO<ColorDTO>>
{
    public async Task<PageDTO<ColorDTO>> Handle(GetManyColorsQuery request, CancellationToken cancellationToken)
    {
        var colors = await colorRepository.GetManyAsync(request.Skip, request.Limit, cancellationToken);

        return new PageDTO<ColorDTO>()
        {
            Data = mapper.Map<IEnumerable<ColorDTO>>(colors),
            HasNext = request.Limit.HasValue ? colors.Count() > request.Limit.Value : colors.Count() > 100
        };
    }
} 