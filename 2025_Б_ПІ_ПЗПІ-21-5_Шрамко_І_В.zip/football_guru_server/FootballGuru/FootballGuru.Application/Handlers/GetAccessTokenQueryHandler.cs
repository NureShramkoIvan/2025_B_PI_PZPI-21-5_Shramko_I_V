﻿using FootballGuru.Application.Interfaces;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Domain;
using FootballGuru.Transport.DTOs.Identity;
using FootballGuru.Transport.Errors;
using FootballGuru.Transport.Queries;
using MediatR;
using Microsoft.AspNetCore.Identity;
using OneOf;
using System.Security.Claims;

namespace FootballGuru.Application.Handlers;

internal class GetAccessTokenQueryHandler(
    ITrainerRepository trainerRepository,
    IPasswordHasher<User> passwordHasher,
    IAccessTokenService accessTokenService) : IRequestHandler<GetAccessTokenQuery, OneOf<AccessTokenDTO, InvalidCredentialsError>>
{
    public async Task<OneOf<AccessTokenDTO, InvalidCredentialsError>> Handle(GetAccessTokenQuery request, CancellationToken cancellationToken)
    {
        var trainer = await trainerRepository.GetOneByUserName(request.UserName, cancellationToken);

        if (trainer is null) return new InvalidCredentialsError();

        var result = passwordHasher.VerifyHashedPassword(
            trainer.User,
            trainer.User.PasswordHash,
            request.Password);

        if(result is not PasswordVerificationResult.Success) return new InvalidCredentialsError();

        List<Claim> claims = [new("user_id", trainer.Id.ToString())];

        var (token, expiresAt) = accessTokenService.GenerateJwtToken(claims);

        return new AccessTokenDTO { AccessToken = token, ExpiresAt = expiresAt };
    }
}
