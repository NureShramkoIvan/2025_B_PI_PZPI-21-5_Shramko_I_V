using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Application.Handlers;

internal class DeleteRoleActionCommandHandler(
    IRoleRepository roleRepository) : IRequestHandler<DeleteRoleActionCommand, OneOf<None, RoleNotFoundError, RoleActionNotFoundError>>
{
    public async Task<OneOf<None, RoleNotFoundError, RoleActionNotFoundError>> Handle(
        DeleteRoleActionCommand request,

        CancellationToken cancellationToken)

    {
        var role = await roleRepository.GetByIdAsync(request.RoleId, cancellationToken);
        
        if (role is null)
        {
            return new RoleActionNotFoundError();
        }

        var roleActionExists = await roleRepository.ExistsAsync(request.RoleId, request.ActionId, cancellationToken);

        if (!roleActionExists)
        {
            return new RoleActionNotFoundError();
        }

        await roleRepository.DeleteActionAsync(request.RoleId, request.ActionId, request.Transaction, cancellationToken);

        // TODO: Implement role action deletion logic
        

        return new None();

    }
} 