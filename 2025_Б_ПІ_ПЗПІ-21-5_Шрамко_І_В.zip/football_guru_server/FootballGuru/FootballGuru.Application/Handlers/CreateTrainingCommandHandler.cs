using AutoMapper;
using FootballGuru.Data.MongoDB.Repositories.Abstract;
using FootballGuru.Data.SqlServer.Interfaces;
using FootballGuru.Domain;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.Errors;
using MediatR;
using OneOf;
using OneOf.Types;

namespace FootballGuru.Application.Handlers;

internal class CreateTrainingCommandHandler(
    IFormationRepository formationRepository,
    IPlayerRepository playerRepository,
    IRoleRepository roleRepository,
    IColorRepository colorRepository,
    ITrainingRepository trainingRepository,
    IMapper mapper) : IRequestHandler<CreateTrainingCommand, OneOf<None, FormationNotFoundError, PlayerNotFoundError>>
{
    public async Task<OneOf<None, FormationNotFoundError, PlayerNotFoundError>> Handle(
        CreateTrainingCommand request, 
        CancellationToken cancellationToken)
    {
        // Validate formations exist
        var formations = await formationRepository.GetManyAsync(cancellationToken);
        var formationIds = formations.Select(f => f.Id).ToList();

        if (!formationIds.Contains(request.TeamA.FormationId) ||
            !formationIds.Contains(request.TeamB.FormationId))
        {
            return new FormationNotFoundError();
        }

        // Get all players with their details
        var playerIds = request.TeamA.Players
            .Concat(request.TeamB.Players)
            .Select(p => p.PlayerId)
            .Distinct()
            .ToList();

        var players = await playerRepository.GetManyByIdsAsync(
            playerIds, 
            request.TrainerId,
            cancellationToken);

        if (players.Count != playerIds.Count)
        {  
            return new PlayerNotFoundError();
        }

        // Get roles for players that have them
        var roleIds = players
            .Where(p => p.RoleId.HasValue)
            .Select(p => p.RoleId.Value)
            .Distinct()
            .ToList();

        var roles = await roleRepository.GetManyByIdsAsync(roleIds, cancellationToken);

        var roleActions = roles
            .ToDictionary(
                r => r.Id,
                r => r.Actions?.Select(a => a.Action).ToList() ?? new List<string>());

        // Get colors
        var colors = await colorRepository.GetManyAsync(null, null, cancellationToken: cancellationToken);
        var colorMap = colors.ToDictionary(c => c.Id, c => c.Hex);

        var training = mapper.Map<Training>(request);
        training.Id = Guid.NewGuid();
        training.TrainerId = request.TrainerId;

        // Enrich team A players
        foreach (var player in training.TeamA.Players)
        {
            EnrichPlayerConfiguration(player, players, roleActions, colorMap);
        }

        // Enrich team B players
        foreach (var player in training.TeamB.Players)
        {
            EnrichPlayerConfiguration(player, players, roleActions, colorMap);
        }

        await trainingRepository.CreateAsync(training, cancellationToken);

        return new None();
    }

    private static void EnrichPlayerConfiguration(
        Training.PlayerConfiguration playerConfig,
        List<Player> players,
        Dictionary<int, List<string>> roleActions,
        Dictionary<int, string> colorMap)
    {
        var player = players.First(p => p.Id == playerConfig.PlayerId);
        
        playerConfig.FirstName = player.FirstName;
        playerConfig.LastName = player.LastName;
        
        // Combine custom actions with role actions if role exists
        var actions = playerConfig.Actions ?? new List<string>();
        if (player.RoleId.HasValue && roleActions.TryGetValue(player.RoleId.Value, out var roleActionList))
        {
            actions.AddRange(roleActionList);
        }
        playerConfig.Actions = actions.Distinct().ToList();

        // Set color hex if color exists
        if (colorMap.TryGetValue(playerConfig.ColorId, out var colorHex))
        {
            playerConfig.ColorHex = colorHex;
        }
    }
} 