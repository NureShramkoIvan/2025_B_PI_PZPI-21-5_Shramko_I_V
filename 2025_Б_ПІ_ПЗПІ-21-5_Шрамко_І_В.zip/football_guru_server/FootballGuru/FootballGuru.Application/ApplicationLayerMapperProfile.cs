﻿using AutoMapper;
using FootballGuru.Domain;
using FootballGuru.Transport.DTOs.Players;
using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.DTOs.Formations;
using FootballGuru.Transport.DTOs.Trainings;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.DTOs.Colors;
namespace FootballGuru.Application;

internal class ApplicationLayerMapperProfile : Profile
{
    public ApplicationLayerMapperProfile()
    {
        CreateMap<Player, PlayerDTO>();
        CreateMap<Role, RoleDTO>();
        CreateMap<Role, RoleDetailsDTO>();
        CreateMap<RoleAction, RoleActionDTO>();
        CreateMap<Formation, FormationDTO>();
        CreateMap<Formation.FormationLine, FormationDTO.FormationLineDTO>();
        CreateMap<Formation.FormationPosition, FormationDTO.FormationPositionDTO>();
        CreateMap<CreateTrainingDTO, CreateTrainingCommand>();
        CreateMap<CreateTrainingDTO.TeamConfigurationDTO, CreateTrainingCommand.TeamConfiguration>();
        CreateMap<CreateTrainingDTO.PlayerConfigurationDTO, CreateTrainingCommand.PlayerConfiguration>();
        CreateMap<CreateTrainingDTO.ZoneConfigurationDTO, CreateTrainingCommand.ZoneConfiguration>();
        CreateMap<CreateTrainingCommand, Training>();
        CreateMap<CreateTrainingCommand.TeamConfiguration, Training.TeamConfiguration>();
        CreateMap<CreateTrainingCommand.PlayerConfiguration, Training.PlayerConfiguration>()
            .ForMember(dest => dest.Actions, opt => opt.MapFrom(src => src.CustomActions));
        CreateMap<CreateTrainingCommand.ZoneConfiguration, Training.ZoneConfiguration>();
        CreateMap<Color, ColorDTO>();
        CreateMap<Training, TrainingDTO>();
        CreateMap<Training, TrainingDetailsDTO>();
        CreateMap<Training.TeamConfiguration, TrainingDetailsDTO.TeamConfigurationDTO>();
        CreateMap<Training.PlayerConfiguration, TrainingDetailsDTO.PlayerConfigurationDTO>();
        CreateMap<Training.ZoneConfiguration, TrainingDetailsDTO.ZoneConfigurationDTO>();
    }
}
