﻿using FootballGuru.Application.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Application.Validation.Players;
using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Players;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Facades;

internal class PlayerFacade(
    IDataLayerTransactionFactory dataLayerTransactionFactory,
    IMediator mediator) : LogicalLayerElement, IPlayerFacade
{
    public async Task<ServiceResponse> CreatePlayerAsync(
        CreatePlayerDTO createPlayerDTO,
        CancellationToken cancellationToken = default)
    {
        var validationResult = await new CreatePlayerDTOValidator().ValidateAsync(createPlayerDTO, cancellationToken);

        if (!validationResult.IsValid) return ValidationFailure(validationResult);

        //TODO: move to bus
        var transaction = dataLayerTransactionFactory.Create();

        var createPlayerResult = await mediator.Send(new CreatePlayerCommand()
        {
            FirstName = createPlayerDTO.FirstName,
            LastName = createPlayerDTO.LastName,
            DateOfBirth = createPlayerDTO.DateOfBirth,
            TrainerId = createPlayerDTO.TrainerId,
            RoleId = createPlayerDTO.RoleId,
            Transaction = transaction
        }, cancellationToken);

        transaction.Commit();

        return createPlayerResult.Match<ServiceResponse>(
            playerCreated => Success(),
            trainerNotFound => ValidationFailure("Trainer not found"));
    }

    public async Task<ServiceResponse<PageDTO<PlayerDTO>>> GetManyPlayers(
        GetManyPlayersDTO getManyPlayersDTO,
        CancellationToken cancellationToken)
    {
        var validationResult = await new GetManyPlayersDTOValidator().ValidateAsync(getManyPlayersDTO, cancellationToken);

        if (!validationResult.IsValid) return ValidationFailure<PageDTO<PlayerDTO>>(validationResult);

        var getManyPLayersResponse = await mediator.Send(new GetManyPlayersQuery(
            getManyPlayersDTO.Skip,
            getManyPlayersDTO.Limit,
            getManyPlayersDTO.TrainerId), cancellationToken);

        return Success(getManyPLayersResponse);
    }

    public async Task<ServiceResponse<PlayerDTO>> GetOnePlayerAsync(
        GetOnePlayerDTO getOnePlayerDTO,
        CancellationToken cancellationToken = default)
    {
        var getOnePlayerResponse = await mediator.Send(new GetOnePlayerQuery(
            getOnePlayerDTO.PlayerId,
            getOnePlayerDTO.TrainerId), cancellationToken);

        return getOnePlayerResponse.Match<ServiceResponse<PlayerDTO>>(
            player => Success(player),
            playerNotFound => NotFound<PlayerDTO>("Player not found"));

    }
}
