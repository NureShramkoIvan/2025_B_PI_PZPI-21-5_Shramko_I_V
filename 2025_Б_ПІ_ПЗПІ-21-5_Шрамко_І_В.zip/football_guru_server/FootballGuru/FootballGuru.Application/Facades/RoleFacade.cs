using FootballGuru.Application.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Application.Validation.Roles;
using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Roles;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Facades;

internal class RoleFacade(
    IMediator mediator,
    IDataLayerTransactionFactory dataLayerTransactionFactory)
    : LogicalLayerElement, IRoleFacade
{
    public async Task<ServiceResponse> CreateAsync(
        CreateRoleDTO request,
        CancellationToken cancellationToken = default)
    {
        var validationResult = await new CreateRoleDTOValidator().ValidateAsync(request, cancellationToken);

        if (!validationResult.IsValid) return ValidationFailure(validationResult);

        var transaction = dataLayerTransactionFactory.Create();

        await mediator.Send(new CreateRoleCommand
        {
            Name = request.Name,
            Transaction = transaction
        }, cancellationToken);

        transaction.Commit();

        return Success();
    }

    public async Task<ServiceResponse<PageDTO<RoleDTO>>> GetManyAsync(
        GetManyRolesDTO request,
        CancellationToken cancellationToken = default)
    {
        var getManyRolesResult = await mediator.Send(
            new GetManyRolesQuery(request.Skip, request.Limit),
            cancellationToken);

        return Success(getManyRolesResult);
    }

    public async Task<ServiceResponse<RoleDetailsDTO>> GetOneAsync(
        GetOneRoleDTO request,
        CancellationToken cancellationToken = default)

    {
        var getOneRoleResult = await mediator.Send(
            new GetOneRoleQuery(request.RoleId),
            cancellationToken);

        return getOneRoleResult.Match(
            role => Success<RoleDetailsDTO>(role),
            error => NotFound<RoleDetailsDTO>("Role not found"));

    }

    public async Task<ServiceResponse> CreateRoleActionAsync(
        CreateRoleActionDTO request,
        CancellationToken cancellationToken = default)
    {
        var validationResult = await new CreateRoleActionDTOValidator().ValidateAsync(request, cancellationToken);

        if (!validationResult.IsValid) return ValidationFailure(validationResult);

        var transaction = dataLayerTransactionFactory.Create();

        await mediator.Send(new CreateRoleActionCommand
        {
            RoleId = request.RoleId,
            Action = request.Action,
            Transaction = transaction
        }, cancellationToken);

        transaction.Commit();

        return Success();
    }

    public async Task<ServiceResponse> DeleteRoleActionAsync(
        DeleteRoleActionDTO request,
        CancellationToken cancellationToken = default)
    {
        var transaction = dataLayerTransactionFactory.Create();

        var result = await mediator.Send(new DeleteRoleActionCommand
        {
            RoleId = request.RoleId,
            ActionId = request.ActionId,
            Transaction = transaction
        }, cancellationToken);

        transaction.Commit();

        return result.Match<ServiceResponse>(
            _ => Success(),
            roleNotFound => NotFound("Role not found"),
            roleActionNotFound => NotFound("Role action not found"));
    }
}
