using FootballGuru.Application.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Formations;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Facades;

internal class FormationFacade(IMediator mediator) : LogicalLayerElement, IFormationFacade
{
    public async Task<ServiceResponse<IEnumerable<FormationDTO>>> GetManyFormationsAsync(
        CancellationToken cancellationToken = default)
    {
        var formations = await mediator.Send(new GetManyFormationsQuery(), cancellationToken);
        return Success(formations);
    }
} 