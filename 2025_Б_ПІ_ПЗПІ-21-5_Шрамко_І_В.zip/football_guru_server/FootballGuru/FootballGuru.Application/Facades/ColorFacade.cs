using FootballGuru.Application.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.DTOs.Colors;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Facades;

internal class ColorFacade(IMediator mediator) : LogicalLayerElement, IColorFacade
{
    public async Task<ServiceResponse<PageDTO<ColorDTO>>> GetManyAsync(
        PageRequestDTO request,
        CancellationToken cancellationToken = default)
    {
        var getManyColorsResult = await mediator.Send(
            new GetManyColorsQuery(request.Skip, request.Limit),
            cancellationToken);

        return Success(getManyColorsResult);
    }
} 