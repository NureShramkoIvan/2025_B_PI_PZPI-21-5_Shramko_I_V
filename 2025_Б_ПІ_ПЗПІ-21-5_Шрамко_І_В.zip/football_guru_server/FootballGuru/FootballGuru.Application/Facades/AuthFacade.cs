﻿using FootballGuru.Application.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Application.Validation.Identity;
using FootballGuru.Data.SqlServer.Transactions;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.DTOs.Identity;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Facades;

internal class AuthFacade(
    IMediator mediator,
    IDataLayerTransactionFactory dataLayerTransactionFactory) 
    : LogicalLayerElement, IAuthFacade
{
    public async Task<ServiceResponse> CreateUser(
        CreateUserDTO createUserDTO,
        CancellationToken cancellationToken = default)
    {
        var validationResult = await new CreateUserDTOValidator().ValidateAsync(createUserDTO, cancellationToken);

        if (!validationResult.IsValid) return ValidationFailure(validationResult);

        //TODO: move to bus
        var transaction = dataLayerTransactionFactory.Create();

        var createUserResult = await mediator.Send(new CreateTrainerCommand()
        {
            FirstName = createUserDTO.FirstName,
            LastName = createUserDTO.LastName,
            Password = createUserDTO.Password,
            Username = createUserDTO.Username,
            Transaction = transaction
        }, cancellationToken);

        transaction.Commit();

        //TODO: create extension methods wuth error messages for results
        return createUserResult.Match<ServiceResponse>(
            userCreated => Success(),
            userNameNotUnique => ValidationFailure("username already exists"));
    }

    public async Task<ServiceResponse<AccessTokenDTO>> GetAccessToken(
        GetAccessTokenDTO getAccessTokenDTO,
        CancellationToken cancellationToken = default)
    {
        //TODO: add validation

        var queryResult = await mediator.Send(new GetAccessTokenQuery()
        {
            Password = getAccessTokenDTO.Password,
            UserName = getAccessTokenDTO.Username
        }, cancellationToken);

        if (queryResult.IsT0) return Success(queryResult.AsT0);

        //TODO: create extension methods wuth error messages for results
        return ValidationFailure<AccessTokenDTO>("Invalid credentials");
    }
}
