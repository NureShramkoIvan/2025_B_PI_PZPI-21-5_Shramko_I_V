using AutoMapper;
using FootballGuru.Application.Common;
using FootballGuru.Application.Interfaces;
using FootballGuru.Transport.Commands;
using FootballGuru.Transport.DTOs.Common;
using FootballGuru.Transport.DTOs.Trainings;
using FootballGuru.Transport.Queries;
using MediatR;

namespace FootballGuru.Application.Facades;

internal class TrainingFacade(IMediator mediator, IMapper mapper) : LogicalLayerElement, ITrainingFacade
{
    public async Task<ServiceResponse> CreateTrainingAsync(
        CreateTrainingDTO createTrainingDTO,
        CancellationToken cancellationToken = default)
    {
        var command = mapper.Map<CreateTrainingCommand>(createTrainingDTO);

        var result = await mediator.Send(command, cancellationToken);

        return result.Match<ServiceResponse>(
            success => Success(),
            formationNotFound => ValidationFailure("Invalid formation ID"),
            playerNotFound => ValidationFailure("Players not found"));
    }

    public async Task<ServiceResponse<PageDTO<TrainingDTO>>> GetManyTrainingsAsync(
        GetManyTrainingsDTO getManyTrainingsDTO,
        CancellationToken cancellationToken = default)
    {
        var query = new GetManyTrainingsQuery(
            getManyTrainingsDTO.Skip,
            getManyTrainingsDTO.Limit,
            getManyTrainingsDTO.TrainerId);

        var result = await mediator.Send(query, cancellationToken);
        return Success(result);
    }

    public async Task<ServiceResponse<TrainingDetailsDTO>> GetTrainingByIdAsync(
        Guid id,
        int trainerId,
        CancellationToken cancellationToken = default)
    {
        var query = new GetTrainingByIdQuery(id, trainerId);
        var result = await mediator.Send(query, cancellationToken);

        return result.Match<ServiceResponse<TrainingDetailsDTO>>(
            training => Success(training),
            trainingNotFound => NotFound<TrainingDetailsDTO>("Training not found"));
    }
} 