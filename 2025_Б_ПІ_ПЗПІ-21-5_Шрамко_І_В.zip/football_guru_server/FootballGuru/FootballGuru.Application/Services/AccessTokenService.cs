﻿using FootballGuru.Application.Interfaces;
using FootballGuru.Application.Settings;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace FootballGuru.Application.Services;

public class AccessTokenService(IOptions<IdentitySettings> identitySettings) : IAccessTokenService
{
    private readonly IdentitySettings _identitySettings = identitySettings.Value;

    public (string token, DateTime expiresAt) GenerateJwtToken(IEnumerable<Claim> claims)
    {
        try
        {
            var jwtToken = new JwtSecurityToken(
                issuer: _identitySettings.Issuer,
                claims: claims,
                expires: DateTime.UtcNow.AddSeconds(_identitySettings.TokenExpiresAfterSeconds),
                signingCredentials: new SigningCredentials(
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_identitySettings.SecretKey)),
                    SecurityAlgorithms.HmacSha256));

            return
            (
                new JwtSecurityTokenHandler().WriteToken(jwtToken),
                DateTime.UtcNow.AddSeconds(_identitySettings.TokenExpiresAfterSeconds)
            );
        }
        catch (Exception ex)
        {
            //TODO: log exception
            //TODO: return error, handle error in handler
            return (null, DateTime.MinValue);
        }
    }
}
