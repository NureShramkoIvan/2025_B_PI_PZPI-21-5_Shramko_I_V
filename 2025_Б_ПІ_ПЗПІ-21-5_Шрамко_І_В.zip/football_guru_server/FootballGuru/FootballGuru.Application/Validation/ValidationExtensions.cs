﻿using FluentValidation;
using System.Text.RegularExpressions;

namespace FootballGuru.Application.Validation;

internal static partial class ValidationExtensions
{
    [GeneratedRegex("[a-z]", RegexOptions.Compiled)]
    private static partial Regex _passwordRule();

    public static IRuleBuilderOptions<T, string> Password<T>(this IRuleBuilder<T, string> ruleBuilder) 
        => ruleBuilder.Must(p => _passwordRule().IsMatch(p));
}
