﻿using FluentValidation;
using FootballGuru.Transport.DTOs.Players;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Application.Validation.Players;

internal class CreatePlayerDTOValidator : AbstractValidator<CreatePlayerDTO>
{
    public CreatePlayerDTOValidator()
    {
        
    }
}
