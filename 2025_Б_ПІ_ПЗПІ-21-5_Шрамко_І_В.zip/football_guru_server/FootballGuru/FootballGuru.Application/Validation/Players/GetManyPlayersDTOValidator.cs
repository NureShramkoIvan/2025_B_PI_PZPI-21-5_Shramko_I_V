using FluentValidation;
using FootballGuru.Transport.DTOs.Players;

namespace FootballGuru.Application.Validation.Players;

public class GetManyPlayersDTOValidator : AbstractValidator<GetManyPlayersDTO>
{
    public GetManyPlayersDTOValidator()
    {
        RuleFor(x => x.TrainerId)
            .NotNull();
    }
}
