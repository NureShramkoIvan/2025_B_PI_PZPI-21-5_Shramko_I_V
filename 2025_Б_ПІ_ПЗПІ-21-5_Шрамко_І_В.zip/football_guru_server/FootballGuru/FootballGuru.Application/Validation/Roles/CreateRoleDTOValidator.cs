using FootballGuru.Transport.DTOs.Roles;
using FluentValidation;

namespace FootballGuru.Application.Validation.Roles;

public class CreateRoleDTOValidator : AbstractValidator<CreateRoleDTO>
{
    public CreateRoleDTOValidator()
    {
        RuleFor(x => x.Name).NotEmpty();
    }
}