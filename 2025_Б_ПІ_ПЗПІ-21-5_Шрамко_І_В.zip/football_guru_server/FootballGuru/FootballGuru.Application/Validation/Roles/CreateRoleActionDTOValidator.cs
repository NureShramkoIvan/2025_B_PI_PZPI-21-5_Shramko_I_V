using FluentValidation;
using FootballGuru.Transport.DTOs.Roles;

namespace FootballGuru.Application.Validation.Roles;

public class CreateRoleActionDTOValidator : AbstractValidator<CreateRoleActionDTO>
{
    public CreateRoleActionDTOValidator()
    {
        RuleFor(x => x.Action).NotEmpty();
    }
} 