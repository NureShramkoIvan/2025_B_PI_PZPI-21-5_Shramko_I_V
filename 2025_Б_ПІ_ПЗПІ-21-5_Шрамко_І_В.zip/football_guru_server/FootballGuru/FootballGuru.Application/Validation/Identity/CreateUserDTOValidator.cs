﻿using FluentValidation;
using FootballGuru.Transport.DTOs.Identity;

namespace FootballGuru.Application.Validation.Identity;

internal class CreateUserDTOValidator : AbstractValidator<CreateUserDTO>
{
    public CreateUserDTOValidator()
    {
        RuleFor(m => m.Username)
            .NotEmpty()
            .MinimumLength(4)
            .MaximumLength(12);

        RuleFor(m => m.Password)
            .NotEmpty()
            .Password();

        RuleFor(m => m.FirstName)
            .NotEmpty();

        RuleFor(m => m.LastName)
            .NotEmpty();
    }
}
