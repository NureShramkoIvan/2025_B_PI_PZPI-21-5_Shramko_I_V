﻿using FootballGuru.Application.Facades;
using FootballGuru.Application.Interfaces;
using FootballGuru.Application.Services;
using FootballGuru.Application.Settings;
using FootballGuru.Data.MongoDB;
using FootballGuru.Data.SqlServer;
using FootballGuru.Domain;
using FootballGuru.Transport;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FootballGuru.Application;

public static class DependencyModule
{
    public static IServiceCollection AddApplication(
        this IServiceCollection services,
        string sqlServerConnectionString,
        string mongoDbConnectionString,
        IConfigurationSection identitySettings)
    {
        services.AddDataAccess(sqlServerConnectionString);
        services.AddMongoDb(mongoDbConnectionString);
        services.AddTransport();

        //TODO: move to transport
        services.AddMediatR(c => c.RegisterServicesFromAssemblies(typeof(DependencyModule).Assembly));

        //TODO: do not user domain models
        services.AddTransient<IPasswordHasher<User>, UserPasswordHasher>();

        services.AddScoped<IAuthFacade, AuthFacade>();
        services.AddScoped<IPlayerFacade, PlayerFacade>();
        services.AddScoped<IRoleFacade, RoleFacade>();
        services.AddScoped<IFormationFacade, FormationFacade>();
        services.AddScoped<ITrainingFacade, TrainingFacade>();
        services.AddScoped<IColorFacade, ColorFacade>();

        services.AddScoped<IAccessTokenService, AccessTokenService>();

        services.AddAutoMapper(c => c.AddProfile(new ApplicationLayerMapperProfile()));

        services.Configure<IdentitySettings>(identitySettings);
        return services;
    }
}
