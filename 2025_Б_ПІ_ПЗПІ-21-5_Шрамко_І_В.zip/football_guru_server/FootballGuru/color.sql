create table colors
(
    id int primary key identity,
    hex varchar(7) not null
)

drop table colors;

insert into colors (hex) values ('#FF0000'); -- Red
insert into colors (hex) values ('#0000FF'); -- Blue
insert into colors (hex) values ('#00FF00'); -- Green
insert into colors (hex) values ('#FFFF00'); -- Yellow
insert into colors (hex) values ('#FF00FF'); -- Magenta
insert into colors (hex) values ('#00FFFF'); -- Cyan
insert into colors (hex) values ('#FFA500'); -- Orange
insert into colors (hex) values ('#800080'); -- Purple
insert into colors (hex) values ('#008000'); -- Dark Green
insert into colors (hex) values ('#FF69B4'); -- Hot Pink
insert into colors (hex) values ('#4B0082'); -- Indigo



