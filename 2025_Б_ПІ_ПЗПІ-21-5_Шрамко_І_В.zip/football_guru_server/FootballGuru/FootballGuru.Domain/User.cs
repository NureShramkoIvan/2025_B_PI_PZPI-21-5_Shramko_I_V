﻿namespace FootballGuru.Domain;

public class User(string userName, string passwordHash)
{
    public string UserName { get; set; } = userName;
    public string PasswordHash { get; set; } = passwordHash;
}
