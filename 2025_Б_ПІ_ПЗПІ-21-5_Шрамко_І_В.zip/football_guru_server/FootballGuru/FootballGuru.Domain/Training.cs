namespace FootballGuru.Domain;

public class Training
{
    public Guid Id { get; set; }
    public int TrainerId { get; set; }
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public TeamConfiguration TeamA { get; set; }
    public TeamConfiguration TeamB { get; set; }
    
    public class TeamConfiguration
    {
        public int FormationId { get; set; }
        public List<PlayerConfiguration> Players { get; set; }
    }

    public class PlayerConfiguration
    {
        public int PlayerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> Actions { get; set; }
        public ZoneConfiguration Zone { get; set; }
        public int ColorId { get; set; }
        public string ColorHex { get; set; }
    }

    public class ZoneConfiguration
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    }
}