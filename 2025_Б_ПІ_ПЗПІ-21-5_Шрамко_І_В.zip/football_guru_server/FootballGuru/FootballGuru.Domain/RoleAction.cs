namespace FootballGuru.Domain;

public class RoleAction
{
    public int Id { get; set; }
    public string Action { get; set; }
    public int RoleId { get; set; }
}
