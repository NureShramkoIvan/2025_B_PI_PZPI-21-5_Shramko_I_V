﻿namespace FootballGuru.Domain;

public class Trainer(User user, string firstName, string lastName)
{
    public int Id { get; set; }
    public string FirstName { get; set; } = firstName;
    public string LastName { get; set; } = lastName;
    public User User { get; } = user;
}
