namespace FootballGuru.Domain;

public class Formation
{
    public int Id { get; set; }
    public string Name { get; set; }

    public List<FormationLine> Lines { get; set; }

    public class FormationLine
    {
        public int Order { get; set; }
        public List<FormationPosition> Positions { get; set; }
    }


    public class FormationPosition
    {
        public int Order { get; set; }
    }
}