namespace FootballGuru.Domain;

public class Color
{
    public int Id { get; set; }
    public string Hex { get; set; }
}

