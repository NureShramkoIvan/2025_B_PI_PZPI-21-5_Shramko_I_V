﻿namespace FootballGuru.Screen.App;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute(nameof(Pages.MainPage), typeof(Pages.MainPage));
    }
}
