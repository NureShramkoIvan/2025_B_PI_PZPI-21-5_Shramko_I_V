﻿using FootballGuru.Screen.App.Queues;
using System.Timers;

namespace FootballGuru.Screen.App.Pages;

public partial class MainPage : ContentPage
{
    private readonly NotificationsQueue _notificationsQueue;
    private System.Timers.Timer _notificationTimer;
    private const string DefaultText = "No notifications";
    private const string DefaultBackgroundColor = "#353757";

    public MainPage(NotificationsQueue notificationsQueue)
    {
        InitializeComponent();
        _notificationsQueue = notificationsQueue;

        // Set default values
        NotificationLabel.Text = DefaultText;
        BackgroundColor = Color.FromArgb(DefaultBackgroundColor);

        _notificationTimer = new System.Timers.Timer(10_000); // 60 seconds
        _notificationTimer.Elapsed += OnNotificationTimerElapsed;
        // Setup timer to check notifications every 60 seconds
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _notificationTimer.Start();
    }

    private void OnNotificationTimerElapsed(object sender, ElapsedEventArgs e)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            if (!_notificationsQueue.IsEmpty())
            {
                var notification = _notificationsQueue.Dequeue();
                if (notification != null)
                {
                    NotificationLabel.Text = notification.Text;
                    BackgroundColor = Color.FromArgb(notification.BackgroundColor);
                }
            }
            else
            {
                // Reset to default values if no notifications
                NotificationLabel.Text = DefaultText;
                BackgroundColor = Color.FromArgb(DefaultBackgroundColor);
            }
        });
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _notificationTimer.Stop();
        _notificationTimer.Dispose();
    }
}