using FootballGuru.Screen.App.Infrastructure;
using FootballGuru.Screen.App.States;
using System.Diagnostics;
using System.Net;

namespace FootballGuru.Screen.App.Pages;

public partial class StartPage : ContentPage
{
    private readonly IWifiDirect _wifi;
    private readonly TrainingState _trainingState;
    private readonly MessagingService _messagingService;

    public StartPage(IWifiDirect wifi, TrainingState trainingState, MessagingService messagingService)
    {
        InitializeComponent();
        _wifi = wifi;
        _trainingState = trainingState;
        _messagingService = messagingService;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _wifi.StartAsync();           // only sets up broadcast receiver
    }

    private async void OnStartButtonClicked(object sender, EventArgs e)
    {

        var loc = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (loc != PermissionStatus.Granted)
                loc = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            
            var status = await Permissions.CheckStatusAsync<Permissions.NearbyWifiDevices>();
            if (status != PermissionStatus.Granted)
                status = await Permissions.RequestAsync<Permissions.NearbyWifiDevices>();
            
            if (loc != PermissionStatus.Granted || status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permissions required",
                    "Camera + location permissions are required for P2P discovery.",
                    "OK");
                return;
            }

            //var cts = new CancellationTokenSource(15_000);

        //Task.Run(async () =>
        //{
            //await _wifi.StartAsync();           // only sets up broadcast receiver
            var serverEp = await _wifi.ConnectAsync();      // returns when info is available

            if (serverEp == null)
            {
                await DisplayAlert("Error", "WI-FI direct hub not found", "OK");
                //_wifi.Stop();

                return;
            }

            Debug.WriteLine("WI-FI direct hub connected");


            await _messagingService.ConnectAsync(serverEp);

            var ackMessage = new Message<string>()
            {
                Type = MessageTypes.ACK,
                Data = AllowedPeers.SCREEN
            };

            await _messagingService.SendMessage(ackMessage);

            await DisplayAlert("Info", "Sent ack", "OK");


        //}, cts.Token);
        
    }

    protected override void OnDisappearing()
    {
        _wifi.Stop();
        base.OnDisappearing();
    }
} 