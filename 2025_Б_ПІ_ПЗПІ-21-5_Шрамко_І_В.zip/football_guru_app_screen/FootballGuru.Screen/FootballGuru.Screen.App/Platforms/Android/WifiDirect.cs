﻿using Android.Content;
using Android.Net.Wifi.P2p;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using Android.Runtime;
using FootballGuru.Screen.App.Infrastructure;
using Microsoft.VisualBasic;
using System.Diagnostics;
using FootballGuru.Screen.App.Platforms.Android;

namespace FootballGuru.Screen.App.Platforms.Android;

public class WifiDirect : Java.Lang.Object, IWifiDirect,
                                WifiP2pManager.IPeerListListener,
                                WifiP2pManager.IConnectionInfoListener
{
    WifiP2pManager _manager;
    WifiP2pManager.Channel _channel;
    WifiDirectBroadcastReceiver _receiver;

    // will complete once we know the GO ip
    TaskCompletionSource<IPEndPoint?> _tcsServer;

    bool _isConnected = false;

    public async Task StartAsync()
    {
        var ctx = Platform.CurrentActivity;
        _manager = (WifiP2pManager)ctx.GetSystemService(Context.WifiP2pService);
        _channel = _manager.Initialize(ctx, ctx.MainLooper, null);

        // 1) register the broadcast receiver
        _receiver = new WifiDirectBroadcastReceiver(_manager, _channel);
        var filter = new IntentFilter();
        filter.AddAction(WifiP2pManager.WifiP2pStateChangedAction);
        filter.AddAction(WifiP2pManager.WifiP2pPeersChangedAction);
        filter.AddAction(WifiP2pManager.WifiP2pConnectionChangedAction);
        ctx.RegisterReceiver(_receiver, filter);

        // 2) *subscribe* to its events*
    }

    public Task<IPEndPoint?> ConnectAsync(string? ssidHint = null)
    {
        //_manager.RemoveGroup(_channel, new SimpleActionListener());
        // reset for each call
        _tcsServer = new TaskCompletionSource<IPEndPoint?>();

        _receiver.PeersChanged += OnPeersAvailable;
        _receiver.ConnectionInfoAvailable += OnConnectionInfoAvailable;

        var listener = new SimpleActionListener();

        listener.Failure += reason =>
        {
            Debug.WriteLine($"DiscoverPeers failed: {reason}");
            _tcsServer.TrySetResult(null);
        };

        var wifiDirect = this;

        listener.Success += () =>
        {
            Debug.WriteLine("DiscoverPeers ok");
            _manager.RequestPeers(_channel, wifiDirect);
        };

        // kick off peer discovery
        _manager.DiscoverPeers(_channel, listener);

        //_manager.RemoveGroup(_channel, new SimpleActionListener());
        //
        //_manager.DiscoverPeers(_channel, listener);

        return _tcsServer.Task;
    }

    // IPeerListListener
    public void OnPeersAvailable(WifiP2pDeviceList peers)
    {
        var device = peers.DeviceList.FirstOrDefault();
        if (device == null)
        {
            // no peers yet, wait for next broadcast
            return;
        }

        // connect to the first one we see
        var config = new WifiP2pConfig { DeviceAddress = device.DeviceAddress };

        var listener = new SimpleActionListener();

        listener.Success += () =>
        {
            Debug.WriteLine("Connect() succeeded, waiting for ConnectionChanged");
            _manager.RequestConnectionInfo(_channel, this);
        };

        listener.Failure += (reason) => 
        {
            Debug.WriteLine($"failed connect() reason: {reason}");
            _tcsServer.TrySetResult(null);
        };

        _manager.Connect(_channel, config, listener);
    }
    // IConnectionInfoListener
//    public void OnConnectionInfoAvailable(WifiP2pInfo info)
//    {
//        if (!info.GroupFormed)
//            return;
//
//        // either role will give you the IP of the group owner:
//        var host = info.GroupOwnerAddress.HostAddress;
//        Debug.WriteLine($"OnConnectionInfoAvailable – GO is at {host}, amOwner={info.IsGroupOwner}");
//        var ep = new IPEndPoint(IPAddress.Parse(host), 8888);
//
//        _tcsServer.TrySetResult(ep);
//    }

    public void OnConnectionInfoAvailable(WifiP2pInfo info)
    {
        if (info.GroupFormed && !info.IsGroupOwner && _tcsServer != null)
        {
            var ep = new IPEndPoint(IPAddress.Parse(info.GroupOwnerAddress.HostAddress), 8888);
            _tcsServer.TrySetResult(ep);
            //Debug.WriteLine($"OnConnectionInfoAvailable – GO is at {info.GroupOwnerAddress.HostAddress}, amOwner={info.IsGroupOwner}");

            // unsubscribe so a late broadcast can’t race in again
            _receiver.ConnectionInfoAvailable -= OnConnectionInfoAvailable;
            _isConnected = true;
        }
    }


    // ---------- sockets ----------
    public async Task<byte[]> ReceiveAsync(int port = 8888, int expectedBytes = 0)
    {
        var endPoint = await _tcsServer.Task;          // wait group owner IP
        using var client = new TcpClient();
        await client.ConnectAsync(endPoint.Address, port);
        using var ns = client.GetStream();

        using var ms = new MemoryStream();
        await ns?.CopyToAsync(ms);
        return ms?.ToArray();
    }

    public Task SendAsync(byte[] data, int port = 8888)
        => throw new NotSupportedException("Camera only receives");

    public Task<IPEndPoint?> CreateGroupAsync()
        => throw new NotSupportedException("Camera is peer");

    public void Stop() { /* unregister receiver, cancel discover */ }

    public bool IsConnected() => _isConnected;

    public Task<IPEndPoint?> GetServerIP() => _tcsServer.Task;
}

// Simple listener implementation
public class SimpleActionListener : Java.Lang.Object, WifiP2pManager.IActionListener
{
    public event Action Success;
    public event Action<string> Failure;

    public void OnSuccess()
    {
        Success?.Invoke();
    }

    public void OnFailure([GeneratedEnum] WifiP2pFailureReason reason)
    {
        Failure?.Invoke(reason.ToString());
    }
}
