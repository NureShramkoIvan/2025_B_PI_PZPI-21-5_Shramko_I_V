﻿using FootballGuru.Screen.App.Infrastructure;
using FootballGuru.Screen.App.Platforms.Android;

namespace FootballGuru.Screen.App;

public static class DependencyModule
{
    public static IServiceCollection AddPlatformServices(this IServiceCollection services)
    {
        services.AddSingleton<IWifiDirect, WifiDirect>();
        return services;
    }
}
