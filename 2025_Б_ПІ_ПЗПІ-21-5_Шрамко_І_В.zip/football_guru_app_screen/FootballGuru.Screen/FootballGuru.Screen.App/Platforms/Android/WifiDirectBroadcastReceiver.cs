﻿using Android.Content;
using Android.Net.Wifi.P2p;
using Android.Net.Wifi.P2p.Nsd;
using Android.Net;
using System;
using Android.Util;
using Android.Net.Wifi.P2p;

namespace FootballGuru.Screen.App.Platforms.Android;

public class WifiDirectBroadcastReceiver : BroadcastReceiver
{
    readonly WifiP2pManager _manager;
    readonly WifiP2pManager.Channel _channel;

    public event Action<WifiP2pDeviceList> PeersChanged;
    public event Action<WifiP2pInfo> ConnectionInfoAvailable;

    public WifiDirectBroadcastReceiver(WifiP2pManager manager, WifiP2pManager.Channel channel)
    {
        _manager = manager;
        _channel = channel;
    }

    public override void OnReceive(Context context, Intent intent)
    {
        string action = intent.Action;

        if (action == WifiP2pManager.WifiP2pPeersChangedAction)
        {
            // request updated list of peers
            _manager.RequestPeers(_channel, new PeerListListener(PeersChanged));
        }
        else if (action == WifiP2pManager.WifiP2pConnectionChangedAction)
        {
            var state = intent.GetIntExtra(WifiP2pManager.ExtraWifiState, -1);
            Log.Debug("P2P", $"STATE_CHANGED: {state} (ENABLED={WifiP2pState.Enabled})");

            var networkInfo = (NetworkInfo)intent.GetParcelableExtra(WifiP2pManager.ExtraNetworkInfo);
            if (networkInfo is not null && networkInfo.IsConnected)
            {
              // request connection info (GO IP etc)
              _manager.RequestConnectionInfo(_channel, new ConnectionInfoListener(ConnectionInfoAvailable));
            }
        }
    }

    class PeerListListener : Java.Lang.Object, WifiP2pManager.IPeerListListener
    {
        readonly Action<WifiP2pDeviceList> _callback;
        public PeerListListener(Action<WifiP2pDeviceList> cb) => _callback = cb;
        public void OnPeersAvailable(WifiP2pDeviceList peers) => _callback?.Invoke(peers);
    }

    class ConnectionInfoListener : Java.Lang.Object, WifiP2pManager.IConnectionInfoListener
    {
        readonly Action<WifiP2pInfo> _callback;
        public ConnectionInfoListener(Action<WifiP2pInfo> cb) => _callback = cb;
        public void OnConnectionInfoAvailable(WifiP2pInfo info) => _callback?.Invoke(info);
    }
}