using System.Text.Json;
using FootballGuru.Screen.App.Models;

namespace FootballGuru.Screen.App.States;

public class TrainingState
{
    public TrainingState()
    {
        TrainingDetails = GenerateMockTraining();
    }

    public string TrainingJson { get; set; }
    public TrainingDetailsModel TrainingDetails { get; set; }

    public void UpdateFromJson(string json)
    {
        TrainingJson = json;
        TrainingDetails = JsonSerializer.Deserialize<TrainingDetailsModel>(json);
    }

    public void Set(TrainingDetailsModel trainingDetailsModel)
    {
        TrainingDetails = trainingDetailsModel;
    }

    public static TrainingDetailsModel GenerateMockTraining()
    {
        return new TrainingDetailsModel
        {
            Id = Guid.Parse("6486392e-8d81-4efb-ab36-9e0f80096fee"),
            Name = "vgvgvgvgvg",
            DateTime = DateTime.Parse("2025-02-27T20:47:41.855Z"),
            TeamA = new TrainingDetailsModel.TeamConfigurationModel
            {
                FormationId = 1,
                Players = new List<TrainingDetailsModel.PlayerConfigurationModel>
                {
                    new()
                    {
                        PlayerId = 7,
                        FirstName = "roler",
                        LastName = "ole",
                        Line = 2,
                        Position = 1,
                        Actions = new List<string>(),
                        Zone = new TrainingDetailsModel.ZoneConfigurationModel
                        {
                            LeftDistanceCm = 30,
                            RightDistanceCm = 50,
                            TopDistanceCm = 50,
                            BottomDistanceCm = 30
                        },
                        ColorId = 8,
                        ColorHex = "#213d63"
                    },
                    //new()
                    //{
                    //    PlayerId = 9,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 2,
                    //    Position = 2,
                    //    Actions = new List<string> { "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 1436.34,
                    //        RightDistanceCm = 399.75,
                    //        TopDistanceCm = 2067.74,
                    //        BottomDistanceCm = 1745.11
                    //    },
                    //    ColorId = 11,
                    //    ColorHex = "#4B0082"
                    //},
                    //new()
                    //{
                    //    PlayerId = 10,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 3,
                    //    Position = 1,
                    //    Actions = new List<string> { "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 703.01,
                    //        RightDistanceCm = 1133.08,
                    //        TopDistanceCm = 3117.74,
                    //        BottomDistanceCm = 695.11
                    //    },
                    //    ColorId = 3,
                    //    ColorHex = "#00FF00"
                    //},
                    //new()
                    //{
                    //    PlayerId = 6,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 1,
                    //    Position = 1,
                    //    Actions = new List<string> { "vvggvvgvg", "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 1069.67,
                    //        RightDistanceCm = 766.42,
                    //        TopDistanceCm = 1017.74,
                    //        BottomDistanceCm = 2795.11
                    //    },
                    //    ColorId = 4,
                    //    ColorHex = "#FFFF00"
                    //},
                    //new()
                    //{
                    //    PlayerId = 11,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 3,
                    //    Position = 2,
                    //    Actions = new List<string> { "vggvvgvg", "rttrrtrt", "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 1436.34,
                    //        RightDistanceCm = 399.75,
                    //        TopDistanceCm = 3117.74,
                    //        BottomDistanceCm = 695.11
                    //    },
                    //    ColorId = 9,
                    //    ColorHex = "#008000"
                    //}
                }
            },
            TeamB = new TrainingDetailsModel.TeamConfigurationModel
            {
                FormationId = 2,
                Players = new List<TrainingDetailsModel.PlayerConfigurationModel>
                {
                    //new()
                    //{
                    //    PlayerId = 6,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 1,
                    //    Position = 1,
                    //    Actions = new List<string> { "errerererere", "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 703.01,
                    //        RightDistanceCm = 1133.08,
                    //        TopDistanceCm = 1017.74,
                    //        BottomDistanceCm = 2795.11
                    //    },
                    //    ColorId = 6,
                    //    ColorHex = "#00FFFF"
                    //},
                    //new()
                    //{
                    //    PlayerId = 10,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 3,
                    //    Position = 2,
                    //    Actions = new List<string> { "vgvvgvgvgvgvg", "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 1436.34,
                    //        RightDistanceCm = 399.75,
                    //        TopDistanceCm = 3117.74,
                    //        BottomDistanceCm = 695.11
                    //    },
                    //    ColorId = 5,
                    //    ColorHex = "#FF00FF"
                    //},
                    //new()
                    //{
                    //    PlayerId = 9,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 3,
                    //    Position = 1,
                    //    Actions = new List<string> { "uiiuiuiuiiuiu", "vggvgvvgvggv", "vggvvgvgvg" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 703.01,
                    //        RightDistanceCm = 1133.08,
                    //        TopDistanceCm = 3117.74,
                    //        BottomDistanceCm = 695.11
                    //    },
                    //    ColorId = 3,
                    //    ColorHex = "#00FF00"
                    //},
                    //new()
                    //{
                    //    PlayerId = 8,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 2,
                    //    Position = 1,
                    //    Actions = new List<string> { "nmmnmmnmn" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 1069.67,
                    //        RightDistanceCm = 766.42,
                    //        TopDistanceCm = 2067.74,
                    //        BottomDistanceCm = 1745.11
                    //    },
                    //    ColorId = 11,
                    //    ColorHex = "#4B0082"
                    //},
                    //new()
                    //{
                    //    PlayerId = 7,
                    //    FirstName = "roler",
                    //    LastName = "ole",
                    //    Line = 1,
                    //    Position = 2,
                    //    Actions = new List<string> { "zxxzzxzxzxxz" },
                    //    Zone = new TrainingDetailsModel.ZoneConfigurationModel
                    //    {
                    //        LeftDistanceCm = 1436.34,
                    //        RightDistanceCm = 399.75,
                    //        TopDistanceCm = 1017.74,
                    //        BottomDistanceCm = 2795.11
                    //    },
                    //    ColorId = 10,
                    //    ColorHex = "#FF69B4"
                    //}
                }
            }
        };
    }
}