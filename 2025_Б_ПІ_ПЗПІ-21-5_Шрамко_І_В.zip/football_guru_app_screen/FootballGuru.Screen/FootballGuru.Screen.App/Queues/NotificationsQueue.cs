﻿namespace FootballGuru.Screen.App.Queues;

public class NotificationsQueue
{
    private readonly object _lock = new();
    private readonly Queue<NotificationsQueueItem> _queue = new();

    public void Enqueue(NotificationsQueueItem item)
    {
        lock (_lock)
        {
            _queue.Enqueue(item);
        }
        System.Diagnostics.Debug.WriteLine($"Notifications queue: {_queue.Count}");
    }

    public NotificationsQueueItem Dequeue()
    {
        lock (_lock)
        {
            var isSuccess = _queue.TryDequeue(out var item);
            return isSuccess ? item : null;
        }
    }

    public bool IsEmpty()
    {
        lock (_lock)
        {
            return !_queue.Any();
        }
    }
}

public class NotificationsQueueItem
{
    public string Text { get; set; }
    public string BackgroundColor { get; set; }
}
