﻿using FootballGuru.Screen.App.States;
using FootballGuru.Screen.App.Infrastructure;
using FootballGuru.Screen.App.test.Infrastructure.Handlers;
using Microsoft.Extensions.Logging;
using FootballGuru.Screen.App.Pages;
using FootballGuru.Screen.App.Infrastructure.Handlers;
using FootballGuru.Screen.App.Queues;

namespace FootballGuru.Screen.App;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

		builder.Logging.AddDebug();
        builder.Services.AddSingleton<MessagingService>();
        builder.Services.AddSingleton<TrainingConfigurationMessageHandler>();
        builder.Services.AddSingleton<PlayerPositionViolationMessageHandler>();
        builder.Services.AddSingleton<CustomActionMessageHandler>();
        builder.Services.AddSingleton<MessagesHandler>((sp) =>
        {
            var messagesHandler = new MessagesHandler(sp);
            messagesHandler.RegisterHandler(MessageTypes.TRAINING_CONFIG, typeof(TrainingConfigurationMessageHandler));
            messagesHandler.RegisterHandler(MessageTypes.POSITION_VIOLATION, typeof(PlayerPositionViolationMessageHandler));
            messagesHandler.RegisterHandler(MessageTypes.CUSTOM_ACTION, typeof(CustomActionMessageHandler));

            return messagesHandler;
        });

#if ANDROID
        builder.Services.AddPlatformServices();
#endif

        builder.Services.AddSingleton<TrainingState>();

        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddSingleton<StartPage>();

        builder.Services.AddSingleton<NotificationsQueue>();

        return builder.Build();
    }
}
