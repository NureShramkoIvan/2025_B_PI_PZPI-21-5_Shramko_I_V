﻿namespace FootballGuru.Screen.App.Infrastructure.Messages;

public class PositionViolationMessage
{
    public int PlayerId { get; set; }
    public int Direction { get; set; }
}
