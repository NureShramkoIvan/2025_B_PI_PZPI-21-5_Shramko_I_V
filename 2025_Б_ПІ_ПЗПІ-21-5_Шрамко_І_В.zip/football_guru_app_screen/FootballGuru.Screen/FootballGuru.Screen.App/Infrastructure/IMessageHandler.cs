﻿namespace FootballGuru.Screen.App.Infrastructure;

public interface IMessageHandler
{
    Task Handle(string messageJson);
}
