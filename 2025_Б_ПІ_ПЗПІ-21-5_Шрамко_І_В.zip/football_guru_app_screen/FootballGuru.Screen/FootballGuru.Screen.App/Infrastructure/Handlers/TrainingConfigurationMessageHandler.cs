﻿using FootballGuru.Screen.App.Infrastructure;
using FootballGuru.Screen.App.Models;
using FootballGuru.Screen.App.Pages;
using FootballGuru.Screen.App.States;
using FootballGuru.Screen.App.test.Infrastructure;
using System.Text.Json;

namespace FootballGuru.Screen.App.test.Infrastructure.Handlers;

internal class TrainingConfigurationMessageHandler(TrainingState trainingState) : IMessageHandler
{
    public async Task Handle(string messageJson)
    {
        var message = JsonSerializer.Deserialize<Message<TrainingDetailsModel>>(messageJson);

        trainingState.Set(message.Data);

        await MainThread.InvokeOnMainThreadAsync(() =>
            Shell.Current.GoToAsync(nameof(MainPage))
        ).ConfigureAwait(false);    
    }
}
