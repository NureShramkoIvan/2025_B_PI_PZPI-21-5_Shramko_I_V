﻿using FootballGuru.Screen.App.Infrastructure.Messages;
using FootballGuru.Screen.App.Queues;
using FootballGuru.Screen.App.States;
using System.Diagnostics;
using System.Text.Json;

namespace FootballGuru.Screen.App.Infrastructure.Handlers;
internal class CustomActionMessageHandler(
    TrainingState trainingState,
    NotificationsQueue notificationsQueue) : IMessageHandler
{
    public async Task Handle(string messageJson)
    {
        var message = JsonSerializer.Deserialize<Message<CustomActionMessage>>(messageJson);
        Debug.WriteLine($"action message received | player {message.Data.PlayerId} | action: {message.Data.Action}");

        var player = trainingState.TrainingDetails.TeamA.Players.Concat(trainingState.TrainingDetails.TeamB.Players)
            .FirstOrDefault(p => p.PlayerId == message.Data.PlayerId);

        var notification = new NotificationsQueueItem()
        {
            Text = $"{player.FirstName} {player.LastName} \n{message.Data.Action}",
            BackgroundColor = player.ColorHex
        };

        notificationsQueue.Enqueue(notification);
    }
}
