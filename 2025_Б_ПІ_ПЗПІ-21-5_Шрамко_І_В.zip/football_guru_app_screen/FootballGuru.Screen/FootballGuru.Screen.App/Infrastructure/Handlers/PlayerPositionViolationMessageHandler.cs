﻿using FootballGuru.Screen.App.Enums;
using FootballGuru.Screen.App.Infrastructure.Messages;
using FootballGuru.Screen.App.Queues;
using FootballGuru.Screen.App.States;
using System.Diagnostics;
using System.Text.Json;

namespace FootballGuru.Screen.App.Infrastructure.Handlers;

public class PlayerPositionViolationMessageHandler(
    NotificationsQueue notificationsQueue,
    TrainingState trainingState) : IMessageHandler
{
    public async Task Handle(string messageJson)
    {
        var message = JsonSerializer.Deserialize<Message<PositionViolationMessage>>(messageJson);
        Debug.WriteLine($"position message received | player {message.Data.PlayerId} | dir: {message.Data.Direction}");

        var player = trainingState.TrainingDetails.TeamA.Players.Concat(trainingState.TrainingDetails.TeamB.Players)
            .FirstOrDefault(p => p.PlayerId == message.Data.PlayerId);

        var notification = new NotificationsQueueItem()
        {
            Text = $"{player.FirstName} {player.LastName} \nзмістись\n{GetDirectionText((PositionRuleViolationDirection)message.Data.Direction)}",
            BackgroundColor = player.ColorHex
        };

        notificationsQueue.Enqueue(notification);
    }

    private string GetDirectionText(PositionRuleViolationDirection direction)
        => direction switch
        {
            PositionRuleViolationDirection.Top => "Ничже",
            PositionRuleViolationDirection.Bottom => "Вище",
            PositionRuleViolationDirection.Left => "Вправо",
            PositionRuleViolationDirection.Right => "Вліво"
        };
}
