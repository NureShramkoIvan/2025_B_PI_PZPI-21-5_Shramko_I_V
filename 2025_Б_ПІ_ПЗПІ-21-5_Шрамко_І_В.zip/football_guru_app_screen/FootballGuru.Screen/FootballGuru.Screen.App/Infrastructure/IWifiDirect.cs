﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Screen.App.Infrastructure;

public interface IWifiDirect
{
    Task StartAsync();                       // initialize & register receiver
    Task<IPEndPoint> CreateGroupAsync();    // trainer side – returns GO IP
    Task<IPEndPoint> ConnectAsync(string ssidHint = null); // camera side
    Task SendAsync(byte[] payload, int port = 8888);
    Task<byte[]> ReceiveAsync(int port = 8888, int expectedBytes = 0);
    void Stop();
    bool IsConnected();
    Task<IPEndPoint?> GetServerIP();
}