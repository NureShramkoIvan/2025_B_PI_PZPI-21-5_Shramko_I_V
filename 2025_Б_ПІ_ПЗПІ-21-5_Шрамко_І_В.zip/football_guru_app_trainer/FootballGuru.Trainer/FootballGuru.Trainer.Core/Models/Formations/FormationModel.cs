namespace FootballGuru.Trainer.Core.Models.Formations;

public class FormationModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public List<FormationLineModel> Lines { get; set; }
}


public class FormationLineModel
{
    public int Order { get; set; }
    public List<FormationPositionModel> Positions { get; set; }
}

public class FormationPositionModel
{
    public int Order { get; set; }
} 