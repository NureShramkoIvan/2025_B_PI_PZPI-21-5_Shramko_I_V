namespace FootballGuru.Trainer.Core.Models.Formations;

public class GetManyFormationsModel
{
    // Empty as it doesn't require any parameters
} 