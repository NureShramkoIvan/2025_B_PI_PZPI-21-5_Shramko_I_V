using FootballGuru.Trainer.Core.Models.Common;

namespace FootballGuru.Trainer.Core.Models.Players;

public class GetManyPlayersModel : GetManyModel
{
}

