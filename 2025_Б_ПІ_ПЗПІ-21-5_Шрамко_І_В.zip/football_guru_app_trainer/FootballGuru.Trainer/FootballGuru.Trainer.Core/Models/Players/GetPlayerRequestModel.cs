namespace FootballGuru.Trainer.Core.Models.Players;

public class GetPlayerRequestModel
{
    public int PlayerId { get; set; }
} 