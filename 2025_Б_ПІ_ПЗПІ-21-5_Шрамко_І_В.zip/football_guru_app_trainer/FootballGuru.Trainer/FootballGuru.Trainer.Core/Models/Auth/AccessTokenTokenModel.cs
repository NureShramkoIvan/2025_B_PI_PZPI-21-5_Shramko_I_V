namespace FootballGuru.Trainer.Core.Models.Auth;

public class AccessTokenTokenModel
{
    public string AccessToken { get; set; }
    public DateTime ExpiresAt { get; set; }
}



