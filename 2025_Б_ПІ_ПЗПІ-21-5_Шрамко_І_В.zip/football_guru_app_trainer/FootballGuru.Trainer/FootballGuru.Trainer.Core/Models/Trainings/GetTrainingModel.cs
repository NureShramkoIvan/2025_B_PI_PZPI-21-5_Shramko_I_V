namespace FootballGuru.Trainer.Core.Models.Trainings;

public class GetTrainingModel
{
    public Guid Id { get; set; }
} 