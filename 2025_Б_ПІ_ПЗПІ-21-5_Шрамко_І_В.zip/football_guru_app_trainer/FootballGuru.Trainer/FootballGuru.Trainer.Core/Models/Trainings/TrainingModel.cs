namespace FootballGuru.Trainer.Core.Models.Trainings;

public class TrainingModel
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public bool IsSaved { get; set; }
} 