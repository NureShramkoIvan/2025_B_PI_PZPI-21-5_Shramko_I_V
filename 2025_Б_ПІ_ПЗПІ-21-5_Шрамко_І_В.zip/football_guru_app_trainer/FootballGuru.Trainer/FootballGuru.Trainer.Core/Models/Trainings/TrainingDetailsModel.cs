namespace FootballGuru.Trainer.Core.Models.Trainings;

public class TrainingDetailsModel
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public TeamConfigurationModel TeamA { get; set; }
    public TeamConfigurationModel TeamB { get; set; }

    public class TeamConfigurationModel
    {
        public int FormationId { get; set; }
        public List<PlayerConfigurationModel> Players { get; set; }
    }

    public class PlayerConfigurationModel
    {
        public int PlayerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> Actions { get; set; }
        public ZoneConfigurationModel Zone { get; set; }
        public int ColorId { get; set; }
        public string ColorHex { get; set; }
    }

    public class ZoneConfigurationModel
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    }
} 