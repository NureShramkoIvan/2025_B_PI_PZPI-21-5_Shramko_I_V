using FootballGuru.Trainer.Core.Models.Common;

namespace FootballGuru.Trainer.Core.Models.Trainings;

public class GetManyTrainingsModel : GetManyModel
{
} 