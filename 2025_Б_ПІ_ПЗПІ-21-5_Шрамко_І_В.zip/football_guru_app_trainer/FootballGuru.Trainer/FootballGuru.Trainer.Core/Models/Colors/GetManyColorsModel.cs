using FootballGuru.Trainer.Core.Models.Common;

namespace FootballGuru.Trainer.Core.Models.Colors;

public class GetManyColorsModel : GetManyModel
{
    // Empty as it doesn't require any parameters
} 