namespace FootballGuru.Trainer.Core.Models.Colors;

public class ColorModel
{
    public int Id { get; set; }
    public string Hex { get; set; }
} 