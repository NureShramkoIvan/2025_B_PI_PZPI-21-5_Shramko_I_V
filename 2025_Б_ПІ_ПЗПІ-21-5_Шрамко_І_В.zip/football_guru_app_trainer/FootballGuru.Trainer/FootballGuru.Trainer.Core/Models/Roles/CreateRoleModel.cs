namespace FootballGuru.Trainer.Core.Models.Roles;

public class CreateRoleModel
{
    public string Name { get; set; }
}
