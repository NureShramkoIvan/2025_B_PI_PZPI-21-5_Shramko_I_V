namespace FootballGuru.Trainer.Core.Models.Roles;

public class DeleteRoleActionModel
{
    public int Id { get; set; }
    public int RoleId { get; set; }
} 