namespace FootballGuru.Trainer.Core.Models.Roles;

public class RoleActionModel
{
    public int Id { get; set; }
    public string Action { get; set; }
}