namespace FootballGuru.Trainer.Core.Models.Roles;

public class CreateRoleActionModel
{
    public string Action { get; set; }
    public int RoleId { get; set; }
} 