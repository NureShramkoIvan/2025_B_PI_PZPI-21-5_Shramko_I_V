namespace FootballGuru.Trainer.Core.Models.Roles;

public class GetRoleModel
{
    public int Id { get; set; }
    public string Name { get; set; }
}
