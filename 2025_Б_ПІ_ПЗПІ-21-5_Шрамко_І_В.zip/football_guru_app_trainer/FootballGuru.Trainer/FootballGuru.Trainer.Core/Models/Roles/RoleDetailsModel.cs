using FootballGuru.Trainer.Core.Models.Roles;

public class RoleDetailsModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public List<RoleActionModel> Actions { get; set; }
}

