using FluentValidation.Results;
using FootballGuru.Trainer.Core.Enums.Common;

namespace FootballGuru.Trainer.Core.Models.Common;

public class ResponseModel
{
    public ValidationResult ValidationResult { get; set; }
    public Status Status { get; set; }
    public string Message { get; set; }
}


public class ResponseModel<TData> : ResponseModel
{
    public TData Data { get; set; }
}