namespace FootballGuru.Trainer.Core.Models.Common;

public class GetManyModel
{
    public int? Skip { get; set; }
    public int? Limit { get; set; }
}
