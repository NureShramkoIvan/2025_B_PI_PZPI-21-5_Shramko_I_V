namespace FootballGuru.Trainer.Core.Models.Common;

public class PageModel<T>
{
    public bool HasNext { get; set; }
    public IEnumerable<T> Data { get; set; }
}

