namespace FootballGuru.Trainer.Core.Enums.Common;

public enum Status
{
    Success = 200,
    NotFound = 404,
    ValidationFailure = 400,
}
