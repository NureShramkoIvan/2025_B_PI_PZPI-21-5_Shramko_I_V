using FootballGuru.Trainer.Core.Models.Colors;

namespace FootballGuru.Trainer.Data.States;

public class ColorsState
{
    private IEnumerable<ColorModel> _colors;
    private bool _isInitialized;

    public IEnumerable<ColorModel> Colors 
    { 
        get => _colors ?? Enumerable.Empty<ColorModel>();
        set
        {
            _colors = value;
            _isInitialized = true;
        }
    }

    public bool IsInitialized => _isInitialized;
} 