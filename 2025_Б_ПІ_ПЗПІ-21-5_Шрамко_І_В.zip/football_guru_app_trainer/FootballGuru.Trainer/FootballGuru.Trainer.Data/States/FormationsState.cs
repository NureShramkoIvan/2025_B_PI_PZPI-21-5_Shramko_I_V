using FootballGuru.Trainer.Core.Models.Formations;

namespace FootballGuru.Trainer.Data.States;

public class FormationsState
{
    private IEnumerable<FormationModel> _formations;
    private bool _isInitialized;

    public IEnumerable<FormationModel> Formations 
    { 
        get => _formations ?? Enumerable.Empty<FormationModel>();
        set
        {
            _formations = value;
            _isInitialized = true;
        }
    }

    public bool IsInitialized => _isInitialized;
} 