namespace FootballGuru.Trainer.Data.States;

public class AuthState
{
    public string Token { get; set; }


    public int UserId { get; set; }  

    public bool IsAuthenticated { get; set; } 

    public event Action OnAuthenticated;

    public void SetToken(string token)
    {
        Token = token;
        IsAuthenticated = true;
        OnAuthenticated?.Invoke();
    }
}

