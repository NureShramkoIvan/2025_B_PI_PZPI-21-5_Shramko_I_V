using System.Security.Principal;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Players;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.Data.Providers;

public class PlayersProvider(IHttpClientFactory httpClientFactory, AuthState authState) : ProviderBase(httpClientFactory), IPlayersProvider
{
    public async Task<ResponseModel> CreatePlayerAsync(CreatePlayerModel createPlayerModel)
    {
        var response = await SendRequestAsync(
            HttpMethod.Post,
            "players",
            createPlayerModel,
            token: authState.Token);
        return response;
    }


    public async Task<ResponseModel<PageModel<PlayerModel>>> GetPlayersAsync(GetManyPlayersModel getManyPlayersModel)
    {
        var queryString = string.Empty;
        queryString += $"?skip={getManyPlayersModel.Skip}";
        queryString += $"&limit={getManyPlayersModel.Limit}";

        var response = await SendRequestAsync<PageModel<PlayerModel>, GetManyPlayersModel>(
            HttpMethod.Get,
            "players" + queryString,
            token: authState.Token);
        return response;
    }

    public async Task<ResponseModel<PlayerModel>> GetPlayerAsync(GetPlayerRequestModel request)
    {
        var response = await SendRequestAsync<PlayerModel, GetPlayerRequestModel>(
            HttpMethod.Get,
            $"players/{request.PlayerId}",
            token: authState.Token);
        return response;
    }
}
