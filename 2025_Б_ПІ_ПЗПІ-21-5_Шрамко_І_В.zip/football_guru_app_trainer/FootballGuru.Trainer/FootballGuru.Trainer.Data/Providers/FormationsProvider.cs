using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Formations;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.Data.Providers;

public class FormationsProvider(IHttpClientFactory httpClientFactory, AuthState authState) 
    : ProviderBase(httpClientFactory), IFormationsProvider
{
    public async Task<ResponseModel<IEnumerable<FormationModel>>> GetFormationsAsync(GetManyFormationsModel model)
    {
        var response = await SendRequestAsync<IEnumerable<FormationModel>>(
            HttpMethod.Get, 
            "formations", 
            token: authState.Token);
        return response;
    }
} 