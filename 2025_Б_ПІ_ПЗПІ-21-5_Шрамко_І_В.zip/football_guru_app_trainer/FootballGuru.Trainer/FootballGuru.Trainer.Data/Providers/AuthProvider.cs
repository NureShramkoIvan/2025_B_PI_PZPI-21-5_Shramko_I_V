
using FootballGuru.Trainer.Core.Models.Auth;
using FootballGuru.Trainer.Core.Models.Common;

public class AuthProvider(IHttpClientFactory httpClientFactory) : ProviderBase(httpClientFactory), IAuthProvider
{
    public async Task<ResponseModel<AccessTokenTokenModel>> LoginAsync(LoginModel loginModel)
    {
        var response = await SendRequestAsync<AccessTokenTokenModel, LoginModel>(HttpMethod.Post, "auth/token", loginModel);
        return response;
    }

    public async Task<ResponseModel> RegisterAsync(RegisterModel registerModel)
    {
        var response = await SendRequestAsync(HttpMethod.Post, "auth/register", registerModel);
        return response;
    }
}
