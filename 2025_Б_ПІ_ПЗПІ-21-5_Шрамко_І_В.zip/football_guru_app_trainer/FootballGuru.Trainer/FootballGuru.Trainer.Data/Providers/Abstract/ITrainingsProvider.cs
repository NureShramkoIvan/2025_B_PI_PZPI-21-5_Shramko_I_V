using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Trainings;

namespace FootballGuru.Trainer.Data.Providers.Abstract;

public interface ITrainingsProvider
{
    Task<ResponseModel> CreateTrainingAsync(CreateTrainingModel model);
    Task<ResponseModel<TrainingDetailsModel>> GetTrainingAsync(GetTrainingModel model);
    Task<ResponseModel<PageModel<TrainingModel>>> GetTrainingsAsync(GetManyTrainingsModel model);
} 