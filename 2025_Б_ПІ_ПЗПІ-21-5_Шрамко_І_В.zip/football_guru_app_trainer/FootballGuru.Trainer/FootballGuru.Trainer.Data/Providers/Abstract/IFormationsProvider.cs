using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Formations;

namespace FootballGuru.Trainer.Data.Providers.Abstract;

public interface IFormationsProvider
{
    Task<ResponseModel<IEnumerable<FormationModel>>> GetFormationsAsync(GetManyFormationsModel model);
} 