using FootballGuru.Trainer.Core.Models.Auth;
using FootballGuru.Trainer.Core.Models.Common;

public interface IAuthProvider
{
    Task<ResponseModel<AccessTokenTokenModel>> LoginAsync(LoginModel loginModel);
    Task<ResponseModel> RegisterAsync(RegisterModel registerModel);
}


