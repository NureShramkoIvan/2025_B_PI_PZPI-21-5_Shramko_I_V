using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Players;

namespace FootballGuru.Trainer.Data.Providers.Abstract;


public interface IPlayersProvider
{
    Task<ResponseModel> CreatePlayerAsync(CreatePlayerModel createPlayerModel);
    Task<ResponseModel<PageModel<PlayerModel>>> GetPlayersAsync(GetManyPlayersModel getManyPlayersModel);
    Task<ResponseModel<PlayerModel>> GetPlayerAsync(GetPlayerRequestModel request);
}

