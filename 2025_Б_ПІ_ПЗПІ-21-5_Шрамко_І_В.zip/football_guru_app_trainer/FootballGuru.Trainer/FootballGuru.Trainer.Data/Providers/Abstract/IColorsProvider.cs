using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Colors;
using FootballGuru.Trainer.Core.Models.Common;

namespace FootballGuru.Trainer.Data.Providers.Abstract;

public interface IColorsProvider
{
    Task<ResponseModel<PageModel<ColorModel>>> GetColorsAsync(GetManyColorsModel model);
} 