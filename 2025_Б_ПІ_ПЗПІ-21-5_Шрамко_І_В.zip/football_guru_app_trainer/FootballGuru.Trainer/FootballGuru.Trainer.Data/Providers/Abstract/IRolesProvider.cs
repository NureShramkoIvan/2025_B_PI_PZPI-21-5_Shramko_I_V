using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Roles;

namespace FootballGuru.Trainer.Data.Providers.Abstract;

public interface IRolesProvider
{
    Task<ResponseModel> CreateRoleAsync(CreateRoleModel model);
    Task<ResponseModel<RoleDetailsModel>> GetRoleAsync(GetRoleModel model);
    Task<ResponseModel<PageModel<RoleModel>>> GetRolesAsync(GetManyRolesModel model);
    Task<ResponseModel> CreateRoleActionAsync(CreateRoleActionModel model);
    Task<ResponseModel> DeleteRoleActionAsync(DeleteRoleActionModel model);

} 