using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Trainings;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.Data.Providers;

public class TrainingsProvider(IHttpClientFactory httpClientFactory, AuthState authState) 
    : ProviderBase(httpClientFactory), ITrainingsProvider
{
    public async Task<ResponseModel> CreateTrainingAsync(CreateTrainingModel model)
    {
        var response = await SendRequestAsync(
            HttpMethod.Post,
            "trainings",
            model,
            token: authState.Token);
        return response;
    }

    public async Task<ResponseModel<TrainingDetailsModel>> GetTrainingAsync(GetTrainingModel model)
    {
        var response = await SendRequestAsync<TrainingDetailsModel>(
            HttpMethod.Get,
            $"trainings/{model.Id}",
            token: authState.Token);
        return response;
    }

    public async Task<ResponseModel<PageModel<TrainingModel>>> GetTrainingsAsync(GetManyTrainingsModel model)
    {
        var queryString = string.Empty;
        queryString += $"?skip={model.Skip}";
        queryString += $"&limit={model.Limit}";

        var response = await SendRequestAsync<PageModel<TrainingModel>>(
            HttpMethod.Get,
            "trainings" + queryString,
            token: authState.Token);
        return response;
    }
} 