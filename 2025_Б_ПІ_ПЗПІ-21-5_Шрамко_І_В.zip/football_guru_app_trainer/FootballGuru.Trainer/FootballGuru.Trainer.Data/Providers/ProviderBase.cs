using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using FootballGuru.Trainer.Core.Models.Common;

public class ProviderBase(IHttpClientFactory httpClientFactory)
{
    protected readonly HttpClient _httpClient = httpClientFactory.CreateClient("FootballGuruTrainerApi");

    protected async Task<ResponseModel<TData>> SendRequestAsync<TData, TRequest>(
        HttpMethod method,
        string url,
        TRequest content = null,
        string token = null) where TRequest : class
    {
        var requestMessage = new HttpRequestMessage(method, url)
        {
            Content = content != null ? new StringContent(JsonSerializer.Serialize(content), Encoding.UTF8, "application/json") : null
        };

        if (token != null)
        {
            requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }

        var response = await _httpClient.SendAsync(requestMessage);

        return await response.Content.ReadFromJsonAsync<ResponseModel<TData>>();
    }

    protected async Task<ResponseModel> SendRequestAsync<TRequest>(
        HttpMethod method,
        string url,
        TRequest content,
        string token = null)

    {
        var requestMessage = new HttpRequestMessage(method, url)
        {
            Content = new StringContent(JsonSerializer.Serialize(content), Encoding.UTF8, "application/json")
        };

        if (token != null)
        {
            requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }


        var response = await _httpClient.SendAsync(requestMessage);

        return await response.Content.ReadFromJsonAsync<ResponseModel>();
    }

    protected async Task<ResponseModel> SendRequestAsync(
        HttpMethod method,
        string url,
        string token = null)
    {
        var requestMessage = new HttpRequestMessage(method, url)
        {
            Content = null
        };

        if (token != null)
        {
            requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }

        var response = await _httpClient.SendAsync(requestMessage);

        return await response.Content.ReadFromJsonAsync<ResponseModel>();
    }

    protected async Task<ResponseModel<TData>> SendRequestAsync<TData>(
        HttpMethod method,
        string url,
        string token = null)
    {
        var requestMessage = new HttpRequestMessage(method, url);


        if (token != null)
        {
            requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }


        var response = await _httpClient.SendAsync(requestMessage);


        return await response.Content.ReadFromJsonAsync<ResponseModel<TData>>();
    }
}
