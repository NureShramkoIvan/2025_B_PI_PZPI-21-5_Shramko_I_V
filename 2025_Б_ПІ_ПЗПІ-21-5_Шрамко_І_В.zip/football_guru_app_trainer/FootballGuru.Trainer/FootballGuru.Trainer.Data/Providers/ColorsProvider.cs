using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Colors;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.Data.Providers;

public class ColorsProvider(IHttpClientFactory httpClientFactory, AuthState authState) 
    : ProviderBase(httpClientFactory), IColorsProvider
{
    public async Task<ResponseModel<PageModel<ColorModel>>> GetColorsAsync(GetManyColorsModel model)
    {
        var queryString = string.Empty;
        queryString += $"?skip={model.Skip}";
        queryString += $"&limit={model.Limit}";

        var response = await SendRequestAsync<PageModel<ColorModel>>(
            HttpMethod.Get, 
            "colors" + queryString, 
            token: authState.Token);
        return response;
    }
} 