using FootballGuru.Trainer.Core.Models;
using FootballGuru.Trainer.Core.Models.Common;
using FootballGuru.Trainer.Core.Models.Roles;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;


namespace FootballGuru.Trainer.Data.Providers;

public class RolesProvider(IHttpClientFactory httpClientFactory, AuthState authState) : ProviderBase(httpClientFactory), IRolesProvider
{
    public async Task<ResponseModel> CreateRoleAsync(CreateRoleModel model)
    {
        var response = await SendRequestAsync(HttpMethod.Post, "roles", model, token: authState.Token);
        return response;
    }


    public async Task<ResponseModel<RoleDetailsModel>> GetRoleAsync(GetRoleModel model)
    {
        var response = await SendRequestAsync<RoleDetailsModel, GetRoleModel>(HttpMethod.Get, $"roles/{model.Id}", token: authState.Token);
        return response;
    }


    public async Task<ResponseModel<PageModel<RoleModel>>> GetRolesAsync(GetManyRolesModel model)
    {
        var queryString = string.Empty;
        queryString += $"?skip={model.Skip}";
        queryString += $"&limit={model.Limit}";
        var response = await SendRequestAsync<PageModel<RoleModel>, GetManyRolesModel>(HttpMethod.Get, "roles" + queryString, token: authState.Token);
        return response;
    }

    public async Task<ResponseModel> CreateRoleActionAsync(CreateRoleActionModel model)
    {
        var response = await SendRequestAsync(HttpMethod.Post, $"roles/{model.RoleId}/actions", model, token: authState.Token);
        return response;
    }

    public async Task<ResponseModel> DeleteRoleActionAsync(DeleteRoleActionModel model)
    {
        var response = await SendRequestAsync(HttpMethod.Delete, $"roles/{model.RoleId}/actions/{model.Id}", token: authState.Token);
        return response;
    }
} 