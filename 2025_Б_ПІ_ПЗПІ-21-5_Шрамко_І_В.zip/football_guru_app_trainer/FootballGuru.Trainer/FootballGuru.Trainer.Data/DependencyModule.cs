using FootballGuru.Trainer.Data.Providers;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.Services;
using FootballGuru.Trainer.Data.States;
using Microsoft.Extensions.DependencyInjection;

public static class DependencyModule
{
    public static IServiceCollection AddDataServices(this IServiceCollection services, string baseUrl)
    {
        services.AddHttpClient("FootballGuruTrainerApi", client =>
        {
            client.BaseAddress = new Uri(baseUrl);
        });

        services.AddScoped<IAuthProvider, AuthProvider>();
        services.AddScoped<IPlayersProvider, PlayersProvider>();
        services.AddSingleton<IRolesProvider, RolesProvider>();
        services.AddSingleton<IFormationsProvider, FormationsProvider>();


        services.AddSingleton<AuthState>();
        services.AddSingleton<FormationsState>();
        services.AddSingleton<FormationsInitializer>();

        services.AddSingleton<ColorsState>();
        services.AddSingleton<IColorsProvider, ColorsProvider>();
        services.AddSingleton<ColorsInitializer>();

        services.AddSingleton<ITrainingsProvider, TrainingsProvider>();

        return services;
    }
}

