using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Colors;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.Data.Services;

public class ColorsInitializer
{
    private readonly IColorsProvider _colorsProvider;
    private readonly ColorsState _colorsState;

    public ColorsInitializer(IColorsProvider colorsProvider, ColorsState colorsState)
    {
        _colorsProvider = colorsProvider;
        _colorsState = colorsState;
    }

    public async Task InitializeAsync()
    {
        if (_colorsState.IsInitialized)
            return;

        var response = await _colorsProvider.GetColorsAsync(new GetManyColorsModel 
        { 
            Skip = 0,
            Limit = 100 // Assuming we won't have more than 100 colors
        });

        if (response.Status == Status.Success && response.Data?.Data != null)
        {
            _colorsState.Colors = response.Data.Data;
        }
    }
} 