using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Formations;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.Data.Services;

public class FormationsInitializer
{
    private readonly IFormationsProvider _formationsProvider;
    private readonly FormationsState _formationsState;

    public FormationsInitializer(IFormationsProvider formationsProvider, FormationsState formationsState)
    {
        _formationsProvider = formationsProvider;
        _formationsState = formationsState;
    }

    public async Task InitializeAsync()
    {
        if (_formationsState.IsInitialized)
            return;

        var response = await _formationsProvider.GetFormationsAsync(new GetManyFormationsModel());

        if (response.Status == Status.Success && response.Data != null)
        {
            _formationsState.Formations = response.Data;
        }
    }
} 