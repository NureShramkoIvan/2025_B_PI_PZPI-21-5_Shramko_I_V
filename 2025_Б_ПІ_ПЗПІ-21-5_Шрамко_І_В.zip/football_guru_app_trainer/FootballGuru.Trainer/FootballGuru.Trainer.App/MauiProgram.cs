﻿using FootballGuru.Trainer.App.Pages;
using FootballGuru.Trainer.App.Pages.Auth;
using FootballGuru.Trainer.App.Pages.Players;
using Microsoft.Extensions.Logging;
using FootballGuru.Trainer.App.Pages.Roles;
using FootballGuru.Trainer.Data.Services;
using FootballGuru.Trainer.Data.States;
using FootballGuru.Trainer.App.Pages.Training;
using FootballGuru.Trainer.App.Infrastructure;
using FootballGuru.Trainer.App.Infrastructure.Handlers;

namespace FootballGuru.Trainer.App;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();

        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

        builder.Services.AddSingleton<LoginPage>();
        builder.Services.AddSingleton<RegisterPage>();
        builder.Services.AddSingleton<HomePage>();

        builder.Services.AddSingleton<PlayersPage>();
        builder.Services.AddSingleton<PlayerDetailsPage>();
        builder.Services.AddSingleton<CreatePlayerPage>();

        builder.Services.AddSingleton<RolesPage>();
        builder.Services.AddSingleton<RoleDetailsPage>();
        builder.Services.AddSingleton<CreateRolePage>();

        builder.Services.AddSingleton<SelectFormationPage>();
        builder.Services.AddSingleton<SelectPlayersPage>();
        builder.Services.AddSingleton<SelectZonesPage>();

        builder.Services.AddSingleton<CreateTrainingPage>();
        builder.Services.AddSingleton<TrainingPage>();

        builder.Services.AddTransient<LookupRoleModal>();
        builder.Services.AddTransient<LookupPlayerModal>();

        builder.Services.AddSingleton<CreateTrainingStateMachine>();

        //builder.Services.AddDataServices("http://10.0.2.2:5120");
        builder.Services.AddDataServices("http://635d-194-44-26-55.ngrok-free.app");

        //builder.Services.AddSingleton(sp => new MessagingHub([AllowedPeers.CAMERA], sp));
        builder.Services.AddSingleton(sp => new MessagingHub([AllowedPeers.SCREEN, AllowedPeers.CAMERA], sp));

        builder.Services.AddSingleton<PlayerPositionViolationMessageHandler>();
        builder.Services.AddKeyedSingleton<MessagesHandler>(AllowedPeers.CAMERA, (sp, _) =>
        {
            var messagesHandler = new MessagesHandler(sp);
            messagesHandler.RegisterHandler(
                MessageTypes.POSITION_VIOLATION,
                typeof(PlayerPositionViolationMessageHandler));

            return messagesHandler;
        });

        //builder.Services.AddSingleton<IWifiDirect, WifiDirect>();

        builder.Services.AddSingleton<IFileService, FileService>();

#if ANDROID
                builder.Services.AddPlatformServices();
#endif

        builder.Logging.AddDebug();

        var app = builder.Build();

        var authState = app.Services.GetRequiredService<AuthState>();
        authState.OnAuthenticated += () =>
        {
            try
            {
                var formationsInitializer = app.Services.GetRequiredService<FormationsInitializer>();
                formationsInitializer.InitializeAsync();

                var colorsInitializer = app.Services.GetRequiredService<ColorsInitializer>();
                colorsInitializer.InitializeAsync();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        };

        var stateMachine = app.Services.GetRequiredService<CreateTrainingStateMachine>();
        var selectFormationPage = app.Services.GetRequiredService<SelectFormationPage>();
        var selectPlayersPage = app.Services.GetRequiredService<SelectPlayersPage>();
        var selectZonesPage = app.Services.GetRequiredService<SelectZonesPage>();
        var createTrainingPage = app.Services.GetRequiredService<CreateTrainingPage>();

        selectFormationPage.FormationSelected += async (formation) =>
        {
            await stateMachine.HandleFormationSelected(formation);
        };

        selectPlayersPage.PlayersConfigured += (playerConfigurations) =>
        {
            stateMachine.HandlePlayersConfigured(playerConfigurations);
        };

        selectZonesPage.ZonesConfigured += (zoneConfigurations) =>
        {
            stateMachine.HandleZonesConfigured(zoneConfigurations);
        };

        createTrainingPage.TrainingCreated += async (name, dateTime) =>
        {
            await stateMachine.HandleTrainingCreated(name, dateTime);
        };

        return app;
    }

}
