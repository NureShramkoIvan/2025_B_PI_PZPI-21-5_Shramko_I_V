using FootballGuru.Trainer.Core.Models.Roles;
using FootballGuru.Trainer.Data.Providers.Abstract;

namespace FootballGuru.Trainer.App.Pages.Roles;

public partial class RolesPage : ContentPage
{
    private readonly IRolesProvider _rolesProvider;
    private CollectionView _rolesCollection;
    private List<RoleModel> _items = new List<RoleModel>();
    
    public RolesPage(IRolesProvider rolesProvider)
    {
        InitializeComponent();
        _rolesProvider = rolesProvider;
        BindingContext = this;
        
        _rolesCollection = new CollectionView
        {
            Margin = new Thickness(0),
            SelectionMode = SelectionMode.None,
            ItemsSource = _items,
            ItemTemplate = new DataTemplate(() =>
            {
                var frame = new Frame
                {
                    Margin = new Thickness(16, 8),
                    Padding = new Thickness(16),
                    BorderColor = Colors.LightGray
                };

                var nameLabel = new Label 
                { 
                    FontSize = 18
                };
                nameLabel.SetBinding(Label.TextProperty, new Binding("Name"));

                frame.Content = nameLabel;

                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += async (s, e) => 
                {
                    if (frame.BindingContext is RoleModel role)
                    {
                        await Shell.Current.GoToAsync($"{nameof(RoleDetailsPage)}?roleId={role.Id}");
                    }
                };
                frame.GestureRecognizers.Add(tapGesture);

                return frame;
            })
        };
        
        var mainGrid = (Grid)Content;
        mainGrid.Children.Add(_rolesCollection);
        Grid.SetRow(_rolesCollection, 1);
    }

    public bool IsLoading { get; set; }
    private int CurrentPage { get; set; }
    private const int PageSize = 10;
    private bool HasNextPage { get; set; }

    protected override async void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
        CurrentPage = 0;
        await LoadMoreRoles();
    }

    private async Task LoadMoreRoles()
    {
        if (IsLoading) return;

        IsLoading = true;
        try
        {
            var getManyModel = new GetManyRolesModel
            {
                Skip = CurrentPage * PageSize,
                Limit = PageSize,
            };

            var response = await _rolesProvider.GetRolesAsync(getManyModel);
            
            if (response.Data != null)
            {
                if (CurrentPage == 0)
                {
                    _items.Clear();
                }

                foreach (var role in response.Data.Data)
                {
                    _items.Add(role);
                }

                _rolesCollection.ItemsSource = null;
                _rolesCollection.ItemsSource = _items;

                HasNextPage = response.Data.HasNext;
                CurrentPage++;
            }
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async void NavigateToCreateRole(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(CreateRolePage));
    }
}
