using System.Windows.Input;
using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Roles;
using FootballGuru.Trainer.Data.Providers.Abstract;

namespace FootballGuru.Trainer.App.Pages.Roles;

public partial class CreateRolePage : ContentPage
{
    private readonly IRolesProvider _rolesProvider;

    public CreateRolePage(IRolesProvider rolesProvider)
    {
        InitializeComponent();
        _rolesProvider = rolesProvider;
        BindingContext = this;
    }

    public string Name { get; set; }

    private async void OnCreateRole(object sender, EventArgs e)
    {
        var model = new CreateRoleModel
        {

            Name = Name
        };

        var response = await _rolesProvider.CreateRoleAsync(model);

        if (response.Status == Status.Success)
        {
            await Shell.Current.GoToAsync("..");
        }
    }
}
