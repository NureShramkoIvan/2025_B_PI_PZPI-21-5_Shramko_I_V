using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Roles;
using FootballGuru.Trainer.Data.Providers.Abstract;

namespace FootballGuru.Trainer.App.Pages.Roles;

[QueryProperty(nameof(RoleId), "roleId")]
public partial class RoleDetailsPage : ContentPage
{
    private readonly IRolesProvider _rolesProvider;

    public RoleDetailsPage(IRolesProvider rolesProvider)
    {
        InitializeComponent();
        _rolesProvider = rolesProvider;
        BindingContext = this;
    }

    public int RoleId { get; set; }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadRole();
    }

    public RoleDetailsModel Role { get; set; }

    private async Task LoadRole()
    {
        var model = new GetRoleModel { Id = RoleId };
        var response = await _rolesProvider.GetRoleAsync(model);

        if (response.Status == Status.Success)
        {
            Role = response.Data;
            NameLabel.Text = Role.Name;
            ActionsCollection.ItemsSource = Role.Actions;
        }
    }

    private async void OnAddAction(object sender, EventArgs e)
    {
        string action = await DisplayPromptAsync("New Action", "Enter action name:", "Add", "Cancel");
        
        if (!string.IsNullOrWhiteSpace(action))
        {
            var model = new CreateRoleActionModel
            {
                Action = action,
                RoleId = RoleId
            };

            var response = await _rolesProvider.CreateRoleActionAsync(model);
            
            if (response.Status == Status.Success)
            {
                await LoadRole(); // Refresh the list
            }
            else
            {
                await DisplayAlert("Error", response.Message ?? "Failed to add action", "OK");
            }
        }
    }

    private async void OnDeleteAction(object sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is int actionId)
        {
            bool confirm = await DisplayAlert("Confirm Delete", 
                "Are you sure you want to delete this action?", 
                "Yes", "No");

            if (confirm)
            {
                var model = new DeleteRoleActionModel
                {
                    Id = actionId,
                    RoleId = RoleId
                };

                var response = await _rolesProvider.DeleteRoleActionAsync(model);
                
                if (response.Status == Status.Success)
                {
                    await LoadRole(); // Refresh the list
                }
                else
                {
                    await DisplayAlert("Error", response.Message ?? "Failed to delete action", "OK");
                }
            }
        }
    }
}
