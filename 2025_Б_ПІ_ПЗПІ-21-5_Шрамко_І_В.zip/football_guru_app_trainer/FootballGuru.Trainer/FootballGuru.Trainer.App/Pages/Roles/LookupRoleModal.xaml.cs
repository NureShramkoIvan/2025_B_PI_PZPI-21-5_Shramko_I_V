using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Roles;
using FootballGuru.Trainer.Data.Providers.Abstract;

namespace FootballGuru.Trainer.App.Pages.Roles;

public partial class LookupRoleModal : ContentPage
{
    private readonly IRolesProvider _rolesProvider;
    private int _currentPage;
    private const int PageSize = 10;
    private CollectionView _rolesCollection;

    public LookupRoleModal(IRolesProvider rolesProvider)
    {
        InitializeComponent();
        _rolesProvider = rolesProvider;
        BindingContext = this;

        var mainGrid = new Grid
        {
            RowDefinitions = new RowDefinitionCollection
            {
                new RowDefinition { Height = GridLength.Star },
                new RowDefinition { Height = GridLength.Auto }
            },
            Padding = new Thickness(16)
        };

        _rolesCollection = new CollectionView
        {
            SelectionMode = SelectionMode.None,
            ItemTemplate = new DataTemplate(() =>
            {
                var frame = new Frame
                {
                    Margin = new Thickness(0, 4),
                    Padding = new Thickness(16)
                };

                var nameLabel = new Label
                {
                    FontSize = 16
                };
                nameLabel.SetBinding(Label.TextProperty, new Binding("Name"));

                frame.Content = nameLabel;
                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += async (sender, args) =>
                {
                    if (sender is Frame roleFrame && roleFrame.BindingContext is RoleModel role)
                    {
                        await Shell.Current.GoToAsync("..", new Dictionary<string, object>
                        {
                            { "selectedRole", role }
                        });
                    }
                };

                frame.GestureRecognizers.Add(tapGesture);


                return frame;
            })
        };
        Grid.SetRow(_rolesCollection, 0);

        var navigationGrid = new Grid
        {
            ColumnDefinitions = new ColumnDefinitionCollection
            {
                new ColumnDefinition { Width = GridLength.Auto },
                new ColumnDefinition { Width = GridLength.Star },
                new ColumnDefinition { Width = GridLength.Auto }
            },
            Margin = new Thickness(0, 16, 0, 0)
        };

        var previousButton = new Button
        {
            Text = "Previous"
        };
        previousButton.Clicked += OnPreviousClicked;
        previousButton.SetBinding(Button.IsEnabledProperty, new Binding(nameof(HasPreviousPage)));
        Grid.SetColumn(previousButton, 0);

        var nextButton = new Button
        {
            Text = "Next"
        };
        nextButton.Clicked += OnNextClicked;
        nextButton.SetBinding(Button.IsEnabledProperty, new Binding(nameof(HasNextPage)));
        Grid.SetColumn(nextButton, 2);

        navigationGrid.Children.Add(previousButton);
        navigationGrid.Children.Add(nextButton);
        Grid.SetRow(navigationGrid, 1);

        mainGrid.Children.Add(_rolesCollection);
        mainGrid.Children.Add(navigationGrid);

        Content = mainGrid;
    }

    public bool HasNextPage { get; set; }
    public bool HasPreviousPage => _currentPage > 0;

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadRoles();
    }

    private async Task LoadRoles()
    {
        var model = new GetManyRolesModel
        {
            Skip = _currentPage * PageSize,
            Limit = PageSize
        };

        var response = await _rolesProvider.GetRolesAsync(model);

        if (response.Status == Status.Success)
        {
            _rolesCollection.ItemsSource = response.Data.Data;
            HasNextPage = response.Data.HasNext;
            OnPropertyChanged(nameof(HasNextPage));
            OnPropertyChanged(nameof(HasPreviousPage));
        }
    }

    private async void OnPreviousClicked(object sender, EventArgs e)
    {
        if (_currentPage > 0)
        {
            _currentPage--;
            await LoadRoles();
        }
    }

    private async void OnNextClicked(object sender, EventArgs e)
    {
        if (HasNextPage)
        {
            _currentPage++;
            await LoadRoles();
        }
    }
} 