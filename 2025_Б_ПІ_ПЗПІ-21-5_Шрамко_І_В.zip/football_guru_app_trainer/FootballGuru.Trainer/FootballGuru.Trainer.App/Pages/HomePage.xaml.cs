using System.Collections.ObjectModel;
using FootballGuru.Trainer.App.Pages.Auth;
using FootballGuru.Trainer.Core.Models.Trainings;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Data.States;
using FootballGuru.Trainer.App.Infrastructure;

namespace FootballGuru.Trainer.App.Pages;

public partial class HomePage : ContentPage
{
    private readonly CreateTrainingStateMachine _stateMachine;
    private readonly ITrainingsProvider _trainingsProvider;
    private readonly IFileService _fileService;
    private int _currentPage;
    private const int PageSize = 10;
    private ObservableCollection<TrainingModel> _trainings;

    public bool IsLoading { get; set; }
    public bool HasNextPage { get; set; }
    public bool HasPreviousPage => _currentPage > 0;

    public HomePage(CreateTrainingStateMachine stateMachine, ITrainingsProvider trainingsProvider, IFileService fileService)
    {
        InitializeComponent();
        _stateMachine = stateMachine;
        _trainingsProvider = trainingsProvider;
        _fileService = fileService;
        _trainings = new ObservableCollection<TrainingModel>();
        TrainingsCollection.ItemsSource = _trainings;
        BindingContext = this;

        var authState = new AuthState();
        if (!authState.IsAuthenticated)
        {
            Shell.Current.GoToAsync(nameof(LoginPage));
        }
    }

    protected override async void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
        await LoadTrainings();
    }

    private async Task LoadTrainings()
    {
        if (IsLoading) return;

        try
        {
            IsLoading = true;
            OnPropertyChanged(nameof(IsLoading));

            var response = await _trainingsProvider.GetTrainingsAsync(new GetManyTrainingsModel
            {
                Skip = _currentPage * PageSize,
                Limit = PageSize
            });

            if (response.Status == Core.Enums.Common.Status.Success && response.Data != null)
            {
                _trainings.Clear();
                foreach (var training in response.Data.Data)
                {
                    training.IsSaved = await _fileService.IsTrainingSavedAsync(training.Id);
                    _trainings.Add(training);
                }

                HasNextPage = response.Data.HasNext;
                OnPropertyChanged(nameof(HasNextPage));
                OnPropertyChanged(nameof(HasPreviousPage));
            }
        }
        finally
        {
            IsLoading = false;
            OnPropertyChanged(nameof(IsLoading));
        }
    }

    private async void OnCreateTrainingClicked(object sender, EventArgs e)
    {
        await _stateMachine.Start();
    }

    private async void OnPreviousClicked(object sender, EventArgs e)
    {
        if (_currentPage > 0)
        {
            _currentPage--;
            await LoadTrainings();
        }
    }

    private async void OnNextClicked(object sender, EventArgs e)
    {
        if (HasNextPage)
        {
            _currentPage++;
            await LoadTrainings();
        }
    }

    private async void OnStartTrainingClicked(object sender, EventArgs e)
    {
        if (sender is Button button && button.Parent is Grid grid && grid.Parent is Frame frame)
        {
            if (frame.BindingContext is TrainingModel training)
            {
                await Shell.Current.GoToAsync($"TrainingPage", new Dictionary<string, object> 
                { { "id", training.Id } });
            }
        }
    }
}