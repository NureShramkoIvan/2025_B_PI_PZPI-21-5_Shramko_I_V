using Microsoft.Maui.Controls;
using FootballGuru.Trainer.Core.Models.Auth;
using FootballGuru.Trainer.Core.Enums.Common;

namespace FootballGuru.Trainer.App.Pages.Auth;

public partial class RegisterPage : ContentPage

{
    private readonly IAuthProvider _authProvider;

    public RegisterPage(IAuthProvider authProvider)
    {
        InitializeComponent();
        _authProvider = authProvider;
    }

    private async void OnRegisterClicked(object sender, EventArgs e)
    {
        string username = UsernameEntry.Text;
        string firstName = FirstNameEntry.Text;
        string lastName = LastNameEntry.Text;
        string password = PasswordEntry.Text;
        string confirmPassword = ConfirmPasswordEntry.Text;

        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(firstName) || 
            string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(password))
        {
            await DisplayAlert("Error", "Please fill in all fields", "OK");
            return;
        }

        if (password != confirmPassword)
        {
            await DisplayAlert("Error", "Passwords do not match", "OK");
            return;
        }

        var registerModel = new RegisterModel
        {   
            Username = username,
            Password = password,
            FirstName = firstName,
            LastName = lastName
        };

        var response = await _authProvider.RegisterAsync(registerModel);

        if (response.Status == Status.Success)
        {
            await DisplayAlert("Success", "Registration successful", "OK");
            await Shell.Current.GoToAsync(nameof(LoginPage));
        }
        else
        {
            await DisplayAlert("Error", response.Message, "OK");
        }

    }

    private async void OnLoginTapped(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }
} 