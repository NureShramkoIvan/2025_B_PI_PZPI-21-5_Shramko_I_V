using FootballGuru.Trainer.Core.Models.Auth;
using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Data.States;
namespace FootballGuru.Trainer.App.Pages.Auth;

public partial class LoginPage : ContentPage
{
    private readonly AuthState _authState;
    private readonly IAuthProvider _authProvider;

    public LoginPage(IAuthProvider authProvider, AuthState authState)
    {
        InitializeComponent();
        _authState = authState;
        _authProvider = authProvider;
    }


    private async void OnLoginClicked(object sender, EventArgs e)
    {
        string userName = UserNameEntry.Text;
        string password = PasswordEntry.Text;

        if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
        {
            await DisplayAlert("Error", "Please enter both username and password", "OK");
            return;
        }

        var loginModel = new LoginModel
        {
            UserName = userName,
            Password = password
        };

        var response = await _authProvider.LoginAsync(loginModel);

        if (response.Status == Status.Success)
        {
            _authState.SetToken(response.Data.AccessToken);
            await Shell.Current.GoToAsync("//" + nameof(HomePage));
        }

        else
        {
            await DisplayAlert("Error", response.Message, "OK");
        }

    }

    private async void OnRegisterTapped(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(RegisterPage));
    }

} 