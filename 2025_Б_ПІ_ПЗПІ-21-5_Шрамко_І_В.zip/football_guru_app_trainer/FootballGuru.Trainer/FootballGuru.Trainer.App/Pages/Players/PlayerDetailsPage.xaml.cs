using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Players;
using FootballGuru.Trainer.Data.Providers.Abstract;

namespace FootballGuru.Trainer.App.Pages.Players;

[QueryProperty(nameof(PlayerId), "playerId")]
public partial class PlayerDetailsPage : ContentPage
{
    private readonly IPlayersProvider _playersProvider;

    public PlayerDetailsPage(IPlayersProvider playersProvider)
    {
        _playersProvider = playersProvider;
        InitializeComponent();
    }

    public int PlayerId { get; set; }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadPlayerData();
    }

    private async Task LoadPlayerData()
    {
        try
        {
            var request = new GetPlayerRequestModel
            {
                PlayerId = PlayerId,
            };

            var response = await _playersProvider.GetPlayerAsync(request);
            
            if (response.Status == Status.Success && response.Data != null)
            {
                var player = response.Data;
                FirstNameLabel.Text = player.FirstName;
                LastNameLabel.Text = player.LastName;
                DateOfBirthLabel.Text = player.DateOfBirth.ToShortDateString();
                RoleLabel.Text = player.RoleId.ToString();
                PlayerIdLabel.Text = player.Id.ToString();
            }
            else
            {
                await DisplayAlert("Error", "Failed to load player data", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", "An error occurred while loading player data", "OK");
        }
    }

    private async void OnEditClicked(object sender, EventArgs e)
    {
        // TODO: Implement edit functionality
        await DisplayAlert("Info", "Edit functionality coming soon", "OK");
    }
} 