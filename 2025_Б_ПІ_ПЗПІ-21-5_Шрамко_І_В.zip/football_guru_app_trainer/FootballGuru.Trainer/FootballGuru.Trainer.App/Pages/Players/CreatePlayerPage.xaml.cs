using FootballGuru.Trainer.Core.Models.Players;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.Core.Enums.Common;
using Microsoft.Maui.Controls;
using FootballGuru.Trainer.Core.Models.Roles;
using FootballGuru.Trainer.App.Pages.Roles;

namespace FootballGuru.Trainer.App.Pages.Players;

[QueryProperty(nameof(SelectedRole), "selectedRole")]
public partial class CreatePlayerPage : ContentPage
{
    private readonly IPlayersProvider _playersProvider;
    private readonly IRolesProvider _rolesProvider;

    private RoleModel? _selectedRole;

    public CreatePlayerPage(IPlayersProvider playersProvider, IRolesProvider rolesProvider)

    {
        InitializeComponent();
        _playersProvider = playersProvider;
        _rolesProvider = rolesProvider;
        BindingContext = this;
    }

    public RoleModel? SelectedRole
    {
        get => _selectedRole;
        set
        {

            _selectedRole = value;
            LoadRoleName();
        }
    }


    public string SelectedRoleName { get; set; } = "No role selected";

    private async void LoadRoleName()
    {
        if (SelectedRole != null)
        {
            SelectedRoleName = SelectedRole.Name;
            OnPropertyChanged(nameof(SelectedRoleName));
        }
    }


    private async void OnSelectRoleClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(LookupRoleModal));
    }

    private async void OnCreatePlayerClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(FirstNameEntry.Text) || 
            string.IsNullOrEmpty(LastNameEntry.Text))
        {
            await DisplayAlert("Error", "Please fill in all required fields", "OK");
            return;
        }

        var createPlayerModel = new CreatePlayerModel
        {
            FirstName = FirstNameEntry.Text,
            LastName = LastNameEntry.Text,
            DateOfBirth = BirthDatePicker.Date,
            RoleId = SelectedRole.Id
        };

        var response = await _playersProvider.CreatePlayerAsync(createPlayerModel);

        if (response.Status == Status.Success)
        {
            await Shell.Current.GoToAsync("..");
        }
        else
        {
            await DisplayAlert("Error", response.Message, "OK");
        }
    }

    private async void OnCancelClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }
}
