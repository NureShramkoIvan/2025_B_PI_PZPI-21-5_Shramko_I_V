using System.Collections.ObjectModel;
using System.Windows.Input;

namespace FootballGuru.Trainer.App.Pages.Players;

[QueryProperty(nameof(Line), "line")]
[QueryProperty(nameof(Position), "position")]
public partial class CustomActionsModal : ContentPage
{
    public ObservableCollection<string> Actions { get; set; } = new ObservableCollection<string>();
    public int Line { get; set; }
    public int Position { get; set; }
    public ICommand AddActionCommand { get; }

    public CustomActionsModal()
    {
        InitializeComponent();
        BindingContext = this;
        
        AddActionCommand = new Command(() => OnAddActionClicked(null, null));
    }

    private void OnAddActionClicked(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(ActionEntry.Text))
        {
            Actions.Add(ActionEntry.Text);
            ActionEntry.Text = string.Empty;
        }
    }

    private void OnRemoveActionClicked(object sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is string action)
        {
            Actions.Remove(action);
        }
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..", new Dictionary<string, object> 
        { 
            { "actions", Actions.ToList() },
            { "line", Line },
            { "position", Position },
            { "from", "CustomActionsModal" }
        });
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        ActionEntry.Focus();
    }
} 