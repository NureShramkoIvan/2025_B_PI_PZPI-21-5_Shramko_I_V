using System.ComponentModel;
using FootballGuru.Trainer.Core.Models.Players;
using FootballGuru.Trainer.Data.Providers;
using FootballGuru.Trainer.Data.Providers.Abstract;
using Microsoft.Maui.Controls;

namespace FootballGuru.Trainer.App.Pages.Players;

public partial class PlayersPage : ContentPage
{
    private readonly IPlayersProvider _playersProvider;
    
    private CollectionView _playersCollection;
    private List<PlayerModel> _items = new List<PlayerModel>();
    
    public PlayersPage(IPlayersProvider playersProvider)
    {
        InitializeComponent();
        _playersProvider = playersProvider;
        BindingContext = this;
        
        // Initialize CollectionView with DataTemplate
        _playersCollection = new CollectionView
        {
            Margin = new Thickness(0),
            SelectionMode = SelectionMode.None,
            ItemsSource = _items,
            ItemTemplate = new DataTemplate(() =>
            {
                var frame = new Frame
                {
                    Margin = new Thickness(16, 8),
                    Padding = new Thickness(16),
                    BorderColor = Colors.LightGray
                };

                var grid = new Grid
                {
                    RowDefinitions = new RowDefinitionCollection
                    {
                        new RowDefinition { Height = GridLength.Auto },
                        new RowDefinition { Height = GridLength.Auto },
                        new RowDefinition { Height = GridLength.Auto }
                    }
                };

                var nameLabel = new Label { FontSize = 18 };
                nameLabel.SetBinding(Label.TextProperty, new Binding("FirstName", stringFormat: "{0} {1}", source: null) { 
                    Path = "FirstName",
                    StringFormat = "{0} {1}",
                });
                Grid.SetRow(nameLabel, 0);

                var dobLabel = new Label
                {
                    TextColor = Colors.Gray,
                    FontSize = 14
                };
                dobLabel.SetBinding(Label.TextProperty, new Binding("DateOfBirth", stringFormat: "Date of Birth: {0:d}"));
                Grid.SetRow(dobLabel, 1);

                var roleLabel = new Label
                {
                    TextColor = Colors.Gray,
                    FontSize = 14
                };
                roleLabel.SetBinding(Label.TextProperty, new Binding("RoleId", stringFormat: "Role ID: {0}"));
                roleLabel.SetBinding(Label.IsVisibleProperty, new Binding("RoleId"));
                Grid.SetRow(roleLabel, 2);


                grid.Children.Add(nameLabel);
                grid.Children.Add(dobLabel);
                grid.Children.Add(roleLabel);

                frame.Content = grid;

                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += async (s, e) => 
                {
                    if (frame.BindingContext is PlayerModel player)
                    {
                        await Shell.Current.GoToAsync($"{nameof(PlayerDetailsPage)}?playerId={player.Id}");
                    }

                };
                frame.GestureRecognizers.Add(tapGesture);

                return frame;
            })
        };
        
        var mainGrid = (Grid)Content;
        mainGrid.Children.Add(_playersCollection);
        Grid.SetRow(_playersCollection, 1);
    }

    public List<PlayerModel> Players { get; set; } = new();
    public bool HasNextPage { get; set; }
    private int CurrentPage { get; set; }
    private const int PageSize = 5;

    public bool IsLoading { get; set; }

    protected override async void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
        CurrentPage = 0;
        await LoadMorePlayers();
    }

    private async void OnLoadMorePlayers(object sender, EventArgs e)
    {
        await LoadMorePlayers();
    }


    private async Task LoadMorePlayers()
    {
        if (IsLoading) return;

        IsLoading = true;
        try
        {
            var getManyModel = new GetManyPlayersModel
            {
                Skip = CurrentPage * PageSize,
                Limit = PageSize,
            };

            var response = await _playersProvider.GetPlayersAsync(getManyModel);
            
            if (response.Data != null)
            {
                if (CurrentPage == 0)
                {
                    _items.Clear();
                }

                foreach (var player in response.Data.Data)
                {
                    _items.Add(player);
                }

                _playersCollection.ItemsSource = null;
                _playersCollection.ItemsSource = _items;

                HasNextPage = response.Data.HasNext;
                CurrentPage++;
            }
        }
        finally
        {
            IsLoading = false;
        }
    }

    private void NavigateToPlayerProfile(int playerId)
    {
        Shell.Current.GoToAsync($"//{nameof(PlayerDetailsPage)}?playerId={playerId}");
    }

    private async void NavigateToCreatePlayer(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(CreatePlayerPage));
    }

    private async Task OnScroll(ScrolledEventArgs e)
    {
        if (HasNextPage && !IsLoading)
        {
            await LoadMorePlayers();
        }
    }
}
