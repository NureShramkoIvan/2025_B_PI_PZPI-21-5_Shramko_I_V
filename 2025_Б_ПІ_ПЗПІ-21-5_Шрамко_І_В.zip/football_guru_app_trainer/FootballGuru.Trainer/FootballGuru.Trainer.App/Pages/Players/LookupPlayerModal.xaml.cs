using System.Collections.ObjectModel;
using FootballGuru.Trainer.Core.Models.Players;
using FootballGuru.Trainer.Data.Providers.Abstract;

namespace FootballGuru.Trainer.App.Pages.Players;

[QueryProperty(nameof(Line), "line")]
[QueryProperty(nameof(Position), "position")]
public partial class LookupPlayerModal : ContentPage
{
    private readonly IPlayersProvider _playersProvider;

    private int _currentPage;
    private const int PageSize = 10;
    private CollectionView _playersCollection;
    public int Line { get; set; }
    public int Position { get; set; }


    public LookupPlayerModal(IPlayersProvider playersProvider)
    {
        InitializeComponent();
        _playersProvider = playersProvider;
        BindingContext = this;

        var mainGrid = new Grid
        {
            RowDefinitions = new RowDefinitionCollection
            {
                new RowDefinition { Height = GridLength.Star },
                new RowDefinition { Height = GridLength.Auto }
            },
            Padding = new Thickness(16)
        };

        _playersCollection = new CollectionView
        {
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var frame = new Frame
                {
                    Margin = new Thickness(0, 4),
                    Padding = new Thickness(16)
                };

                var grid = new Grid
                {
                    RowDefinitions = new RowDefinitionCollection
                    {
                        new RowDefinition { Height = GridLength.Auto },
                        new RowDefinition { Height = GridLength.Auto }
                    }
                };

                var nameLabel = new Label
                {
                    FontSize = 16
                };
                nameLabel.SetBinding(Label.TextProperty, new MultiBinding
                {
                    Bindings = new Collection<BindingBase>
                    {
                        new Binding("FirstName"),
                        new Binding("LastName")
                    },
                    StringFormat = "{0} {1}"
                });
                Grid.SetRow(nameLabel, 0);

                var dobLabel = new Label
                {
                    FontSize = 14,
                    TextColor = Colors.Gray
                };
                dobLabel.SetBinding(Label.TextProperty, new Binding("DateOfBirth", stringFormat: "Born: {0:d}"));
                Grid.SetRow(dobLabel, 1);

                grid.Children.Add(nameLabel);
                grid.Children.Add(dobLabel);
                frame.Content = grid;

                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += async (sender, args) =>
                {
                    if (sender is Frame roleFrame && roleFrame.BindingContext is PlayerModel player)
                    {
                        await Shell.Current.GoToAsync("..", new Dictionary<string, object>
                        {
                            { "selectedPlayer", (Line, Position, player) },
                            { "from", "LookupPlayerModal" }
                        });


                    }
                };
                frame.GestureRecognizers.Add(tapGesture);

                return frame;
            })
        };
        Grid.SetRow(_playersCollection, 0);

        var navigationGrid = new Grid
        {
            ColumnDefinitions = new ColumnDefinitionCollection
            {
                new ColumnDefinition { Width = GridLength.Auto },
                new ColumnDefinition { Width = GridLength.Star },
                new ColumnDefinition { Width = GridLength.Auto }
            },
            Margin = new Thickness(0, 16, 0, 0)
        };

        var previousButton = new Button
        {
            Text = "Previous"
        };
        previousButton.Clicked += OnPreviousClicked;
        previousButton.SetBinding(Button.IsEnabledProperty, new Binding(nameof(HasPreviousPage)));
        Grid.SetColumn(previousButton, 0);

        var nextButton = new Button
        {
            Text = "Next"
        };
        nextButton.Clicked += OnNextClicked;
        nextButton.SetBinding(Button.IsEnabledProperty, new Binding(nameof(HasNextPage)));
        Grid.SetColumn(nextButton, 2);

        navigationGrid.Children.Add(previousButton);
        navigationGrid.Children.Add(nextButton);
        Grid.SetRow(navigationGrid, 1);

        mainGrid.Children.Add(_playersCollection);
        mainGrid.Children.Add(navigationGrid);

        Content = mainGrid;
    }

    public event Action<PlayerModel> PlayerSelected;
    public bool HasNextPage { get; set; }
    public bool HasPreviousPage => _currentPage > 0;

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadPlayers();
    }

    private async Task LoadPlayers()
    {
        var model = new GetManyPlayersModel
        {
            Skip = _currentPage * PageSize,
            Limit = PageSize
        };

        var response = await _playersProvider.GetPlayersAsync(model);

        if (response.Status == Core.Enums.Common.Status.Success)
        {
            _playersCollection.ItemsSource = response.Data.Data;
            HasNextPage = response.Data.HasNext;
            OnPropertyChanged(nameof(HasNextPage));
            OnPropertyChanged(nameof(HasPreviousPage));
        }
    }

    private async void OnPreviousClicked(object sender, EventArgs e)
    {
        if (_currentPage > 0)
        {
            _currentPage--;
            await LoadPlayers();
        }
    }

    private async void OnNextClicked(object sender, EventArgs e)
    {
        if (HasNextPage)
        {
            _currentPage++;
            await LoadPlayers();
        }
    }

    private void OnPlayerSelected(PlayerModel player)
    {
        PlayerSelected?.Invoke(player);
    }
} 