using FootballGuru.Trainer.Core.Models.Formations;
using FootballGuru.Trainer.Data.States;

namespace FootballGuru.Trainer.App.Pages.Training;

public partial class SelectFormationPage : ContentPage
{
    private readonly FormationsState _formationsState;
    private CollectionView _formationsCollection;

    public event Action<FormationModel> FormationSelected;

    public SelectFormationPage(FormationsState formationsState)
    {
        InitializeComponent();
        _formationsState = formationsState;
        BindingContext = this;

        var mainGrid = new Grid
        {
            RowDefinitions = new RowDefinitionCollection
            {
                new RowDefinition { Height = GridLength.Auto },
                new RowDefinition { Height = GridLength.Star }
            },
            Padding = new Thickness(16)
        };

        // Header
        var headerLabel = new Label
        {
            Text = "Select Formation",
            FontSize = 24,
            Margin = new Thickness(0, 0, 0, 16)
        };
        Grid.SetRow(headerLabel, 0);

        // Formations list
        _formationsCollection = new CollectionView
        {
            SelectionMode = SelectionMode.Single,
            ItemTemplate = new DataTemplate(() =>
            {
                var frame = new Frame
                {
                    Margin = new Thickness(0, 4),
                    Padding = new Thickness(16),
                    BorderColor = Colors.LightGray
                };

                var nameLabel = new Label
                {
                    FontSize = 18
                };
                nameLabel.SetBinding(Label.TextProperty, new Binding("Name"));

                frame.Content = nameLabel;

                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += (s, e) =>
                {
                    if (frame.BindingContext is FormationModel formation)
                    {
                        OnFormationSelected(formation);
                    }
                };
                frame.GestureRecognizers.Add(tapGesture);


                return frame;
            })
        };
        Grid.SetRow(_formationsCollection, 1);

        mainGrid.Children.Add(headerLabel);
        mainGrid.Children.Add(_formationsCollection);

        Content = mainGrid;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        LoadFormations();
    }

    private void LoadFormations()
    {
        if (_formationsState.IsInitialized)
        {
            _formationsCollection.ItemsSource = _formationsState.Formations;
        }
    }

    private void OnFormationSelected(FormationModel formation)
    {
        // Navigate back with the selected formation
        FormationSelected?.Invoke(formation);
    }

} 