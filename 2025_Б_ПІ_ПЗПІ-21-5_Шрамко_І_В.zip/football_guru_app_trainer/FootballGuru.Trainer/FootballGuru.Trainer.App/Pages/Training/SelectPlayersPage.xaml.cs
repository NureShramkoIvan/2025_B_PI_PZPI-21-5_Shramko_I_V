using FootballGuru.Trainer.Core.Models.Formations;
using FootballGuru.Trainer.Data.States;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.App.Pages.Players;
using FootballGuru.Trainer.Core.Models.Players;

namespace FootballGuru.Trainer.App.Pages.Training;

[QueryProperty(nameof(FormationId), "formationId")]
[QueryProperty(nameof(SelectedPlayer), "selectedPlayer")]
[QueryProperty(nameof(Actions), "actions")]
[QueryProperty(nameof(From), "from")]
public partial class SelectPlayersPage : ContentPage
{
    private readonly FormationsState _formationsState;
    private readonly IPlayersProvider _playersProvider;
    private readonly ColorsState _colorsState;
    private HashSet<int> _usedColorIds = new();
    private FormationModel _formation;

    public int FormationId { get; set; }
    public (int line, int position, PlayerModel player) _selectedPlayer;
    public List<string> _actions = [];
    
    private string _from;
    public string From { 
        get => _from;
        set
        {
            _from = value;
            if(From == "LookupPlayerModal")
            {
                DisplayPlayerInCircle(SelectedPlayer.line, SelectedPlayer.position, SelectedPlayer.player);
            }
            if(From == "CustomActionsModal")
            {
                AddActionsToPlayer(PlayerForAction.line, PlayerForAction.position, _actions);
            }
        }
    }

    public List<(int line, int position, PlayerModel player, List<string> customActions, int colorId)> SelectedPlayers { get; set; } = [];

    public (int line, int position, PlayerModel player) SelectedPlayer
    {
        get => _selectedPlayer;
        set
        {
            // if(From == "LookupPlayerModal")
            // {
                _selectedPlayer = value;
                //DisplayPlayerInCircle(SelectedPlayer.line, SelectedPlayer.position, SelectedPlayer.player);
            // }
        }


    }
  
    public (int line, int position, PlayerModel player) PlayerForAction { get; set; }
    public List<string> Actions { 
        get => _actions;
        set
        {
            // if(From == "CustomActionsModal")
            // {
                _actions = value;
                //AddActionsToPlayer(SelectedPlayer.line, SelectedPlayer.position, _actions);
            //}
        }

    }

    public event Action<List<(int playerId, List<string> customActions, int line, int position, int colorId)>> PlayersConfigured;

    private string FormatPlayerName(PlayerModel player)
    {
        if (player == null)
        {
            return "";
        }

        return string.Concat(player.FirstName.ToUpper()[0], player.LastName.ToUpper()[0]);
    }

    private void AddActionsToPlayer(int line, int position, List<string> actions)
    {
        var selectedPlayer = SelectedPlayers.FindIndex(p => p.line == line && p.position == position);
        var a = SelectedPlayers[selectedPlayer];
        SelectedPlayers.RemoveAt(selectedPlayer);
        a.customActions = actions;
        SelectedPlayers.Add(a);
        UpdateActionCount(line, position, actions.Count);
    }

    private void UpdateActionCount(int line, int position, int actionCount)
    {
        var positionCircle = PitchLayout.Children
            .OfType<Grid>()
            .SelectMany(g => g.Children)
            .OfType<StackLayout>()
            .SelectMany(sl => sl.Children)
            .OfType<Button>()
            .FirstOrDefault(b => b.CommandParameter is (int l, int p) && l == line && p == position);

        if (positionCircle != null)
        {
            var actionCountLabel = new Label
            {
                Text = actionCount.ToString(),
                FontSize = 12,
                BackgroundColor = Color.FromArgb("#FF0000"),
                TextColor = Color.FromArgb("#FFFFFF"),
                WidthRequest = 20,
                HeightRequest = 20,
                HorizontalTextAlignment = TextAlignment.Center,
                VerticalTextAlignment = TextAlignment.Center,
                Margin = new Thickness(-10, -10, 0, 0)
            };


            var parent = (StackLayout)positionCircle.Parent;
            parent.Children.Add(actionCountLabel);
        }
    }

    private int GetRandomUnusedColor()
    {
        var availableColors = _colorsState.Colors
            .Where(c => !_usedColorIds.Contains(c.Id))
            .ToList();

        if (!availableColors.Any())
        {
            throw new InvalidOperationException("No more unique colors available");
        }

        var randomColor = availableColors[Random.Shared.Next(availableColors.Count())];
        _usedColorIds.Add(randomColor.Id);
        return randomColor.Id;
    }

    private void DisplayPlayerInCircle(int line, int position, PlayerModel player)
    {
        if (SelectedPlayers.Any(p => p.player != null && p.player.Id == player.Id))
        {
            DisplayAlert("Error", "This player is already picked for a different position.", "OK");
            return;
        }

        var colorId = GetRandomUnusedColor();
        var selectedPlayer = SelectedPlayers.FindIndex(p => p.line == line && p.position == position);
        var oldPlayer = SelectedPlayers[selectedPlayer];

        // If replacing a player, free up their color
        if (oldPlayer.player != null && oldPlayer.colorId != 0)
        {
            _usedColorIds.Remove(oldPlayer.colorId);
        }

        SelectedPlayers.RemoveAt(selectedPlayer);
        SelectedPlayers.Add((line, position, player, [], colorId));

        LoadFormation();
    }

    private void PopulateSelectedPlayers()
    {
        if (SelectedPlayers.Any()) return;

        for(int i = 0; i < _formation.Lines.Count; i++)
        {
            for(int j = 0; j < _formation.Lines[i].Positions.Count; j++)
            {
                SelectedPlayers.Add((_formation.Lines[i].Order, _formation.Lines[i].Positions[j].Order, null, [], 0));
            }
        }
    }

    public SelectPlayersPage(FormationsState formationsState, IPlayersProvider playersProvider, ColorsState colorsState)
    {
        InitializeComponent();
        _formationsState = formationsState;
        _playersProvider = playersProvider;
        _colorsState = colorsState;
        BindingContext = this;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        LoadFormation();
    }

    private void LoadFormation()
    {
        // Get the formation ID from the query
        _formation = _formationsState.Formations.FirstOrDefault(f => f.Id == FormationId);

        PopulateSelectedPlayers();

        if (_formation != null)
        {
            GenerateFormationUI();
        }
    }

    private void GenerateFormationUI()
    {
        // Clear existing UI elements
        PitchLayout.Children.Clear();

        // Create a grid for the pitch and players
        var mainGrid = new Grid
        {
            VerticalOptions = LayoutOptions.FillAndExpand,
            HorizontalOptions = LayoutOptions.FillAndExpand,
            RowDefinitions = new RowDefinitionCollection
            {
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) },
                new RowDefinition { Height = GridLength.Auto }
            }
        };

        // Create a pitch background
        var pitchBackground = new BoxView
        {
            Color = Color.FromArgb("#008000"),
            VerticalOptions = LayoutOptions.FillAndExpand,
            HorizontalOptions = LayoutOptions.FillAndExpand
        };
        mainGrid.Children.Add(pitchBackground);

        
        // Add save button at the bottom
        var saveButton = new Button

        {
            Text = "Save Configuration",
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.End,
            Margin = new Thickness(0, 20, 0, 20)
        };
        saveButton.Clicked += OnSaveConfigurationClicked;

        mainGrid.Children.Add(saveButton);


        // Create a vertical stack for the formation
        var formationStack = new StackLayout
        {
            Spacing = 50, // Add spacing between lines
            VerticalOptions = LayoutOptions.CenterAndExpand
        };

        // Add rows based on the formation
        foreach (var line in _formation.Lines)
        {
            // Create a horizontal stack for the current line
            var lineStack = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                HorizontalOptions = LayoutOptions.CenterAndExpand,
                Spacing = 50 // Add spacing between circles
            };

            // Add circles for each position in the line
            foreach (var position in line.Positions)
            {
                var selectedPlayer = SelectedPlayers.FirstOrDefault(p => 
                    p.line == line.Order && p.position == position.Order);
                
                var color = selectedPlayer.colorId != 0 
                    ? _colorsState.Colors.FirstOrDefault(c => c.Id == selectedPlayer.colorId)?.Hex 
                    : "#FFFFFF";

                var circleContainer = new Grid
                {
                    WidthRequest = 50,
                    HeightRequest = 50
                };

                var positionCircle = new Button
                {
                    BackgroundColor = Color.FromArgb(color),
                    BorderColor = Color.FromArgb("#000000"),
                    BorderWidth = 1,
                    CornerRadius = 25,
                    WidthRequest = 50,
                    HeightRequest = 50,
                    VerticalOptions = LayoutOptions.Center,
                    HorizontalOptions = LayoutOptions.Center,
                    Text = FormatPlayerName(selectedPlayer.player),
                    TextColor = Color.FromArgb("#000000"),
                    CommandParameter = (line.Order, position.Order)
                };

                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += async (s, e) =>
                {
                    var selectedPlayer = SelectedPlayers.FirstOrDefault(p => p.line == line.Order && p.position == position.Order);
                    if (selectedPlayer.player != null)
                    {
                        PlayerForAction = (line.Order, position.Order, selectedPlayer.player);
                        await Shell.Current.GoToAsync(nameof(CustomActionsModal) + $"?line={line.Order}&position={position.Order}");
                    }
                    else
                    {
                        await Shell.Current.GoToAsync(nameof(LookupPlayerModal) + $"?line={line.Order}&position={position.Order}");
                    }
                };
                positionCircle.GestureRecognizers.Add(tapGesture);

                circleContainer.Children.Add(positionCircle);

                // Add action count label if there are actions
                var actions = SelectedPlayers.FirstOrDefault(p => p.line == line.Order && p.position == position.Order).customActions;
                if (actions != null && actions.Count > 0)
                {
                    var actionCountLabel = new Label
                    {
                        Text = actions.Count.ToString(),
                        FontSize = 12,
                        BackgroundColor = Color.FromArgb("#FF0000"),
                        TextColor = Color.FromArgb("#FFFFFF"),
                        WidthRequest = 20,
                        HeightRequest = 20,
                        HorizontalTextAlignment = TextAlignment.Center,
                        VerticalTextAlignment = TextAlignment.Center,
                        HorizontalOptions = LayoutOptions.End,
                        VerticalOptions = LayoutOptions.Start,
                        Margin = new Thickness(0, -10, -10, 0)
                    };
                    circleContainer.Children.Add(actionCountLabel);
                }

                lineStack.Children.Add(circleContainer);
            }

            formationStack.Children.Add(lineStack);
        }

        // Add the formation stack to the main grid
        mainGrid.Children.Add(formationStack);

        PitchLayout.Children.Add(mainGrid);

    }

    private async void OnSaveConfigurationClicked(object sender, EventArgs e)
    {
        var emptyPositions = SelectedPlayers.Where(p => p.player == null).ToList();
        if (emptyPositions.Any())
        {
            await DisplayAlert("Validation Error", 
                "Please select players for all positions before saving.", "OK");
            return;
        }

        var playerConfigurations = SelectedPlayers
            .Select(p => (p.player.Id, p.customActions, p.line, p.position, p.colorId))
            .ToList();

        PlayersConfigured?.Invoke(playerConfigurations);
        SelectedPlayers = [];
        _usedColorIds.Clear();
    }
}