using System.ComponentModel;

namespace FootballGuru.Trainer.App.Pages.Training;

public partial class CreateTrainingPage : ContentPage, INotifyPropertyChanged
{
    private DateTime _selectedDate = DateTime.Today;
    private TimeSpan _selectedTime = DateTime.Now.TimeOfDay;

    public event Action<string, DateTime> TrainingCreated;

    public DateTime MinDate => DateTime.Today;

    public DateTime SelectedDate
    {
        get => _selectedDate;
        set
        {
            if (_selectedDate != value)
            {
                _selectedDate = value;
                OnPropertyChanged(nameof(SelectedDate));
            }
        }
    }

    public TimeSpan SelectedTime
    {
        get => _selectedTime;
        set
        {
            if (_selectedTime != value)
            {
                _selectedTime = value;
                OnPropertyChanged(nameof(SelectedTime));
            }
        }
    }

    public CreateTrainingPage()
    {
        InitializeComponent();
        BindingContext = this;
    }

    private async void OnCreateClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NameEntry.Text))
        {
            await DisplayAlert("Validation Error", "Please enter a training name", "OK");
            return;
        }

        var trainingDateTime = SelectedDate.Date + SelectedTime;
        TrainingCreated?.Invoke(NameEntry.Text, trainingDateTime);
    }
} 