using FootballGuru.Trainer.Core.Models.Trainings;
using FootballGuru.Trainer.Data.Providers.Abstract;
using FootballGuru.Trainer.App.Infrastructure;
using System.Globalization;
using FootballGuru.Trainer.App.Infrastructure.Messages;

namespace FootballGuru.Trainer.App.Pages.Training;

[QueryProperty(nameof(Id), "id")]
public partial class TrainingPage : ContentPage
{
    private readonly ITrainingsProvider _trainingsProvider;
    private readonly IWifiDirect _wifi;
    private readonly MessagingHub _messagingHub;
    private readonly IFileService _fileService;
    private Guid _id;

    public bool IsLoading { get; set; }
    public bool IsLoaded { get; set; }
    public TrainingDetailsModel Training { get; set; }
    public Command StartTrainingCommand { get; }

    public bool IsConnected { get; set; } = false;

    public Guid Id
    {
        get => _id;
        set
        {
            _id = value;
            LoadTraining();
        }
    }

    public TrainingPage(ITrainingsProvider trainingsProvider, IWifiDirect wifi, MessagingHub messagingHub, IFileService fileService)
    {
        InitializeComponent();
        _trainingsProvider = trainingsProvider;
        _wifi = wifi;
        _messagingHub = messagingHub;
        _fileService = fileService;
        BindingContext = this;

        // Add converter to resources
        Resources.Add("IntToBoolConverter", new IntToBoolConverter());
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _wifi.StartAsync();
    }

    protected override void OnDisappearing()
    {
        _wifi.Stop();
        base.OnDisappearing();
    }

    private async void LoadTraining()
    {
        try
        {
            IsLoading = true;
            IsLoaded = false;
            OnPropertyChanged(nameof(IsLoading));
            OnPropertyChanged(nameof(IsLoaded));

            var response = await _trainingsProvider.GetTrainingAsync(new GetTrainingModel { Id = Id });

            if (response.Status == Core.Enums.Common.Status.Success && response.Data != null)
            {
                Training = response.Data;
                OnPropertyChanged(nameof(Training));
            }
        }
        finally
        {
            IsLoading = false;
            IsLoaded = true;
            OnPropertyChanged(nameof(IsLoading));
            OnPropertyChanged(nameof(IsLoaded));
        }
    }

    private async void StartTrainingClicked(object sender, EventArgs e)
    {
        await StartTrainingAsync();
    }

    private async Task StartTrainingAsync()
    {
        if (Training == null)
        {
            await DisplayAlert("Error", "Training data not loaded", "OK");
            return;
        }

        await ConnectDevices();
    }

    private async Task ConnectDevices()
    {
        try
        {
            var loc = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (loc != PermissionStatus.Granted)
            {
                loc = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            }

            var status = await Permissions.CheckStatusAsync<Permissions.NearbyWifiDevices>();
            if (status != PermissionStatus.Granted)
            {
                status = await Permissions.RequestAsync<Permissions.NearbyWifiDevices>();
            }

            if (loc != PermissionStatus.Granted || status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permissions required",
                    "location permissions are required for P2P discovery.",
                    "OK");
                return;
            }

            var goEp = await _wifi.CreateGroupAsync();
            if (goEp == null)
            {
                await DisplayAlert("Wi-Fi Direct", "Couldn't create Wi-Fi Direct group.", "OK");
                return;
            }

            await DisplayAlert("Info", "Waiting for connections", "OK");

            _messagingHub.Start();
            var cts = new CancellationTokenSource();

            await _messagingHub.WaitForConnections(cts.Token);

            if (!_messagingHub.IsConnected())
            {
                await DisplayAlert("Failure", "Failed to connect peers, timed out", "OK");
            }
            else
            {
                await DisplayAlert("Success", "Devices are connected", "OK");
                StatusLabel.Text = "Devices connected - Ready to start training";
            }

            cts.Cancel();

            var message = new Message<TrainingDetailsModel>()
            {
                Data = Training,
                Type = MessageTypes.TRAINING_CONFIG
            };

            await _messagingHub.SendMessage(AllowedPeers.CAMERA, message);
            await _messagingHub.SendMessage(AllowedPeers.SCREEN, message);

            await DisplayAlert("Success", "Training configuration sent to devices", "OK");

            IsConnected = true;
            OnPropertyChanged(nameof(IsConnected));
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"Failed to start training: {ex.Message}", "OK");
        }
    }

    private async void OnDownloadClicked(object sender, EventArgs e)
    {
        if (Training == null)
        {
            await DisplayAlert("Error", "Training data not loaded", "OK");
            return;
        }

        try
        {
            var success = await _fileService.SaveTrainingAsync(Training);
            if (success)
            {
                await DisplayAlert("Success", "Training saved successfully", "OK");
            }
            else
            {
                await DisplayAlert("Error", "Failed to save training", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"Failed to save training: {ex.Message}", "OK");
        }
    }

    private async void OnNotifyClicked(object sender, EventArgs e)
    {
        if (sender is Button button)
        {
            var playerId = (int)button.CommandParameter;
            var action = (string)((Grid)button.Parent).Children.OfType<Label>().First().Text;
            
            // TODO: Implement notification logic
            // You can use playerId and action here

            var actionMessage = new Message<CustomActionMessage>()
            {
                Type = MessageTypes.CUSTOM_ACTION,
                Data = new() { PlayerId = playerId, Action = action }
            };

            await _messagingHub.SendMessage(AllowedPeers.SCREEN, actionMessage);
        }
    }
}

public class IntToBoolConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is int count)
        {
            bool invert = parameter?.ToString() == "invert";
            bool result = count > 0;
            return invert ? !result : result;
        }
        return false;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}