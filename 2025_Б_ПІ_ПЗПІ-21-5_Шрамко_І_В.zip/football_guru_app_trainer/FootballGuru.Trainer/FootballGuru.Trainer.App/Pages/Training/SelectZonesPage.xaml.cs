using FootballGuru.Trainer.Core.Models.Formations;
using FootballGuru.Trainer.Data.States;
using Microsoft.Maui.Layouts;

namespace FootballGuru.Trainer.App.Pages.Training;

[QueryProperty(nameof(FormationId), "formationId")]
public partial class SelectZonesPage : ContentPage
{
    private readonly FormationsState _formationsState;
    private FormationModel _formation;
    private List<(int line, int position, double size, double x, double y)> _zones = new();
    private const double InitialZoneSize = 60;
    private BoxView _activeZone;
    private double _initialX, _initialY;
    private const double CircleSize = 50;
    private double _fieldWidth;
    private double _fieldHeight;
    private const double FieldWidthMeters = 22;
    private const double FieldLengthMeters = 42;
    private const double SizeStep = 10;
    public event Action<List<(int line, int position, double leftCm, double rightCm, double topCm, double bottomCm)>> ZonesConfigured;

    private class ZoneState
    {
        public int Line { get; set; }
        public int Position { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
    }

    private Dictionary<(int line, int position), ZoneState> _zoneStates = new();

    public int FormationId { get; set; }

    public SelectZonesPage(FormationsState formationsState)
    {
        InitializeComponent();
        _formationsState = formationsState;
        BindingContext = this;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        LoadFormation();
    }

    private void LoadFormation()
    {
        _formation = _formationsState.Formations.FirstOrDefault(f => f.Id == FormationId);

        if (_formation != null)
        {
            GenerateFormationUI();
        }
    }

    private void GenerateFormationUI()
    {
        PitchLayout.Children.Clear();

        var mainGrid = new Grid
        {
            VerticalOptions = LayoutOptions.FillAndExpand,
            HorizontalOptions = LayoutOptions.FillAndExpand,
            RowDefinitions = new RowDefinitionCollection
            {
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) },
                new RowDefinition { Height = GridLength.Auto }
            }
        };

        var pitchBackground = new BoxView
        {
            Color = Color.FromArgb("#008000"),
            VerticalOptions = LayoutOptions.FillAndExpand,
            HorizontalOptions = LayoutOptions.FillAndExpand
        };

        mainGrid.Children.Add(pitchBackground);

        var saveButton = new Button
        {
            Text = "Save Zones",
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.End,
            Margin = new Thickness(0, 20, 0, 20)
        };
        saveButton.Clicked += OnSaveZonesClicked;
        Grid.SetRow(saveButton, 1);
        mainGrid.Children.Add(saveButton);

        var formationContainer = new AbsoluteLayout
        {
            HorizontalOptions = LayoutOptions.FillAndExpand,
            VerticalOptions = LayoutOptions.FillAndExpand
        };

        Grid.SetRow(formationContainer, 0);
        mainGrid.Children.Add(formationContainer);
        PitchLayout.Children.Add(mainGrid);

        _fieldWidth = DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density - 30;
        _fieldHeight = DeviceDisplay.MainDisplayInfo.Height / DeviceDisplay.MainDisplayInfo.Density - 200;
        
        GeneratePositionsAndZones(formationContainer);
    }

    private void GeneratePositionsAndZones(AbsoluteLayout formationContainer)
    {
        formationContainer.Children.Clear();

        foreach (var line in _formation.Lines)
        {
            foreach (var position in line.Positions)
            {
                var positionCircle = new Button
                {
                    BackgroundColor = Color.FromArgb("#FFFFFF"),
                    BorderColor = Color.FromArgb("#000000"),
                    BorderWidth = 1,
                    CornerRadius = (int)(CircleSize / 2),
                    WidthRequest = CircleSize,
                    HeightRequest = CircleSize,
                    Text = position.Order.ToString(),
                    CommandParameter = (line.Order, position.Order)
                };

                double x = CalculateXPosition(line, position);
                double y = CalculateYPosition(line);

                AbsoluteLayout.SetLayoutBounds(positionCircle, new Rect(x - CircleSize/2, y - CircleSize/2, CircleSize, CircleSize));
                AbsoluteLayout.SetLayoutFlags(positionCircle, AbsoluteLayoutFlags.None);

                var tapGesture = new TapGestureRecognizer();
                tapGesture.Tapped += (s, e) =>
                {
                    if (!_zones.Any(z => z.line == line.Order && z.position == position.Order))
                    {
                        AddZoneWithControls(formationContainer, InitialZoneSize, line.Order, position.Order, x, y);
                        UpdateZone(line.Order, position.Order, InitialZoneSize, x, y);
                    }
                };
                positionCircle.GestureRecognizers.Add(tapGesture);

                var zone = _zones.FirstOrDefault(z => z.line == line.Order && z.position == position.Order);
                if (zone.size > 0)
                {
                    AddZoneWithControls(formationContainer, zone.size, line.Order, position.Order, x, y);
                }

                formationContainer.Children.Add(positionCircle);
            }
        }
    }

    private double CalculateXPosition(FormationLineModel line, FormationPositionModel position)
    {
        double horizontalSpacing = _fieldWidth / (line.Positions.Count + 1);
        return horizontalSpacing * position.Order;
    }

    private double CalculateYPosition(FormationLineModel line)
    {
        double verticalSpacing = _fieldHeight / (_formation.Lines.Count + 1);
        return verticalSpacing * line.Order;
    }

    private void AddZoneWithControls(AbsoluteLayout container, double size, int line, int position, double x, double y)
    {
        var existingSquare = container.Children.FirstOrDefault(c => 
            c is BoxView box && 
            box.GetValue(AbsoluteLayout.LayoutBoundsProperty) is Rect rect &&
            rect.X == x && rect.Y == y);

        if (existingSquare != null)
        {
            container.Children.Remove(existingSquare);
        }

        if (!_zoneStates.TryGetValue((line, position), out var zoneState))
        {
            zoneState = new ZoneState
            {
                Line = line,
                Position = position,
                Width = size,
                Height = size,
                X = x - (size - CircleSize) / 2,
                Y = y - (size - CircleSize) / 2
            };
            _zoneStates[(line, position)] = zoneState;
        }

        var zoneGrid = new Grid
        {
            WidthRequest = zoneState.Width + 80, // Extra space for buttons
            HeightRequest = zoneState.Height + 80
        };

        var zoneSquare = new BoxView
        {
            Color = Color.FromArgb("#80FF0000"),
            WidthRequest = zoneState.Width,
            HeightRequest = zoneState.Height,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center
        };

        var increaseButton = new Button
        {
            Text = "+",
            WidthRequest = 40,
            HeightRequest = 40,
            HorizontalOptions = LayoutOptions.End,
            VerticalOptions = LayoutOptions.Center
        };

        var decreaseButton = new Button
        {
            Text = "-",
            WidthRequest = 40,
            HeightRequest = 40,
            HorizontalOptions = LayoutOptions.Start,
            VerticalOptions = LayoutOptions.Center
        };

        increaseButton.Clicked += (s, e) =>
        {
            var newSize = Math.Min(zoneState.Width + SizeStep, Math.Min(_fieldWidth, _fieldHeight));
            zoneState.Width = newSize;
            zoneState.Height = newSize;
            zoneSquare.WidthRequest = newSize;
            zoneSquare.HeightRequest = newSize;
            UpdateZone(line, position, newSize, zoneState.X, zoneState.Y);
        };

        decreaseButton.Clicked += (s, e) =>
        {
            var newSize = Math.Max(InitialZoneSize, zoneState.Width - SizeStep);
            zoneState.Width = newSize;
            zoneState.Height = newSize;
            zoneSquare.WidthRequest = newSize;
            zoneSquare.HeightRequest = newSize;
            UpdateZone(line, position, newSize, zoneState.X, zoneState.Y);
        };

        zoneGrid.Children.Add(zoneSquare);
        zoneGrid.Children.Add(decreaseButton);
        zoneGrid.Children.Add(increaseButton);

        AbsoluteLayout.SetLayoutBounds(zoneGrid, new Rect(zoneState.X - 40, zoneState.Y - 40, zoneState.Width + 80, zoneState.Height + 80));
        AbsoluteLayout.SetLayoutFlags(zoneGrid, AbsoluteLayoutFlags.None);

        var panGesture = new PanGestureRecognizer();
        panGesture.PanUpdated += (s, e) =>
        {
            switch (e.StatusType)
            {
                case GestureStatus.Started:
                    _activeZone = zoneSquare;
                    _initialX = e.TotalX;
                    _initialY = e.TotalY;
                    break;

                case GestureStatus.Running:
                    if (_activeZone != null)
                    {
                        var bounds = (Rect)AbsoluteLayout.GetLayoutBounds(zoneGrid);
                        var deltaX = e.TotalX - _initialX;
                        var deltaY = e.TotalY - _initialY;

                        var newX = bounds.X + deltaX;
                        var newY = bounds.Y + deltaY;

                        //newX = Math.Max(-40, Math.Min(newX, _fieldWidth - bounds.Width + 40));
                        //newY = Math.Max(-40, Math.Min(newY, _fieldHeight - bounds.Height + 40));

                        AbsoluteLayout.SetLayoutBounds(zoneGrid, new Rect(newX, newY, bounds.Width, bounds.Height));
                        zoneState.X = newX;
                        zoneState.Y = newY;

                        UpdateZone(line, position, zoneState.Width, zoneState.X, zoneState.Y);
                        
                        _initialX = e.TotalX;
                        _initialY = e.TotalY;
                    }
                    break;

                case GestureStatus.Completed:
                    _activeZone = null;
                    break;
            }
        };

        zoneGrid.GestureRecognizers.Add(panGesture);
        container.Children.Add(zoneGrid);
    }

    private void UpdateZone(int line, int position, double size, double x, double y)
    {
        var existingZone = _zones.FindIndex(z => z.line == line && z.position == position);
        if (existingZone != -1)
        {
            _zones.RemoveAt(existingZone);
        }
        _zones.Add((line, position, size, x, y));
    }

    private void OnSaveZonesClicked(object sender, EventArgs e)
    {
        var zoneConfigurations = new List<(int line, int position, double leftCm, double rightCm, double topCm, double bottomCm)>();

        foreach (var zoneState in _zoneStates)
        {
            var zone = zoneState.Value;

            var leftDistance = zone.X;
            var rightDistance = _fieldWidth - (zone.X + zone.Width);
            var topDistance = zone.Y;
            var bottomDistance = _fieldHeight - (zone.Y + zone.Height);

            var leftCm = (leftDistance / _fieldWidth) * FieldWidthMeters * 100;
            var rightCm = (rightDistance / _fieldWidth) * FieldWidthMeters * 100;
            var topCm = (topDistance / _fieldHeight) * FieldLengthMeters * 100;
            var bottomCm = (bottomDistance / _fieldHeight) * FieldLengthMeters * 100;

            zoneConfigurations.Add((
                zone.Line,
                zone.Position,
                Math.Round(leftCm, 2),
                Math.Round(rightCm, 2),
                Math.Round(topCm, 2),
                Math.Round(bottomCm, 2)
            ));
        }

        ZonesConfigured?.Invoke(zoneConfigurations);
        _zoneStates = [];
        _zones = [];
        _activeZone = null;
    }
}