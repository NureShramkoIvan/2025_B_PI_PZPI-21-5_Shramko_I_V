namespace FootballGuru.Trainer.App.Logic.Models;

public class CreateTrainingLogicModel
{
    public string Name { get; set; }
    public DateTime DateTime { get; set; }
    public TeamConfigurationLogicModel TeamA { get; set; }
    public TeamConfigurationLogicModel TeamB { get; set; }
    
    public class TeamConfigurationLogicModel
    {
        public int FormationId { get; set; }
        public List<PlayerConfigurationLogicModel> Players { get; set; }
    }

    public class PlayerConfigurationLogicModel
    {
        public int PlayerId { get; set; }
        public int Line { get; set; }
        public int Position { get; set; }
        public List<string> CustomActions { get; set; }
        public ZoneConfigurationLogicModel Zone { get; set; }
        public int ColorId { get; set; }
    }

    public class ZoneConfigurationLogicModel
    {
        public double LeftDistanceCm { get; set; }
        public double RightDistanceCm { get; set; }
        public double TopDistanceCm { get; set; }
        public double BottomDistanceCm { get; set; }
    }
}

