using FootballGuru.Trainer.App.Logic.Models;
using FootballGuru.Trainer.Core.Enums.Common;
using FootballGuru.Trainer.Core.Models.Formations;
using FootballGuru.Trainer.Core.Models.Trainings;
using FootballGuru.Trainer.Data.Providers.Abstract;

public class CreateTrainingStateMachine
{
    private readonly ITrainingsProvider _trainingsProvider;
    private CreateTrainingLogicModel _createTrainingLogicModel;
    private CreateTrainingState _currentState;

    public CreateTrainingStateMachine(ITrainingsProvider trainingsProvider)
    {
        _trainingsProvider = trainingsProvider;
    }

    public async Task Start()
    {
        _currentState = CreateTrainingState.Started;
        _createTrainingLogicModel = new();
        await Shell.Current.GoToAsync("SelectFormationPage");
    }

    public async Task HandleFormationSelected(FormationModel formation)
    {
        if (_currentState == CreateTrainingState.Started)
        {
            _currentState = CreateTrainingState.TeamAFormationSelected;
            _createTrainingLogicModel.TeamA = new() { FormationId = formation.Id };
            await Shell.Current.GoToAsync($"SelectPlayersPage?formationId={formation.Id}");
        }

        if (_currentState == CreateTrainingState.TeamAZonesConfigured)
        {
            _currentState = CreateTrainingState.TeamBFormationSelected;
            _createTrainingLogicModel.TeamB = new() { FormationId = formation.Id };
            await Shell.Current.GoToAsync($"SelectPlayersPage?formationId={formation.Id}");
        }
    }

    public async Task HandlePlayersConfigured(List<(int playerId, List<string> customActions, int line, int position, int colorId)> playerConfigurations)
    {
        var players = playerConfigurations
            .Select(p => new CreateTrainingLogicModel.PlayerConfigurationLogicModel
            {
                PlayerId = p.playerId,
                CustomActions = p.customActions,
                Line = p.line,
                Position = p.position,
                ColorId = p.colorId
            })
            .ToList();

        if (_currentState == CreateTrainingState.TeamAFormationSelected)
        {
            _createTrainingLogicModel.TeamA.Players = players;
            _currentState = CreateTrainingState.TeamAPlayersConfigured;
            await Shell.Current.GoToAsync($"SelectZonesPage?formationId={_createTrainingLogicModel.TeamA.FormationId}");
        }
        else if (_currentState == CreateTrainingState.TeamBFormationSelected)
        {
            _createTrainingLogicModel.TeamB.Players = players;
            _currentState = CreateTrainingState.TeamBPlayersConfigured;
            await Shell.Current.GoToAsync($"SelectZonesPage?formationId={_createTrainingLogicModel.TeamB.FormationId}");
        }
    }

    public async Task HandleZonesConfigured(List<(int line, int position, double leftCm, double rightCm, double topCm, double bottomCm)> zoneConfigurations)
    {
        if (_currentState == CreateTrainingState.TeamAPlayersConfigured)
        {
            foreach (var player in _createTrainingLogicModel.TeamA.Players)
            {
                var zone = zoneConfigurations.FirstOrDefault(z => z.line == player.Line && z.position == player.Position);
                player.Zone = new CreateTrainingLogicModel.ZoneConfigurationLogicModel
                {
                    LeftDistanceCm = zone.leftCm,
                    RightDistanceCm = zone.rightCm,
                    TopDistanceCm = zone.topCm,
                    BottomDistanceCm = zone.bottomCm
                };
            }
            _currentState = CreateTrainingState.TeamAZonesConfigured;
            await Shell.Current.GoToAsync("SelectFormationPage");
            
        }
        else if (_currentState == CreateTrainingState.TeamBPlayersConfigured)
        {
            foreach (var player in _createTrainingLogicModel.TeamB.Players)
            {
                var zone = zoneConfigurations.FirstOrDefault(z => z.line == player.Line && z.position == player.Position);
                player.Zone = new CreateTrainingLogicModel.ZoneConfigurationLogicModel
                {
                        LeftDistanceCm = zone.leftCm,
                        RightDistanceCm = zone.rightCm,
                        TopDistanceCm = zone.topCm,
                        BottomDistanceCm = zone.bottomCm
                };
            }
            _currentState = CreateTrainingState.TeamBZonesConfigured;
            await Shell.Current.GoToAsync("CreateTrainingPage");
        }
    }

    public async Task HandleTrainingCreated(string name, DateTime dateTime)
    {
        if (_currentState == CreateTrainingState.TeamBZonesConfigured)
        {
            _createTrainingLogicModel.Name = name;
            _createTrainingLogicModel.DateTime = dateTime;
            _currentState = CreateTrainingState.Completed;

            var createTrainingModel = new CreateTrainingModel
            {
                Name = _createTrainingLogicModel.Name,
                DateTime = _createTrainingLogicModel.DateTime,
                TeamA = new CreateTrainingModel.TeamConfigurationModel
                {
                    FormationId = _createTrainingLogicModel.TeamA.FormationId,
                    Players = _createTrainingLogicModel.TeamA.Players.Select(p => new CreateTrainingModel.PlayerConfigurationModel
                    {
                        PlayerId = p.PlayerId,
                        Line = p.Line,
                        Position = p.Position,
                        CustomActions = p.CustomActions,
                        ColorId = p.ColorId,
                        Zone = new CreateTrainingModel.ZoneConfigurationModel
                        {
                            LeftDistanceCm = p.Zone.LeftDistanceCm,
                            RightDistanceCm = p.Zone.RightDistanceCm,
                            TopDistanceCm = p.Zone.TopDistanceCm,
                            BottomDistanceCm = p.Zone.BottomDistanceCm
                        }
                    }).ToList()
                },
                TeamB = new CreateTrainingModel.TeamConfigurationModel
                {
                    FormationId = _createTrainingLogicModel.TeamB.FormationId,
                    Players = _createTrainingLogicModel.TeamB.Players.Select(p => new CreateTrainingModel.PlayerConfigurationModel
                    {
                        PlayerId = p.PlayerId,
                        Line = p.Line,
                        Position = p.Position,
                        CustomActions = p.CustomActions,
                        ColorId = p.ColorId,
                        Zone = new CreateTrainingModel.ZoneConfigurationModel
                        {
                            LeftDistanceCm = p.Zone.LeftDistanceCm,
                            RightDistanceCm = p.Zone.RightDistanceCm,
                            TopDistanceCm = p.Zone.TopDistanceCm,
                            BottomDistanceCm = p.Zone.BottomDistanceCm
                        }
                    }).ToList()
                }
            };
            
            var response = await _trainingsProvider.CreateTrainingAsync(createTrainingModel);

            if (response.Status == Status.Success)
            {
                await Shell.Current.GoToAsync("//HomePage");
            }
            else
            {
                // Handle error - you might want to show an alert or handle it differently
                System.Diagnostics.Debug.WriteLine($"Failed to create training: {response.Message}");
            }
        }
    }
}

public enum CreateTrainingState
{
    None,
    Started,
    TeamAFormationSelected,
    TeamAPlayersConfigured,
    TeamAZonesConfigured,
    TeamBFormationSelected,
    TeamBPlayersConfigured,
    TeamBZonesConfigured,
    Completed
}
