﻿using Android.Content;
using Android.Net.Wifi.P2p;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using Android.Runtime;
using FootballGuru.Trainer.App.Infrastructure;

namespace FootballGuru.Trainer.App.Platforms.Android
{
    public class WifiDirect : Java.Lang.Object, IWifiDirect, WifiP2pManager.IConnectionInfoListener
    {
        private WifiP2pManager _manager;
        private WifiP2pManager.Channel _channel;
        private WifiDirectBroadcastReceiver _receiver;
        private TaskCompletionSource<IPEndPoint?> _tcsGoIp;

        public async Task StartAsync()
        {
            var ctx = Platform.CurrentActivity;
            _manager = (WifiP2pManager)ctx.GetSystemService(Context.WifiP2pService);
            _channel = _manager.Initialize(ctx, ctx.MainLooper, null);

            var removeTcs = new TaskCompletionSource<bool>();
            var listener = new SimpleActionListener();

            listener.Success += () => removeTcs.TrySetResult(true);
            listener.Failure += _ => removeTcs.TrySetResult(false);

            _manager.RemoveGroup(_channel,listener);
            await removeTcs.Task.ConfigureAwait(false);

            _receiver = new WifiDirectBroadcastReceiver(_manager, _channel, this);
            var filter = new IntentFilter();
            filter.AddAction(WifiP2pManager.WifiP2pStateChangedAction);
            filter.AddAction(WifiP2pManager.WifiP2pPeersChangedAction);
            filter.AddAction(WifiP2pManager.WifiP2pConnectionChangedAction);

            ctx.RegisterReceiver(_receiver, filter);

            // Hook up the receiver's event to our method
            _receiver.ConnectionInfoAvailable += OnConnectionInfoAvailable;
        }

        public Task<IPEndPoint?> CreateGroupAsync()
        {
            _manager.RemoveGroup(_channel, null);
            _tcsGoIp = new TaskCompletionSource<IPEndPoint?>();

            var listener = new SimpleActionListener();
            listener.Success += () =>
            {
                // group is now up; Android will send a CONNECTION_CHANGED broadcast,
                // our receiver catches it, does RequestConnectionInfo, and invokes
                // OnConnectionInfoAvailable → _tcsGoIp.TrySetResult(...)
            };
            listener.Failure += reason =>
            {
                _tcsGoIp.TrySetResult(null);
            };

            _manager.CreateGroup(_channel, listener);

            return _tcsGoIp.Task;
        }

        public void OnConnectionInfoAvailable(WifiP2pInfo info)
        {
            if (info.GroupFormed)
            {
                if (info.IsGroupOwner)
                {
                    // We're the GO, return our IP
                    try
                    {
                        var goIp = new IPEndPoint(IPAddress.Parse(info.GroupOwnerAddress.HostAddress), 8888);
                        _tcsGoIp.TrySetResult(goIp);
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    // We're a client; connect to GO
                    var clientEp = new IPEndPoint(IPAddress.Parse(info.GroupOwnerAddress.HostAddress), 8888);
                    _tcsGoIp.TrySetResult(clientEp);
                }
            }
        }

        // ------------- send / receive over TCP -------------

        public async Task SendAsync(byte[] payload, int port = 8888)
        {
            using var listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            using var client = await listener.AcceptTcpClientAsync().ConfigureAwait(false);
            using var ns = client.GetStream();
            await ns.WriteAsync(payload.AsMemory(0, payload.Length)).ConfigureAwait(false);
        }

        public Task<byte[]> ReceiveAsync(int port = 8888, int expected = 0)
            => throw new NotSupportedException("Trainer only sends");

        public Task<IPEndPoint?> ConnectAsync(string? ssidHint = null)
            => throw new NotSupportedException("Trainer is Group Owner");

        public void Stop()
        {
            var ctx = Platform.CurrentActivity;
            ctx.UnregisterReceiver(_receiver);
            _manager.RemoveGroup(_channel, new SimpleActionListener());
        }
    }

    // Simple listener implementation
    public class SimpleActionListener : Java.Lang.Object, WifiP2pManager.IActionListener
    {
        public event Action Success;
        public event Action<string> Failure;

        public void OnSuccess()
        {
            Success?.Invoke();
        }

        public void OnFailure([GeneratedEnum] WifiP2pFailureReason reason)
        {
            Failure?.Invoke(reason.ToString());
        }
    }
}
