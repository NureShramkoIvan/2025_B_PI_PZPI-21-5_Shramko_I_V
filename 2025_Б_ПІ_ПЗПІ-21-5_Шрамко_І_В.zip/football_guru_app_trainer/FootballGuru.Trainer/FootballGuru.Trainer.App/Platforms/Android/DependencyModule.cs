﻿using FootballGuru.Trainer.App.Infrastructure;
using FootballGuru.Trainer.App.Platforms.Android;

namespace FootballGuru.Trainer.App;

public static class DependencyModule
{
    public static IServiceCollection AddPlatformServices(this IServiceCollection services)
    {
        services.AddSingleton<IWifiDirect, WifiDirect>();
        return services;
    }
}
