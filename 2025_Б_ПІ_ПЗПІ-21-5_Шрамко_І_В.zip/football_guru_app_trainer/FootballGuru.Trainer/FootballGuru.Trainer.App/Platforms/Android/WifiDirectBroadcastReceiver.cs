﻿using Android.Content;
using Android.Net.Wifi.P2p;
using Android.Net.Wifi.P2p.Nsd;
using Android.Net;
using System;

namespace FootballGuru.Trainer.App.Platforms.Android
{
    public class WifiDirectBroadcastReceiver : BroadcastReceiver
    {
        readonly WifiP2pManager _manager;
        readonly WifiP2pManager.Channel _channel;

        public event Action<WifiP2pDeviceList> PeersChanged;
        public event Action<WifiP2pInfo> ConnectionInfoAvailable;
        readonly WifiP2pManager.IConnectionInfoListener _connListener;

        public WifiDirectBroadcastReceiver(
                WifiP2pManager mgr,
                WifiP2pManager.Channel ch,
                WifiP2pManager.IConnectionInfoListener connListener)
        {
            _manager = mgr;
            _channel = ch;
            _connListener = connListener;
        }

        public override void OnReceive(Context context, Intent intent)
        {
            var action = intent.Action;

            if (action == WifiP2pManager.WifiP2pPeersChangedAction)
            {
                // request updated list of peers
                var networkInfo = (NetworkInfo)intent.GetParcelableExtra(WifiP2pManager.ExtraNetworkInfo);
                //if (networkInfo.IsConnected)
                //{
                    // Ask the manager to invoke *your* listener (the WifiDirect object):
                    _manager.RequestConnectionInfo(_channel, _connListener);
                //}
            }
            else if (action == WifiP2pManager.WifiP2pConnectionChangedAction)
            {
                var networkInfo = (NetworkInfo)intent.GetParcelableExtra(WifiP2pManager.ExtraNetworkInfo);
                if (networkInfo.IsConnected)
                {
                    // request connection info (GO IP etc)
                    _manager.RequestConnectionInfo(_channel, new ConnectionInfoListener(ConnectionInfoAvailable));
                }
            }
        }

        class PeerListListener : Java.Lang.Object, WifiP2pManager.IPeerListListener
        {
            readonly Action<WifiP2pDeviceList> _callback;
            public PeerListListener(Action<WifiP2pDeviceList> cb) => _callback = cb;
            public void OnPeersAvailable(WifiP2pDeviceList peers) => _callback?.Invoke(peers);
        }

        class ConnectionInfoListener : Java.Lang.Object, WifiP2pManager.IConnectionInfoListener
        {
            readonly Action<WifiP2pInfo> _callback;
            public ConnectionInfoListener(Action<WifiP2pInfo> cb) => _callback = cb;
            public void OnConnectionInfoAvailable(WifiP2pInfo info) => _callback?.Invoke(info);
        }
    }
}
