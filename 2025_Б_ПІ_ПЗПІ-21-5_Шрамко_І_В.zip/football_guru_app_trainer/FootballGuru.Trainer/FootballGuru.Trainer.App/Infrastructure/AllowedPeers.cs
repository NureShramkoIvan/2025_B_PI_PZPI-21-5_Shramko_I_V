﻿namespace FootballGuru.Trainer.App.Infrastructure;

public static class AllowedPeers
{
    public const string SCREEN = "SCREEN";
    public const string CAMERA = "CAMERA";
}
