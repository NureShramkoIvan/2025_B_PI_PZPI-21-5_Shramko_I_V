﻿
using FootballGuru.Trainer.App.Infrastructure.Messages;
using System.Diagnostics;
using System.Text.Json;

namespace FootballGuru.Trainer.App.Infrastructure.Handlers;

public class PlayerPositionViolationMessageHandler(MessagingHub messagingHub) : IMessageHandler
{
    public async Task Handle(string messageJson)
    {
        Debug.WriteLine($"position message received | {messageJson}");

        if (messagingHub.IsPeerConnected(AllowedPeers.SCREEN))
        {
            var message = JsonSerializer.Deserialize<Message<PositionViolationMessage>>(messageJson);

            await messagingHub.SendMessage(AllowedPeers.SCREEN, message);

            Debug.WriteLine($"position sent to screen | {messageJson}");
        }

    }
}
