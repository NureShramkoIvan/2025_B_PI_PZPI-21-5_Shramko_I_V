﻿namespace FootballGuru.Trainer.App.Infrastructure;

public interface IMessageHandler
{
    Task Handle(string messageJson);
}
