using System.Text.Json;
using FootballGuru.Trainer.Core.Models.Trainings;

namespace FootballGuru.Trainer.App.Infrastructure;

public class FileService : IFileService
{
    private readonly string _baseDirectory;

    public FileService()
    {
        _baseDirectory = Path.Combine(FileSystem.AppDataDirectory, "Trainings");
        if (!Directory.Exists(_baseDirectory))
        {
            Directory.CreateDirectory(_baseDirectory);
        }
    }

    private string GetFilePath(Guid id) => Path.Combine(_baseDirectory, $"{id}.json");

    public async Task<bool> SaveTrainingAsync(TrainingDetailsModel training)
    {
        try
        {
            var json = JsonSerializer.Serialize(training);
            await File.WriteAllTextAsync(GetFilePath(training.Id), json);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public async Task<TrainingDetailsModel> LoadTrainingAsync(Guid id)
    {
        try
        {
            var path = GetFilePath(id);
            if (!File.Exists(path))
                return null;

            var json = await File.ReadAllTextAsync(path);
            return JsonSerializer.Deserialize<TrainingDetailsModel>(json);
        }
        catch
        {
            return null;
        }
    }

    public Task<bool> IsTrainingSavedAsync(Guid id)
    {
        return Task.FromResult(File.Exists(GetFilePath(id)));
    }

    public async Task<bool> DeleteTrainingAsync(Guid id)
    {
        try
        {
            var path = GetFilePath(id);
            if (File.Exists(path))
            {
                File.Delete(path);
            }
            return true;
        }
        catch
        {
            return false;
        }
    }
} 