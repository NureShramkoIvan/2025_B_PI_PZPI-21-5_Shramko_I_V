using FootballGuru.Trainer.Core.Models.Trainings;

namespace FootballGuru.Trainer.App.Infrastructure;

public interface IFileService
{
    Task<bool> SaveTrainingAsync(TrainingDetailsModel training);
    Task<TrainingDetailsModel> LoadTrainingAsync(Guid id);
    Task<bool> IsTrainingSavedAsync(Guid id);
    Task<bool> DeleteTrainingAsync(Guid id);
} 