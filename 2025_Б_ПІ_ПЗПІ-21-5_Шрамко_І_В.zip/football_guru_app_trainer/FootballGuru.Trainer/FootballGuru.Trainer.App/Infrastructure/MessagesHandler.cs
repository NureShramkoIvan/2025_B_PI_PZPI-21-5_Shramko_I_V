﻿using System.Diagnostics;
using System.Text.Json;

namespace FootballGuru.Trainer.App.Infrastructure;

public class MessagesHandler(IServiceProvider serviceProvider)
{
    private StreamReader _streamReader;
    private readonly List<(string MessageType, Type HandlerType)> _handlers = [];

    public void Start(StreamReader streamReader)
    {
        _streamReader = streamReader;
        Task.Run(Handle);
    }

    public void RegisterHandler(string messageType, Type handlerType)
    {
        _handlers.Add((messageType, handlerType));
    }

    public void Handle()
    {
        while (true)
        {
            var messageJson = _streamReader.ReadLineAsync().Result;

            if (messageJson is null)
            {
                //Debug.WriteLine($"Message is empty");
                continue;
            }

            try
            {
                var messageBase = JsonSerializer.Deserialize<MessageBase>(messageJson);

                var handlerType = _handlers.FirstOrDefault(h => h.MessageType == messageBase.Type).HandlerType;

                if (handlerType is null)
                {
                    Debug.WriteLine($"No handler for message | {messageBase.Type}");
                    continue;
                }

                var handler = (IMessageHandler)serviceProvider.GetRequiredService(handlerType);

                handler.Handle(messageJson);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to parse message | {ex}");
            }

        }
    }
}
