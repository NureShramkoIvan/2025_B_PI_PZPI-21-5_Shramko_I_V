﻿using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace FootballGuru.Trainer.App.Infrastructure;

public class MessagingHub(List<string> allowedPeers, IServiceProvider serviceProvider, int port = 8888)
{
    private TcpListener _listener;
    private List<(string Peer, NetworkStream Stream, StreamWriter Writer, StreamReader Reader)> _streams = [];

    public void Start()
    {
        _listener = new TcpListener(IPAddress.Any, port);
        _listener.Start();
    }

    public async Task<bool> WaitForConnections(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            if (allowedPeers.Count == _streams.Count)
            {
                return true;
            }

            var client = await _listener.AcceptTcpClientAsync(cancellationToken).ConfigureAwait(false);

            var stream = client.GetStream();
            var reader = new StreamReader(stream, Encoding.UTF8, false, leaveOpen: true);

            var messageJson = await reader.ReadLineAsync(cancellationToken).ConfigureAwait(false);

            if (messageJson is null)
            {
                Debug.WriteLine("Message is empty");
            }

            try
            {
                var message = JsonSerializer.Deserialize<Message<string>>(messageJson);

                if (message.Type != MessageTypes.ACK)
                {
                    Debug.WriteLine($"Not an ACK message | mt: {message.Type}");
                    continue;
                }

                var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };

                _streams.Add((message.Data, stream, writer, reader));
                Debug.WriteLine($"Added peer {message.Data}");

                var peerMessagesHandler = serviceProvider.GetKeyedService<MessagesHandler>(message.Data);

                if (peerMessagesHandler is null)
                {
                    Debug.WriteLine($"No msg handler is registered for peer {message.Data}");
                }

                peerMessagesHandler.Start(reader);

                Debug.WriteLine($"Started msg handler for peer {message.Data}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"TCp connecting ... | Error parsing message | {ex}");
            }
        }

        return false;
    }

    public async Task SendMessage<TMessageData>(string peer, Message<TMessageData> message)
    {
        var writer = _streams.FirstOrDefault(s => s.Peer == peer).Writer;

        if (writer is null) return;

        var messageJson = JsonSerializer.Serialize(message);

        await writer.WriteLineAsync(messageJson);
    }

    public bool IsConnected() => _streams.Count == allowedPeers.Count;
    public bool IsPeerConnected(string peer) => _streams.Any(s => s.Peer == peer);
}
