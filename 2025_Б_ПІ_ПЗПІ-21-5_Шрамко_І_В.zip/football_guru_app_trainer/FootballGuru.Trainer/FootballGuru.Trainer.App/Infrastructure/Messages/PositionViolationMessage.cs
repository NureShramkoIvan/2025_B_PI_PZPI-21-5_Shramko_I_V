﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballGuru.Trainer.App.Infrastructure.Messages;

public class PositionViolationMessage
{
    public int PlayerId { get; set; }
    public int Direction { get; set; }
}
