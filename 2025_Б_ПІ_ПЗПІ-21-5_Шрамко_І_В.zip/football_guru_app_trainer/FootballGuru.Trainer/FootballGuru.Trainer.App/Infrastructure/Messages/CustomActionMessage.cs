﻿namespace FootballGuru.Trainer.App.Infrastructure.Messages;

public class CustomActionMessage
{
    public int PlayerId { get; set; }
    public string Action { get; set; }
}
