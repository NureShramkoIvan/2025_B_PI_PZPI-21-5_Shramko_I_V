﻿using FootballGuru.Trainer.App.Pages;
using FootballGuru.Trainer.App.Pages.Auth;
using FootballGuru.Trainer.App.Pages.Players;
using FootballGuru.Trainer.App.Pages.Roles;
using FootballGuru.Trainer.App.Pages.Training;

namespace FootballGuru.Trainer.App;

public partial class AppShell : Shell

{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
        Routing.RegisterRoute(nameof(RegisterPage), typeof(RegisterPage));
        Routing.RegisterRoute(nameof(CreatePlayerPage), typeof(CreatePlayerPage));
        Routing.RegisterRoute(nameof(PlayerDetailsPage), typeof(PlayerDetailsPage));
        Routing.RegisterRoute(nameof(RoleDetailsPage), typeof(RoleDetailsPage));
        Routing.RegisterRoute(nameof(CreateRolePage), typeof(CreateRolePage));
        Routing.RegisterRoute(nameof(LookupRoleModal), typeof(LookupRoleModal));
        Routing.RegisterRoute(nameof(SelectFormationPage), typeof(SelectFormationPage));
        Routing.RegisterRoute(nameof(LookupPlayerModal), typeof(LookupPlayerModal));
        Routing.RegisterRoute(nameof(SelectPlayersPage), typeof(SelectPlayersPage));
        Routing.RegisterRoute(nameof(CustomActionsModal), typeof(CustomActionsModal));
        Routing.RegisterRoute(nameof(SelectZonesPage), typeof(SelectZonesPage));
        Routing.RegisterRoute(nameof(CreateTrainingPage), typeof(CreateTrainingPage));
        Routing.RegisterRoute("TrainingPage", typeof(TrainingPage));
        //Routing.RegisterRoute(nameof(HomePage), typeof(HomePage));
    }
}
